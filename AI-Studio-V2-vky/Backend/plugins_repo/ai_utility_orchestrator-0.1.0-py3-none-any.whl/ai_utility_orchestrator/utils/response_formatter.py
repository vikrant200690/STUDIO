# ai_utility_orchestrator/utils/response_formatter.py

import os
import json
import yaml
import ast
import re
from dotenv import load_dotenv
from typing import Any, Union, Optional, Dict, List

# Load .env variables
load_dotenv()

try:
    from openai import OpenAI
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        client = OpenAI(api_key=api_key)
    else:
        client = None
except ImportError:
    print("Warning: OpenAI package not installed. Some features may not work.")
    client = None
except Exception as e:
    print(f"Warning: Could not initialize OpenAI client: {e}")
    client = None


def _parse_response(raw_text: str, formatter: str) -> Union[dict, list, str, None]:
    """
    Helper function to parse raw LLM response based on specified formatter.
    
    Args:
        raw_text: The raw response from the LLM
        formatter: Format type - 'json', 'yaml', 'python', or 'answer'
        
    Returns:
        Parsed response in the requested format, or raw text if parsing fails
    """
    if not raw_text or not raw_text.strip():
        return None

    try:
        if formatter == "json":
            cleaned_text = raw_text.strip()
            
            # Try direct JSON parsing first (most common case)
            if cleaned_text.startswith('{') and cleaned_text.endswith('}'):
                return json.loads(cleaned_text)
            
            # Try array format
            if cleaned_text.startswith('[') and cleaned_text.endswith(']'):
                return json.loads(cleaned_text)

            # Try to extract JSON from code blocks (``````)
            json_match = re.search(r'``````', cleaned_text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group(1))

            # Last resort: extract first { to last matching }
            start = cleaned_text.find('{')
            end = cleaned_text.rfind('}')
            if start != -1 and end != -1 and end > start:
                return json.loads(cleaned_text[start:end+1])
            
            # Try for array format
            start = cleaned_text.find('[')
            end = cleaned_text.rfind(']')
            if start != -1 and end != -1 and end > start:
                return json.loads(cleaned_text[start:end+1])

            # If no JSON found, return the raw text
            print(f"Warning: Could not extract JSON from response, returning raw text")
            return cleaned_text

        elif formatter == "yaml":
            # YAML can return dict, list, string, or None
            return yaml.safe_load(raw_text)
            
        elif formatter == "python":
            # Note: ast.literal_eval expects Python literals, not JSON
            # Use this only for Python dict/list syntax, not JSON with true/false/null
            return ast.literal_eval(raw_text)
            
        else:
            # For 'answer' or unsupported formatter, return as-is
            return raw_text

    except json.JSONDecodeError as e:
        print(f"JSON parsing failed: {e}")
        print(f"Raw text was: {raw_text[:200]}...")
        return raw_text.strip()
        
    except yaml.YAMLError as e:
        print(f"YAML parsing failed: {e}")
        return raw_text.strip()
        
    except (ValueError, SyntaxError) as e:
        print(f"Python literal parsing failed: {e}")
        return raw_text.strip()
        
    except Exception as e:
        print(f"Failed to parse LLM output using formatter '{formatter}': {e}")
        return raw_text.strip() if raw_text else None


def _validate_messages(messages: List[Dict]) -> List[Dict]:
    """
    Validate and clean message list for OpenAI API.
    
    Args:
        messages: List of message dictionaries
        
    Returns:
        Cleaned list of messages with valid roles and content
    """
    valid_roles = {"system", "user", "assistant"}
    cleaned_messages = []
    
    for msg in messages:
        if not isinstance(msg, dict):
            continue
            
        if "role" not in msg or "content" not in msg:
            continue
            
        if msg["role"] not in valid_roles:
            print(f"Warning: Invalid role '{msg['role']}' found, skipping message")
            continue
        
        # Ensure content is a string
        cleaned_msg = {
            "role": msg["role"],
            "content": str(msg["content"]) if msg["content"] is not None else ""
        }
        cleaned_messages.append(cleaned_msg)
    
    return cleaned_messages


def format_response(
    prompt: str,
    formatter: str,
    model_name: str,
    temperature: float,
    return_meta: bool = False,
    system_prompt: Optional[str] = None,
    messages: Optional[List[Dict]] = None,
    max_tokens: Optional[int] = 1024,
    use_json_mode: bool = True
) -> Union[Dict[str, Any], str, None]:
    """
    Calls the LLM and formats the output.

    Args:
        prompt: The user query or prompt
        formatter: Format type: 'json', 'yaml', 'python', or 'answer'
        model_name: OpenAI model name (e.g., 'gpt-4o', 'gpt-4-turbo')
        temperature: Temperature for creativity (0.0 to 2.0)
        return_meta: Whether to return metadata like raw response and model used
        system_prompt: System prompt to guide the LLM
        messages: Previous conversation messages for context
        max_tokens: Maximum tokens in response (default: 1024)
        use_json_mode: Use OpenAI's JSON mode when formatter is 'json' (default: True)

    Returns:
        If return_meta is True:
            dict: {
                "raw_response": str,
                "parsed_response": Any,
                "used_model": str,
                "error": Optional[str]
            }
        Else:
            Parsed response only (type depends on formatter)
    """
    if not client:
        error_msg = "OpenAI client not initialized. Check your API key."
        if return_meta:
            return {
                "raw_response": None,
                "parsed_response": None,
                "used_model": None,
                "error": error_msg
            }
        return None

    try:
        # Build messages array
        conversation_messages = []

        # Add system prompt if provided
        if system_prompt:
            conversation_messages.append({"role": "system", "content": system_prompt})

        # Add previous messages if provided
        if messages:
            cleaned_messages = _validate_messages(messages)
            conversation_messages.extend(cleaned_messages)

        # Add current user prompt
        conversation_messages.append({"role": "user", "content": prompt})

        # Prepare API call arguments
        api_args = {
            "model": model_name,
            "messages": conversation_messages,
            "temperature": temperature,
        }
        
        # Add max_tokens if specified
        if max_tokens:
            api_args["max_tokens"] = max_tokens

        # Use JSON mode for stricter JSON formatting (requires compatible models)
        if formatter == "json" and use_json_mode:
            try:
                api_args["response_format"] = {"type": "json_object"}
            except Exception as e:
                print(f"Warning: Could not enable JSON mode: {e}")

        # Make API call
        response = client.chat.completions.create(**api_args)

        raw_text = response.choices[0].message.content.strip()
        parsed_output = _parse_response(raw_text, formatter)

        if return_meta:
            return {
                "raw_response": raw_text,
                "parsed_response": parsed_output,
                "used_model": model_name,
                "error": None
            }
        else:
            return parsed_output

    except Exception as e:
        error_msg = f"Error during LLM response: {str(e)}"
        print(error_msg)
        
        if return_meta:
            return {
                "raw_response": None,
                "parsed_response": None,
                "used_model": model_name,
                "error": error_msg
            }
        else:
            return None


# Example usage and testing
if __name__ == "__main__":
    # Test with JSON formatter
    test_prompt = "List 3 programming languages as JSON with fields: name, year, paradigm"
    
    result = format_response(
        prompt=test_prompt,
        formatter="json",
        model_name="gpt-4o-mini",
        temperature=0.7,
        return_meta=True,
        system_prompt="You are a helpful assistant that returns structured data."
    )
    
    print("Result:", json.dumps(result, indent=2))
