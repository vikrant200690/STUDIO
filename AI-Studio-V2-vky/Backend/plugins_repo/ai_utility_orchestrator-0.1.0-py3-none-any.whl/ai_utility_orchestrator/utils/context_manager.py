# ai_utility_orchestrator/utils/context_manager.py

"""
Context Manager for conversation history and runtime state management.
Handles persistent storage and session-level context with thread-safe operations.
"""

import json
import os
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class ContextManager:
    """
    Manages conversation history and runtime context with persistence.
    Thread-safe implementation for concurrent access.
    """

    def __init__(
        self,
        history_path: Optional[Union[str, Path]] = None,
        max_history_per_user: int = 1000,
        auto_save: bool = True,
    ):
        """
        Initialize the ContextManager.

        Args:
            history_path: Path to store conversation history (defaults to user home)
            max_history_per_user: Maximum number of interactions to store per user
            auto_save: Whether to automatically save after each interaction
        """
        # Use default path if none provided
        if history_path is None:
            home_dir = Path.home()
            data_dir = home_dir / ".ai_utility_orchestrator"
            history_path = data_dir / "chat_history.json"

        self.history_path = Path(history_path)
        self.max_history_per_user = max_history_per_user
        self.auto_save = auto_save

        # Create directory if it doesn't exist
        try:
            self.history_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.error(f"Failed to create history directory: {e}")
            raise

        self.history: Dict[str, List[Dict[str, Any]]] = self._load_history()

        # Runtime context for session-level state management
        self.runtime_context: Dict[str, Any] = {}

        # Thread safety
        self._lock = threading.RLock()

        # Statistics
        self._stats = {
            "total_interactions": 0,
            "active_users": set(),
            "last_save_time": None,
        }

    def _load_history(self) -> Dict[str, List[Dict[str, Any]]]:
        """Load conversation history from disk."""
        if self.history_path.exists():
            try:
                with open(self.history_path, "r", encoding="utf-8") as f:
                    history = json.load(f)
                    logger.info(f"Loaded history for {len(history)} users")
                    return history
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse history file: {e}")
                # Backup corrupted file
                backup_path = self.history_path.with_suffix(".json.backup")
                try:
                    self.history_path.rename(backup_path)
                    logger.info(f"Backed up corrupted history to {backup_path}")
                except Exception as backup_error:
                    logger.error(f"Failed to backup corrupted history: {backup_error}")
                return {}
            except Exception as e:
                logger.error(f"Failed to load history: {e}")
                return {}
        return {}

    def _save_history(self) -> bool:
        """Save conversation history to disk."""
        with self._lock:
            try:
                # Write to temporary file first
                temp_path = self.history_path.with_suffix(".json.tmp")
                with open(temp_path, "w", encoding="utf-8") as f:
                    json.dump(self.history, f, indent=2, ensure_ascii=False)

                # Atomic replace
                temp_path.replace(self.history_path)

                self._stats["last_save_time"] = datetime.utcnow().isoformat()
                logger.debug(f"Saved history for {len(self.history)} users")
                return True

            except Exception as e:
                logger.error(f"Failed to save history: {e}")
                return False

    def get_history(self, user_id: str) -> List[Dict[str, Any]]:
        """
        Get conversation history for a specific user.

        Args:
            user_id: User identifier

        Returns:
            List of conversation interactions
        """
        with self._lock:
            return self.history.get(user_id, []).copy()

    def get_recent_messages(
        self,
        user_id: str,
        limit: int = 5,
        format_config: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get recent messages formatted for LLM context.

        Args:
            user_id: User identifier
            limit: Maximum number of interactions to retrieve
            format_config: Configuration with user_role, assistant_role, include_metadata

        Returns:
            List of formatted messages

        Raises:
            ValueError: If format_config is invalid or missing required fields
        """
        if not format_config:
            raise ValueError(
                "format_config must be provided with user_role, assistant_role, and include_metadata"
            )

        if not isinstance(format_config, dict):
            raise ValueError(
                "format_config must be a dictionary containing user_role, assistant_role, and include_metadata"
            )

        user_role = format_config.get("user_role")
        assistant_role = format_config.get("assistant_role")
        include_metadata = format_config.get("include_metadata")

        if user_role is None or assistant_role is None or include_metadata is None:
            raise ValueError(
                "format_config must contain user_role, assistant_role, and include_metadata"
            )

        with self._lock:
            history = self.get_history(user_id)
            messages: List[Dict[str, Any]] = []

            # Get last 'limit' interactions
            recent_history = history[-limit:] if len(history) > limit else history

            for i, interaction in enumerate(recent_history):
                user_msg = {"role": user_role, "content": interaction["user"]}
                assistant_msg = {"role": assistant_role, "content": interaction["bot"]}

                # Add metadata if requested
                if include_metadata:
                    timestamp = interaction.get("timestamp", "unknown")
                    user_msg["metadata"] = {
                        "interaction_index": i,
                        "user_id": user_id,
                        "timestamp": timestamp,
                    }
                    assistant_msg["metadata"] = {
                        "interaction_index": i,
                        "user_id": user_id,
                        "timestamp": timestamp,
                    }

                messages.append(user_msg)
                messages.append(assistant_msg)

            return messages

    def add_interaction(
        self,
        user_id: str,
        user_input: str,
        bot_response: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Add a new interaction to history.

        Args:
            user_id: User identifier
            user_input: User's message
            bot_response: Bot's response
            metadata: Optional metadata to store with the interaction

        Returns:
            True if saved successfully
        """
        with self._lock:
            if user_id not in self.history:
                self.history[user_id] = []
                self._stats["active_users"].add(user_id)

            interaction: Dict[str, Any] = {
                "user": user_input,
                "bot": bot_response,
                "timestamp": datetime.utcnow().isoformat(),
            }

            if metadata:
                interaction["metadata"] = metadata

            self.history[user_id].append(interaction)

            # Trim history if it exceeds max length
            if len(self.history[user_id]) > self.max_history_per_user:
                removed = len(self.history[user_id]) - self.max_history_per_user
                self.history[user_id] = self.history[user_id][-self.max_history_per_user:]
                logger.info(f"Trimmed {removed} old interactions for user {user_id}")

            self._stats["total_interactions"] += 1

            if self.auto_save:
                return self._save_history()

            return True

    def clear_history(self, user_id: Optional[str] = None) -> bool:
        """
        Clear conversation history.

        Args:
            user_id: Specific user to clear (if None, clears all)

        Returns:
            True if cleared successfully
        """
        with self._lock:
            if user_id:
                if user_id in self.history:
                    del self.history[user_id]
                    self._stats["active_users"].discard(user_id)
                    logger.info(f"Cleared history for user {user_id}")
            else:
                self.history = {}
                self._stats["active_users"].clear()
                logger.info("Cleared all history")

            if self.auto_save:
                return self._save_history()

            return True

    def get_user_stats(self, user_id: str) -> Dict[str, Any]:
        """
        Get statistics for a specific user.

        Args:
            user_id: User identifier

        Returns:
            Dictionary with user statistics
        """
        with self._lock:
            history = self.history.get(user_id, [])
            return {
                "user_id": user_id,
                "total_interactions": len(history),
                "first_interaction": history[0]["timestamp"] if history else None,
                "last_interaction": history[-1]["timestamp"] if history else None,
            }

    def get_all_users(self) -> List[str]:
        """Get list of all users with history."""
        with self._lock:
            return list(self.history.keys())

    def export_history(
        self, user_id: Optional[str] = None, output_path: Optional[Path] = None
    ) -> Optional[str]:
        """
        Export history to JSON file.

        Args:
            user_id: Specific user to export (if None, exports all)
            output_path: Path to save export (if None, returns JSON string)

        Returns:
            JSON string if output_path is None, otherwise None
        """
        with self._lock:
            if user_id:
                export_data = {user_id: self.history.get(user_id, [])}
            else:
                export_data = self.history

            json_str = json.dumps(export_data, indent=2, ensure_ascii=False)

            if output_path:
                try:
                    output_path = Path(output_path)
                    output_path.parent.mkdir(parents=True, exist_ok=True)
                    with open(output_path, "w", encoding="utf-8") as f:
                        f.write(json_str)
                    logger.info(f"Exported history to {output_path}")
                    return None
                except Exception as e:
                    logger.error(f"Failed to export history: {e}")
                    raise

            return json_str

    def import_history(
        self, import_path: Path, merge: bool = True
    ) -> bool:
        """
        Import history from JSON file.

        Args:
            import_path: Path to import from
            merge: If True, merge with existing; if False, replace

        Returns:
            True if import successful
        """
        with self._lock:
            try:
                with open(import_path, "r", encoding="utf-8") as f:
                    imported_data = json.load(f)

                if merge:
                    for user_id, interactions in imported_data.items():
                        if user_id not in self.history:
                            self.history[user_id] = []
                        self.history[user_id].extend(interactions)
                else:
                    self.history = imported_data

                logger.info(f"Imported history from {import_path}")
                return self._save_history()

            except Exception as e:
                logger.error(f"Failed to import history: {e}")
                return False

    # Runtime Context Management Methods

    def set_context(self, key: str, value: Any) -> None:
        """Set a runtime context value for the current session."""
        with self._lock:
            self.runtime_context[key] = value

    def get_context(self, key: str, default: Any = None) -> Any:
        """Get a runtime context value by key."""
        with self._lock:
            return self.runtime_context.get(key, default)

    def get_all_context(self) -> Dict[str, Any]:
        """Get all runtime context data."""
        with self._lock:
            return self.runtime_context.copy()

    def clear_context(self) -> None:
        """Clear all runtime context data."""
        with self._lock:
            self.runtime_context = {}
            logger.info("Cleared runtime context")

    def remove_context(self, key: str) -> bool:
        """Remove a specific context key. Returns True if key existed."""
        with self._lock:
            if key in self.runtime_context:
                del self.runtime_context[key]
                return True
            return False

    def has_context(self, key: str) -> bool:
        """Check if a context key exists."""
        with self._lock:
            return key in self.runtime_context

    def update_context(self, context_dict: Dict[str, Any]) -> None:
        """Update multiple context values at once."""
        with self._lock:
            self.runtime_context.update(context_dict)

    def get_statistics(self) -> Dict[str, Any]:
        """Get overall statistics."""
        with self._lock:
            return {
                "total_users": len(self.history),
                "active_users": len(self._stats["active_users"]),
                "total_interactions": self._stats["total_interactions"],
                "last_save_time": self._stats["last_save_time"],
                "history_file": str(self.history_path),
                "file_size_bytes": self.history_path.stat().st_size
                if self.history_path.exists()
                else 0,
            }

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - save on exit."""
        if self.auto_save:
            self._save_history()

    def __repr__(self) -> str:
        """String representation."""
        return f"<ContextManager: {len(self.history)} users, {self._stats['total_interactions']} interactions>"
