# ai_utility_orchestrator/utils/toolkit.py

import os
import json
import logging
import importlib
from typing import Dict, List, Callable, Any, Optional
from pathlib import Path

try:
    from importlib import resources
except ImportError:
    # Python < 3.9 fallback
    import importlib_resources as resources

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

logger = logging.getLogger("ai_utility_orchestrator.toolkit")


class ConfigUtils:
    """Utility class for configuration management with support for user-specific configs."""
    
    @staticmethod
    def _get_default_config() -> Dict[str, Any]:
        """
        Get empty default configuration.
        Users must provide all configuration via files or overrides.
        
        Returns:
            Empty configuration dictionary
        """
        return {}

    @staticmethod
    def load_config(
        file_path: Optional[str] = None,
        overrides: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Load configuration from file with support for user-specific overrides.
        
        Priority order:
        1. Specified file_path
        2. Environment variable AI_ORCHESTRATOR_CONFIG
        3. Minimal default config
        4. User-specific config (if user_id provided)
        5. Runtime overrides
        
        Args:
            file_path: Path to main config file
            overrides: Dictionary of config values to override
            user_id: Optional user ID for loading user-specific config
            
        Returns:
            Merged configuration dictionary
        """
        config = None
        config_path = None

        # Case 1: Load from specified file path
        if file_path:
            config_path = file_path
            if os.path.exists(file_path):
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        config = json.load(f)
                    logger.info(f"Loaded config from: {file_path}")
                except (json.JSONDecodeError, IOError) as e:
                    logger.error(f"Failed to load config from {file_path}: {e}")
                    config = None
            else:
                logger.error(f"Config file not found: {file_path}")
                config = None

        # Case 2: Load from environment variable
        else:
            env_config = os.getenv("AI_ORCHESTRATOR_CONFIG")
            if env_config:
                if os.path.exists(env_config):
                    try:
                        with open(env_config, "r", encoding="utf-8") as f:
                            config = json.load(f)
                            config_path = env_config
                        logger.info(f"Loaded config from environment: {env_config}")
                    except (json.JSONDecodeError, IOError) as e:
                        logger.warning(f"Failed to load config from environment path {env_config}: {e}")
                        config = None
                else:
                    logger.warning(f"Environment config path does not exist: {env_config}")

        # If no config was loaded, use minimal dynamic configuration
        if config is None:
            logger.info("No config file found. Using minimal dynamic configuration.")
            config = ConfigUtils._get_default_config()

        # Apply user-specific config if available
        if user_id and config_path and config_path != "package_resources":
            try:
                user_config_path = Path(config_path).parent / f"user_{user_id}.json"
                if user_config_path.exists():
                    with open(user_config_path, "r", encoding="utf-8") as f:
                        user_config = json.load(f)
                        # Deep merge user config
                        ConfigUtils._deep_merge(config, user_config)
                    logger.info(f"Applied user-specific config for user: {user_id}")
                else:
                    logger.debug(f"No user-specific config found for user: {user_id}")
            except Exception as e:
                logger.warning(f"Could not load user config for {user_id}: {e}")

        # Apply overrides
        if overrides:
            ConfigUtils._deep_merge(config, overrides)
            logger.debug(f"Applied {len(overrides)} config overrides")

        return config

    @staticmethod
    def _deep_merge(base_dict: Dict[str, Any], update_dict: Dict[str, Any]) -> None:
        """
        Deep merge update_dict into base_dict (modifies base_dict in-place).
        
        Args:
            base_dict: Base dictionary to merge into
            update_dict: Dictionary with values to merge
        """
        for key, value in update_dict.items():
            if key in base_dict and isinstance(base_dict[key], dict) and isinstance(value, dict):
                ConfigUtils._deep_merge(base_dict[key], value)
            else:
                base_dict[key] = value

    @staticmethod
    def load_tools_from_config(config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract tools list from configuration.
        
        Args:
            config: Configuration dictionary
            
        Returns:
            List of tool definitions
        """
        tools = config.get("tools", [])
        logger.debug(f"Loaded {len(tools)} tools from config")
        return tools

    @staticmethod
    def save_config(config: Dict[str, Any], file_path: str) -> bool:
        """
        Save configuration to a JSON file.
        
        Args:
            config: Configuration dictionary to save
            file_path: Path where config should be saved
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Create directory if it doesn't exist
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Saved config to: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save config to {file_path}: {e}")
            return False

    @staticmethod
    def validate_config(config: Dict[str, Any], required_keys: List[str] = None) -> bool:
        """
        Validate configuration has required keys.
        
        Args:
            config: Configuration dictionary to validate
            required_keys: List of required top-level keys
            
        Returns:
            True if valid, False otherwise
        """
        if required_keys is None:
            required_keys = []
        
        missing_keys = [key for key in required_keys if key not in config]
        
        if missing_keys:
            logger.error(f"Config validation failed. Missing keys: {missing_keys}")
            return False
        
        logger.debug("Config validation passed")
        return True


class EnvUtils:
    """Utility class for environment variable management."""
    
    @staticmethod
    def get_env(key: str, default: str = "", required: bool = False) -> str:
        """
        Get environment variable with optional validation.
        
        Args:
            key: Environment variable name
            default: Default value if not found
            required: Raise error if not found
            
        Returns:
            Environment variable value or default
            
        Raises:
            EnvironmentError: If required=True and variable not found
        """
        value = os.getenv(key, default)
        if required and not value:
            raise EnvironmentError(f"Missing required environment variable: {key}")
        return value

    @staticmethod
    def get_env_int(key: str, default: int = 0, required: bool = False) -> int:
        """
        Get environment variable as integer.
        
        Args:
            key: Environment variable name
            default: Default value if not found or invalid
            required: Raise error if not found
            
        Returns:
            Integer value of environment variable
        """
        value = EnvUtils.get_env(key, str(default), required)
        try:
            return int(value)
        except ValueError:
            logger.warning(f"Invalid integer value for {key}: {value}, using default: {default}")
            return default

    @staticmethod
    def get_env_bool(key: str, default: bool = False, required: bool = False) -> bool:
        """
        Get environment variable as boolean.
        
        Args:
            key: Environment variable name
            default: Default value if not found
            required: Raise error if not found
            
        Returns:
            Boolean value (True for '1', 'true', 'yes', case-insensitive)
        """
        value = EnvUtils.get_env(key, str(default), required).lower()
        return value in ('1', 'true', 'yes', 'on')

    @staticmethod
    def get_env_list(key: str, default: List[str] = None, separator: str = ",", required: bool = False) -> List[str]:
        """
        Get environment variable as list (comma-separated by default).
        
        Args:
            key: Environment variable name
            default: Default list if not found
            separator: String to split on
            required: Raise error if not found
            
        Returns:
            List of strings
        """
        if default is None:
            default = []
        
        value = EnvUtils.get_env(key, "", required)
        if not value:
            return default
        
        return [item.strip() for item in value.split(separator) if item.strip()]


class DynamicImportUtils:
    """Utility class for dynamic module and object imports."""
    
    @staticmethod
    def load_object(path: str) -> Optional[Any]:
        """
        Dynamically import and return an object from a module path.
        
        Args:
            path: Dotted path to object (e.g., 'module.submodule.ClassName')
            
        Returns:
            Imported object or None if import fails
        """
        try:
            module_path, attr = path.rsplit(".", 1)
            module = importlib.import_module(module_path)
            obj = getattr(module, attr)
            logger.debug(f"Successfully imported: {path}")
            return obj
        except ValueError:
            logger.error(f"Invalid import path (no dot found): {path}")
            return None
        except ImportError as e:
            logger.error(f"Could not import module from {path}: {e}")
            return None
        except AttributeError as e:
            logger.error(f"Could not find attribute in {path}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error importing {path}: {e}")
            return None

    @staticmethod
    def load_module(module_path: str) -> Optional[Any]:
        """
        Dynamically import a module.
        
        Args:
            module_path: Dotted path to module
            
        Returns:
            Imported module or None if import fails
        """
        try:
            module = importlib.import_module(module_path)
            logger.debug(f"Successfully imported module: {module_path}")
            return module
        except ImportError as e:
            logger.error(f"Could not import module {module_path}: {e}")
            return None

    @staticmethod
    def check_import(module_path: str) -> bool:
        """
        Check if a module can be imported without actually importing it.
        
        Args:
            module_path: Dotted path to module
            
        Returns:
            True if module exists, False otherwise
        """
        try:
            importlib.util.find_spec(module_path)
            return True
        except (ImportError, ValueError, AttributeError):
            return False


class RegistryUtils:
    """
    Global registry for tools with decorator-based registration.
    Supports both function and class-based tools.
    """
    
    registered_tools: Dict[str, Callable] = {}
    tool_metadata: Dict[str, Dict[str, Any]] = {}

    @classmethod
    def register_tool(cls, name: str, metadata: Optional[Dict[str, Any]] = None):
        """
        Decorator to register a tool function.
        
        Args:
            name: Unique tool identifier
            metadata: Optional metadata (description, parameters, etc.)
            
        Returns:
            Decorator function
            
        Example:
            @RegistryUtils.register_tool("my_tool", {"description": "Does something"})
            def my_tool_func(param1, param2):
                return result
        """
        def wrapper(func: Callable):
            cls.registered_tools[name] = func
            if metadata:
                cls.tool_metadata[name] = metadata
            logger.info(f"Registered tool: {name}")
            return func
        return wrapper

    @classmethod
    def register_tool_class(cls, name: str, tool_class: type, metadata: Optional[Dict[str, Any]] = None):
        """
        Register a tool class (not a decorator).
        
        Args:
            name: Unique tool identifier
            tool_class: Class or callable to register
            metadata: Optional metadata
        """
        cls.registered_tools[name] = tool_class
        if metadata:
            cls.tool_metadata[name] = metadata
        logger.info(f"Registered tool class: {name}")

    @classmethod
    def get_tool(cls, name: str) -> Optional[Callable]:
        """
        Get a registered tool by name.
        
        Args:
            name: Tool identifier
            
        Returns:
            Tool callable or None if not found
        """
        tool = cls.registered_tools.get(name)
        if tool is None:
            logger.warning(f"Tool not found: {name}")
        return tool

    @classmethod
    def get_tool_metadata(cls, name: str) -> Optional[Dict[str, Any]]:
        """
        Get metadata for a registered tool.
        
        Args:
            name: Tool identifier
            
        Returns:
            Metadata dictionary or None if not found
        """
        return cls.tool_metadata.get(name)

    @classmethod
    def list_registered_tools(cls) -> List[str]:
        """
        Get list of all registered tool names.
        
        Returns:
            List of tool identifiers
        """
        return list(cls.registered_tools.keys())

    @classmethod
    def unregister_tool(cls, name: str) -> bool:
        """
        Remove a tool from the registry.
        
        Args:
            name: Tool identifier
            
        Returns:
            True if tool was removed, False if not found
        """
        if name in cls.registered_tools:
            del cls.registered_tools[name]
            if name in cls.tool_metadata:
                del cls.tool_metadata[name]
            logger.info(f"Unregistered tool: {name}")
            return True
        logger.warning(f"Cannot unregister tool (not found): {name}")
        return False

    @classmethod
    def clear_registry(cls):
        """Clear all registered tools."""
        count = len(cls.registered_tools)
        cls.registered_tools.clear()
        cls.tool_metadata.clear()
        logger.info(f"Cleared tool registry ({count} tools removed)")

    @classmethod
    def get_all_tools_info(cls) -> Dict[str, Dict[str, Any]]:
        """
        Get information about all registered tools.
        
        Returns:
            Dictionary mapping tool names to their info
        """
        return {
            name: {
                "callable": tool,
                "metadata": cls.tool_metadata.get(name, {}),
                "callable_type": type(tool).__name__
            }
            for name, tool in cls.registered_tools.items()
        }


# Example usage and testing
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.DEBUG)
    
    # Test ConfigUtils
    print("\n=== Testing ConfigUtils ===")
    config = ConfigUtils.load_config()
    print(f"Loaded config: {config}")
    
    # Test EnvUtils
    print("\n=== Testing EnvUtils ===")
    test_val = EnvUtils.get_env("PATH", default="not_found")
    print(f"PATH exists: {test_val != 'not_found'}")
    
    # Test RegistryUtils
    print("\n=== Testing RegistryUtils ===")
    
    @RegistryUtils.register_tool("test_tool", {"description": "A test tool"})
    def my_test_tool(x, y):
        return x + y
    
    print(f"Registered tools: {RegistryUtils.list_registered_tools()}")
    tool = RegistryUtils.get_tool("test_tool")
    if tool:
        print(f"Tool result: {tool(2, 3)}")
    
    print(f"All tools info: {RegistryUtils.get_all_tools_info()}")
