# core/agent_registry.py

from typing import List, Dict, Optional, Callable, Any
from ai_utility_orchestrator.core.tools import Tool
import logging
from collections import defaultdict
import threading

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Thread-safe registry for maintaining available tools with dynamic capabilities."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self._tools: Dict[str, Tool] = {}  # Dictionary to store tools by name
        self.config = config or {}
        self.registration_callbacks: List[Callable[[Tool], None]] = []  # For dynamic registration events
        self._lock = threading.RLock()  # Thread-safe operations
        self._tool_usage_stats: Dict[str, int] = defaultdict(int)  # Track tool usage
        self._tool_metadata: Dict[str, Dict[str, Any]] = {}  # Extended metadata per tool
    
    def register_tool(self, tool: Tool, metadata: Optional[Dict[str, Any]] = None) -> bool:
        """
        Register a new tool with configurable logging.
        
        Args:
            tool: Tool instance to register
            metadata: Optional metadata (tags, priority, etc.)
            
        Returns:
            bool: True if registration successful, False if tool already exists
        """
        with self._lock:
            if tool.name in self._tools:
                logger.warning(f"Tool '{tool.name}' already registered. Skipping.")
                return False
            
            self._tools[tool.name] = tool
            
            # Store metadata if provided
            if metadata:
                self._tool_metadata[tool.name] = metadata
            
            # Configurable registration message - user must provide template
            reg_template = self.config.get("registration_message")
            if reg_template:
                logger.info(reg_template.format(tool_name=tool.name))
            
            # Execute registration callbacks
            for callback in self.registration_callbacks:
                try:
                    callback(tool)
                except Exception as e:
                    logger.warning(f"Registration callback failed for '{tool.name}': {e}")
            
            return True
    
    def unregister_tool(self, name: str) -> bool:
        """
        Unregister a tool by name.
        
        Args:
            name: Name of the tool to unregister
            
        Returns:
            bool: True if tool was removed, False if not found
        """
        with self._lock:
            if name in self._tools:
                del self._tools[name]
                if name in self._tool_metadata:
                    del self._tool_metadata[name]
                if name in self._tool_usage_stats:
                    del self._tool_usage_stats[name]
                logger.info(f"Tool '{name}' unregistered")
                return True
            return False
    
    def add_registration_callback(self, callback: Callable[[Tool], None]) -> None:
        """Add a callback to be executed when tools are registered."""
        if callable(callback):
            self.registration_callbacks.append(callback)
        else:
            raise TypeError("Callback must be callable")
    
    def get_tool(self, name: str, track_usage: bool = True) -> Optional[Tool]:
        """
        Get a tool by name.
        
        Args:
            name: Name of the tool
            track_usage: Whether to track this tool access in statistics
            
        Returns:
            Tool instance or None if not found
        """
        with self._lock:
            tool = self._tools.get(name)
            if tool and track_usage:
                self._tool_usage_stats[name] += 1
            return tool
    
    def get_tools(self, sort_by: Optional[str] = None) -> List[Tool]:
        """
        Get all registered tools.
        
        Args:
            sort_by: Optional sorting criterion ('name', 'usage', 'priority')
            
        Returns:
            List of Tool instances
        """
        with self._lock:
            tools = list(self._tools.values())
            
            if sort_by == "name":
                tools.sort(key=lambda t: t.name)
            elif sort_by == "usage":
                tools.sort(key=lambda t: self._tool_usage_stats.get(t.name, 0), reverse=True)
            elif sort_by == "priority":
                tools.sort(
                    key=lambda t: self._tool_metadata.get(t.name, {}).get("priority", 0),
                    reverse=True
                )
            
            return tools
    
    def list_tools(self) -> List[str]:
        """Get list of registered tool names."""
        with self._lock:
            return list(self._tools.keys())
    
    def get_tools_by_category(self, category: str) -> List[Tool]:
        """Get tools filtered by category (if tools have category metadata)."""
        with self._lock:
            return [
                tool for tool in self._tools.values()
                if (hasattr(tool, "category") and tool.category == category) or
                   (self._tool_metadata.get(tool.name, {}).get("category") == category)
            ]
    
    def get_tools_by_tag(self, tag: str) -> List[Tool]:
        """
        Get tools filtered by tag in metadata.
        
        Args:
            tag: Tag to filter by
            
        Returns:
            List of tools with the specified tag
        """
        with self._lock:
            return [
                tool for tool in self._tools.values()
                if tag in self._tool_metadata.get(tool.name, {}).get("tags", [])
            ]
    
    def search_tools(self, query: str, search_metadata: bool = True) -> List[Tool]:
        """
        Search tools by name, description, or metadata.
        
        Args:
            query: Search query string
            search_metadata: Whether to also search in tool metadata
            
        Returns:
            List of matching tools
        """
        with self._lock:
            query_lower = query.lower()
            results = []
            
            for tool in self._tools.values():
                # Search in name and description
                if query_lower in tool.name.lower() or query_lower in tool.description.lower():
                    results.append(tool)
                # Search in metadata if enabled
                elif search_metadata and tool.name in self._tool_metadata:
                    metadata_str = str(self._tool_metadata[tool.name]).lower()
                    if query_lower in metadata_str:
                        results.append(tool)
            
            return results
    
    def get_tool_usage_stats(self) -> Dict[str, int]:
        """
        Get usage statistics for all tools.
        
        Returns:
            Dictionary mapping tool names to usage counts
        """
        with self._lock:
            return dict(self._tool_usage_stats)
    
    def get_most_used_tools(self, limit: int = 5) -> List[tuple[str, int]]:
        """
        Get the most frequently used tools.
        
        Args:
            limit: Maximum number of tools to return
            
        Returns:
            List of (tool_name, usage_count) tuples sorted by usage
        """
        with self._lock:
            sorted_stats = sorted(
                self._tool_usage_stats.items(),
                key=lambda x: x[1],
                reverse=True
            )
            return sorted_stats[:limit]
    
    def reset_usage_stats(self) -> None:
        """Reset all usage statistics."""
        with self._lock:
            self._tool_usage_stats.clear()
            logger.info("Tool usage statistics reset")
    
    def get_tool_metadata(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Get metadata for a specific tool.
        
        Args:
            name: Tool name
            
        Returns:
            Metadata dictionary or None if not found
        """
        with self._lock:
            return self._tool_metadata.get(name)
    
    def update_tool_metadata(self, name: str, metadata: Dict[str, Any], merge: bool = True) -> bool:
        """
        Update metadata for a tool.
        
        Args:
            name: Tool name
            metadata: New metadata
            merge: If True, merge with existing metadata; if False, replace
            
        Returns:
            True if updated, False if tool not found
        """
        with self._lock:
            if name not in self._tools:
                return False
            
            if merge and name in self._tool_metadata:
                self._tool_metadata[name].update(metadata)
            else:
                self._tool_metadata[name] = metadata
            
            return True
    
    def get_tools_info(self) -> Dict[str, Dict[str, Any]]:
        """
        Get comprehensive information about all registered tools.
        
        Returns:
            Dictionary with tool details including name, description, usage, metadata
        """
        with self._lock:
            info = {}
            for name, tool in self._tools.items():
                info[name] = {
                    "name": tool.name,
                    "description": tool.description,
                    "usage_count": self._tool_usage_stats.get(name, 0),
                    "metadata": self._tool_metadata.get(name, {}),
                    "has_schema": hasattr(tool, "schema") and tool.schema is not None,
                }
            return info
    
    def bulk_register_tools(self, tools: List[Tool], metadata_list: Optional[List[Dict[str, Any]]] = None) -> Dict[str, bool]:
        """
        Register multiple tools at once.
        
        Args:
            tools: List of Tool instances
            metadata_list: Optional list of metadata dicts (must match tools length)
            
        Returns:
            Dictionary mapping tool names to registration success status
        """
        results = {}
        metadata_list = metadata_list or [None] * len(tools)
        
        if len(tools) != len(metadata_list):
            logger.error("Tools and metadata lists must have the same length")
            return {tool.name: False for tool in tools}
        
        for tool, metadata in zip(tools, metadata_list):
            results[tool.name] = self.register_tool(tool, metadata)
        
        return results
    
    def clear(self) -> None:
        """Clear all registered tools and reset statistics."""
        with self._lock:
            count = len(self._tools)
            self._tools.clear()
            self._tool_metadata.clear()
            self._tool_usage_stats.clear()
            logger.info(f"Registry cleared. Removed {count} tools.")
    
    def __len__(self) -> int:
        """Return the number of registered tools."""
        return len(self._tools)
    
    def __contains__(self, name: str) -> bool:
        """Check if a tool is registered."""
        return name in self._tools
    
    def __repr__(self) -> str:
        """String representation of the registry."""
        return f"<ToolRegistry: {len(self._tools)} tools registered>"
