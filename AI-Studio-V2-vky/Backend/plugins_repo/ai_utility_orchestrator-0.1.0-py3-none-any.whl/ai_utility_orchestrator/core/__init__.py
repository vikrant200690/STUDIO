# core/__init__.py

"""
AI Utility Orchestrator - Universal Core Module

This module provides the core functionality for building AI-powered agent systems
with dynamic tool registration and execution capabilities.
"""

from .agent_builder import agent_executor
from .agent_registry import ToolRegistry
from .tools import (
    Tool,
    ToolExecutionError,
    create_tool_from_function,
    create_tools_from_module,
    create_tools_from_object,
    register_function_as_tool,
    create_tool_decorator,
)

__version__ = "0.1.0"

__all__ = [
    # Main agent executor
    "agent_executor",
    
    # Registry
    "ToolRegistry",
    
    # Tool classes and exceptions
    "Tool",
    "ToolExecutionError",
    
    # Tool creation utilities
    "create_tool_from_function",
    "create_tools_from_module",
    "create_tools_from_object",
    "register_function_as_tool",
    "create_tool_decorator",
]

# Module metadata
__author__ = "AI Utility Orchestrator Team"
__description__ = "Universal AI agent orchestration framework with dynamic tool management"
