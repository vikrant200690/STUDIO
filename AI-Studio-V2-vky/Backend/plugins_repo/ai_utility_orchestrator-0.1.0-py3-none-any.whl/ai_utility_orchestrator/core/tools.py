# core/tools.py

"""
Universal Tool System
Dynamic, AI-powered tool interface that can adapt any function into a tool.
"""

from typing import Callable, Dict, Any, Optional, List, Union
import json
import logging
import inspect
from functools import wraps
from datetime import datetime
import time

logger = logging.getLogger(__name__)


class ToolExecutionError(Exception):
    """Custom exception for tool execution failures."""
    def __init__(self, tool_name: str, message: str, original_error: Optional[Exception] = None):
        self.tool_name = tool_name
        self.message = message
        self.original_error = original_error
        self.timestamp = datetime.utcnow().isoformat()
        super().__init__(f"Tool '{tool_name}' failed: {message}")


class Tool:
    """
    Universal tool class that can wrap any function.
    Completely dynamic with AI-enhanced capabilities.
    """
    
    def __init__(
        self,
        name: str,
        description: str,
        execute_func: Callable,
        schema: Optional[Dict[str, Any]] = None,
        category: str = "general",
        ai_enhanced: bool = True,
        version: str = "1.0.0",
        timeout: Optional[int] = None,
        retry_on_failure: bool = False,
        max_retries: int = 3,
    ):
        if not name or not name.strip():
            raise ValueError("Tool name cannot be empty")
        if not description or not description.strip():
            raise ValueError(f"Tool '{name}' must have a description")
        if not callable(execute_func):
            raise TypeError(f"execute_func for tool '{name}' must be callable")
        
        self.name = name.strip()
        self.description = description.strip()
        self._execute_func = execute_func
        self.schema = schema or self._generate_schema()
        self.category = category
        self.ai_enhanced = ai_enhanced
        self.version = version
        self.timeout = timeout
        self.retry_on_failure = retry_on_failure
        self.max_retries = max_retries
        
        # Execution statistics
        self._execution_count = 0
        self._success_count = 0
        self._failure_count = 0
        self._total_execution_time = 0.0
        self._last_execution_time: Optional[float] = None
        self._last_error: Optional[str] = None
    
    def _generate_schema(self) -> Dict[str, Any]:
        """Generate schema from function signature with type hints."""
        try:
            sig = inspect.signature(self._execute_func)
            properties = {}
            required = []
            
            for param_name, param in sig.parameters.items():
                # Skip context parameters that are injected
                if param_name in ["registry", "config", "context_manager", "user_id"]:
                    continue
                
                param_type = "string"  # default
                param_desc = f"Parameter: {param_name}"
                
                # Extract type from annotation
                if param.annotation != inspect.Parameter.empty:
                    annotation = param.annotation
                    if annotation == int:
                        param_type = "integer"
                    elif annotation == float:
                        param_type = "number"
                    elif annotation == bool:
                        param_type = "boolean"
                    elif annotation == list or annotation == List:
                        param_type = "array"
                    elif annotation == dict or annotation == Dict:
                        param_type = "object"
                    else:
                        param_type = "string"
                
                properties[param_name] = {
                    "type": param_type,
                    "description": param_desc
                }
                
                # Add to required if no default value
                if param.default == inspect.Parameter.empty:
                    required.append(param_name)
            
            return {
                "type": "object",
                "properties": properties,
                "required": required
            }
        except Exception as e:
            logger.warning(f"Could not generate schema for tool '{self.name}': {e}")
            return {"type": "object", "properties": {}, "required": []}
    
    def execute(self, params: Optional[Dict[str, Any]] = None) -> Any:
        """
        Execute the tool with given parameters.
        
        Args:
            params: Dictionary of parameters to pass to the function
            
        Returns:
            Result of the tool execution
            
        Raises:
            ToolExecutionError: If execution fails
        """
        params = params or {}
        start_time = time.time()
        self._execution_count += 1
        
        try:
            # Validate parameters against schema if available
            if self.schema and self.schema.get("required"):
                self._validate_params(params)
            
            # Execute with retry logic if enabled
            if self.retry_on_failure:
                result = self._execute_with_retry(params)
            else:
                result = self._execute_func(params) if self._accepts_dict() else self._execute_func(**params)
            
            # Update statistics
            execution_time = time.time() - start_time
            self._total_execution_time += execution_time
            self._last_execution_time = execution_time
            self._success_count += 1
            
            logger.info(f"Tool '{self.name}' executed successfully in {execution_time:.3f}s")
            return result
            
        except Exception as e:
            execution_time = time.time() - start_time
            self._total_execution_time += execution_time
            self._failure_count += 1
            self._last_error = str(e)
            
            logger.error(f"Tool '{self.name}' execution failed: {e}", exc_info=True)
            raise ToolExecutionError(self.name, str(e), original_error=e)
    
    def _accepts_dict(self) -> bool:
        """Check if the function accepts a single dict parameter."""
        try:
            sig = inspect.signature(self._execute_func)
            params = list(sig.parameters.values())
            
            # Check if single parameter that accepts dict
            if len(params) == 1:
                param = params[0]
                if param.annotation in [dict, Dict, Dict[str, Any]]:
                    return True
            return False
        except Exception:
            return False
    
    def _validate_params(self, params: Dict[str, Any]) -> None:
        """Validate parameters against schema."""
        required = self.schema.get("required", [])
        provided = set(params.keys())
        
        # Check for missing required parameters
        missing = set(required) - provided
        if missing:
            raise ValueError(f"Missing required parameters: {', '.join(missing)}")
        
        # Check for unknown parameters
        known = set(self.schema.get("properties", {}).keys())
        # Allow extra context parameters
        context_params = {"registry", "config", "context_manager", "user_id", "original_query"}
        unknown = provided - known - context_params
        
        if unknown:
            logger.warning(f"Unknown parameters provided to tool '{self.name}': {', '.join(unknown)}")
    
    def _execute_with_retry(self, params: Dict[str, Any]) -> Any:
        """Execute with retry logic."""
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                if self._accepts_dict():
                    return self._execute_func(params)
                else:
                    return self._execute_func(**params)
            except Exception as e:
                last_exception = e
                if attempt < self.max_retries - 1:
                    wait_time = 2 ** attempt  # Exponential backoff
                    logger.warning(
                        f"Tool '{self.name}' attempt {attempt + 1} failed, "
                        f"retrying in {wait_time}s: {e}"
                    )
                    time.sleep(wait_time)
                else:
                    logger.error(f"Tool '{self.name}' failed after {self.max_retries} attempts")
        
        raise last_exception
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get execution statistics for this tool."""
        avg_time = (
            self._total_execution_time / self._execution_count
            if self._execution_count > 0
            else 0.0
        )
        
        success_rate = (
            (self._success_count / self._execution_count * 100)
            if self._execution_count > 0
            else 0.0
        )
        
        return {
            "name": self.name,
            "total_executions": self._execution_count,
            "successful_executions": self._success_count,
            "failed_executions": self._failure_count,
            "success_rate": round(success_rate, 2),
            "average_execution_time": round(avg_time, 3),
            "last_execution_time": round(self._last_execution_time, 3) if self._last_execution_time else None,
            "last_error": self._last_error,
        }
    
    def reset_statistics(self) -> None:
        """Reset execution statistics."""
        self._execution_count = 0
        self._success_count = 0
        self._failure_count = 0
        self._total_execution_time = 0.0
        self._last_execution_time = None
        self._last_error = None
    
    @classmethod
    def from_function(
        cls,
        func: Callable,
        name: Optional[str] = None,
        description: Optional[str] = None,
        **kwargs
    ) -> 'Tool':
        """Create a Tool from any function."""
        tool_name = name or getattr(func, '__name__', None)
        if not tool_name:
            raise ValueError("Tool name must be provided or function must have __name__ attribute")
        
        tool_desc = description or func.__doc__
        if not tool_desc:
            raise ValueError(f"Tool description must be provided for tool '{tool_name}'")
        
        return cls(
            name=tool_name,
            description=tool_desc.strip(),
            execute_func=func,
            **kwargs
        )
    
    def __call__(self, *args, **kwargs) -> Any:
        """Allow tool to be called directly."""
        if args and not kwargs:
            # Assume single dict parameter
            return self.execute(args[0] if isinstance(args[0], dict) else {})
        return self.execute(kwargs)
    
    def __repr__(self) -> str:
        """String representation of the tool."""
        return (
            f"<Tool(name='{self.name}', category='{self.category}', "
            f"executions={self._execution_count})>"
        )


# Universal tool creation helpers

def create_tool_from_function(
    func: Callable,
    name: Optional[str] = None,
    description: Optional[str] = None,
    **kwargs
) -> Tool:
    """
    Create a tool from any function with AI-enhanced metadata.
    
    Args:
        func: The function to wrap
        name: Tool name (defaults to function name)
        description: Tool description (defaults to function docstring)
        **kwargs: Additional Tool constructor arguments
        
    Returns:
        Tool instance
    """
    return Tool.from_function(func, name, description, **kwargs)


def create_tools_from_module(
    module_name: str,
    filter_func: Optional[Callable[[str, Callable], bool]] = None,
    category: str = "general"
) -> List[Tool]:
    """
    Create tools from all functions in a module.
    
    Args:
        module_name: Name of the module to import
        filter_func: Optional function to filter which functions to include
        category: Category to assign to all tools from this module
        
    Returns:
        List of Tool instances
    """
    import importlib
    tools = []
    
    try:
        module = importlib.import_module(module_name)
        
        for name in dir(module):
            if name.startswith('_'):
                continue
            
            try:
                attr = getattr(module, name)
                
                if not callable(attr):
                    continue
                
                # Apply filter if provided
                if filter_func and not filter_func(name, attr):
                    continue
                
                # Skip if no docstring
                if not attr.__doc__:
                    logger.debug(f"Skipping '{name}' - no docstring")
                    continue
                
                tool = Tool.from_function(attr, name=name, category=category)
                tools.append(tool)
                logger.info(f"Created tool '{name}' from module '{module_name}'")
                
            except Exception as e:
                logger.warning(f"Could not create tool from '{name}': {e}")
        
        logger.info(f"Created {len(tools)} tools from module '{module_name}'")
        
    except Exception as e:
        logger.error(f"Could not import module '{module_name}': {e}")
    
    return tools


def create_tools_from_object(
    obj: Any,
    method_filter: Optional[Callable[[str], bool]] = None,
    category: str = "general"
) -> List[Tool]:
    """
    Create tools from all methods of an object.
    
    Args:
        obj: Object to extract methods from
        method_filter: Optional function to filter method names
        category: Category to assign to all tools
        
    Returns:
        List of Tool instances
    """
    tools = []
    class_name = obj.__class__.__name__
    
    for name in dir(obj):
        if name.startswith('_'):
            continue
        
        try:
            attr = getattr(obj, name)
            
            if not callable(attr):
                continue
            
            # Apply filter if provided
            if method_filter and not method_filter(name):
                continue
            
            # Skip if no docstring
            if not attr.__doc__:
                logger.debug(f"Skipping method '{name}' - no docstring")
                continue
            
            tool_name = f"{class_name}.{name}"
            tool = Tool.from_function(attr, name=tool_name, category=category)
            tools.append(tool)
            logger.info(f"Created tool '{tool_name}'")
            
        except Exception as e:
            logger.warning(f"Could not create tool from method '{name}': {e}")
    
    logger.info(f"Created {len(tools)} tools from object '{class_name}'")
    return tools


def register_function_as_tool(
    registry,
    func: Callable,
    metadata: Optional[Dict[str, Any]] = None,
    **kwargs
) -> Tool:
    """
    Register any function as a tool in the registry.
    
    Args:
        registry: ToolRegistry instance
        func: Function to register
        metadata: Optional metadata for the registry
        **kwargs: Additional Tool constructor arguments
        
    Returns:
        Created Tool instance
    """
    tool = Tool.from_function(func, **kwargs)
    registry.register_tool(tool, metadata=metadata)
    return tool


def create_tool_decorator(
    registry,
    category: str = "general",
    **tool_kwargs
) -> Callable:
    """
    Create a decorator for registering functions as tools.
    
    Example:
        @create_tool_decorator(my_registry, category="utilities")
        def my_function(x: int) -> int:
            '''Doubles a number'''
            return x * 2
    
    Args:
        registry: ToolRegistry instance
        category: Category for registered tools
        **tool_kwargs: Additional Tool constructor arguments
        
    Returns:
        Decorator function
    """
    def decorator(func: Callable) -> Callable:
        tool = Tool.from_function(func, category=category, **tool_kwargs)
        registry.register_tool(tool)
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        
        return wrapper
    
    return decorator
