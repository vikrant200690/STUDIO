"""
AI Utility Orchestrator - Universal AI-powered tool orchestration framework.

A completely dynamic, AI-driven orchestration system that adapts to any project.
No hardcoding, fully universal, and intelligently adaptive.

Key Features:
- Universal tool registration from any function
- AI-powered tool discovery and selection
- Dynamic schema generation
- Modular and extensible architecture
- Works with any AI project without modification

Usage:
    >>> from ai_utility_orchestrator import agent_executor, ToolRegistry
    >>> registry = ToolRegistry()
    >>> result = agent_executor(query="your task", tools=registry.get_tools())

Documentation:
    For full documentation, visit: https://github.com/yourusername/ai-utility-orchestrator

License:
    MIT License - See LICENSE file for details
"""

import logging
from typing import TYPE_CHECKING

# Package metadata
__version__ = "0.1.0"
__author__ = "Your Name"
__license__ = "MIT"

# Configure package-level logger
logger = logging.getLogger(__name__)

# Type checking imports (not executed at runtime)
if TYPE_CHECKING:
    from ai_utility_orchestrator.core.agent_builder import agent_executor as _agent_executor
    from ai_utility_orchestrator.core.agent_registry import ToolRegistry as _ToolRegistry
    from ai_utility_orchestrator.core.tools import (
        Tool as _Tool,
        create_tool_from_function as _create_tool_from_function,
        create_tools_from_module as _create_tools_from_module,
        create_tools_from_object as _create_tools_from_object,
        register_function_as_tool as _register_function_as_tool
    )
    from ai_utility_orchestrator.utils.toolkit import ConfigUtils as _ConfigUtils
    from ai_utility_orchestrator.utils.context_manager import ContextManager as _ContextManager
    from ai_utility_orchestrator.utils.response_formatter import format_response as _format_response


# Lazy imports to avoid side effects and improve startup time
def __getattr__(name):
    """
    Lazy import mechanism for package components.
    
    This ensures imports only happen when actually used, improving startup time
    and avoiding side effects during package initialization.
    
    Args:
        name: Attribute name being accessed
        
    Returns:
        The requested module attribute
        
    Raises:
        AttributeError: If the requested attribute doesn't exist
    """
    # Core components
    if name == "agent_executor":
        from ai_utility_orchestrator.core.agent_builder import agent_executor
        return agent_executor
    
    elif name == "ToolRegistry":
        from ai_utility_orchestrator.core.agent_registry import ToolRegistry
        return ToolRegistry
    
    elif name == "Tool":
        from ai_utility_orchestrator.core.tools import Tool
        return Tool
    
    # Universal tool creation functions
    elif name == "create_tool_from_function":
        from ai_utility_orchestrator.core.tools import create_tool_from_function
        return create_tool_from_function
    
    elif name == "create_tools_from_module":
        from ai_utility_orchestrator.core.tools import create_tools_from_module
        return create_tools_from_module
    
    elif name == "create_tools_from_object":
        from ai_utility_orchestrator.core.tools import create_tools_from_object
        return create_tools_from_object
    
    elif name == "register_function_as_tool":
        from ai_utility_orchestrator.core.tools import register_function_as_tool
        return register_function_as_tool
    
    # Utility components
    elif name == "ConfigUtils":
        from ai_utility_orchestrator.utils.toolkit import ConfigUtils
        return ConfigUtils
    
    elif name == "ContextManager":
        from ai_utility_orchestrator.utils.context_manager import ContextManager
        return ContextManager
    
    elif name == "format_response":
        from ai_utility_orchestrator.utils.response_formatter import format_response
        return format_response
    
    # Handle special attributes
    elif name in ("__version__", "__author__", "__license__"):
        return globals()[name]
    
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


# Define public API explicitly
__all__ = [
    # Core components
    'agent_executor',
    'ToolRegistry',
    'Tool',
    
    # Universal tool creation
    'create_tool_from_function',
    'create_tools_from_module',
    'create_tools_from_object',
    'register_function_as_tool',
    
    # Utilities
    'ConfigUtils',
    'ContextManager',
    'format_response',
    
    # Metadata
    '__version__',
]


# Optional: Provide a convenience function for quick setup
def quick_start(config_path=None, log_level=logging.INFO):
    """
    Quick start function to initialize the orchestrator with sensible defaults.
    
    Args:
        config_path: Optional path to configuration file
        log_level: Logging level (default: INFO)
        
    Returns:
        Tuple of (agent_executor, ToolRegistry instance)
        
    Example:
        >>> executor, registry = quick_start()
        >>> registry.register_tool(my_function)
        >>> result = executor("Do something", tools=registry.get_tools())
    """
    # Configure logging
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Load config if provided
    if config_path:
        from ai_utility_orchestrator.utils.toolkit import ConfigUtils
        config = ConfigUtils.load_config(config_path)
        logger.info(f"Loaded configuration from: {config_path}")
    
    # Import and return core components
    from ai_utility_orchestrator.core.agent_builder import agent_executor
    from ai_utility_orchestrator.core.agent_registry import ToolRegistry
    
    registry = ToolRegistry()
    logger.info("AI Utility Orchestrator initialized successfully")
    
    return agent_executor, registry


# Optional: Provide version checking utility
def check_dependencies():
    """
    Check if all optional dependencies are installed.
    
    Returns:
        Dictionary with dependency status
    """
    dependencies = {}
    
    # Check OpenAI
    try:
        import openai
        dependencies['openai'] = {
            'installed': True,
            'version': getattr(openai, '__version__', 'unknown')
        }
    except ImportError:
        dependencies['openai'] = {'installed': False}
    
    # Check LangChain
    try:
        import langchain
        dependencies['langchain'] = {
            'installed': True,
            'version': getattr(langchain, '__version__', 'unknown')
        }
    except ImportError:
        dependencies['langchain'] = {'installed': False}
    
    # Check other optional dependencies
    for lib in ['pydantic', 'tiktoken', 'anthropic', 'groq']:
        try:
            mod = __import__(lib)
            dependencies[lib] = {
                'installed': True,
                'version': getattr(mod, '__version__', 'unknown')
            }
        except ImportError:
            dependencies[lib] = {'installed': False}
    
    return dependencies


# Prevent wildcard import issues
def __dir__():
    """Return list of public attributes for tab completion."""
    return __all__
