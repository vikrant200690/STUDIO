"""
Universal logging module with multi-backend support and async capabilities.

This module provides:
- Structured logging with JSON formatting
- Async-safe logging with queue handlers
- Multiple database backend support (MongoDB, PostgreSQL, Neo4j, Snowflake)
- Automatic exception logging
- Framework integrations (Flask, FastAPI)
- Rotating file handlers
"""

import json
import logging
import sys
import traceback
from collections.abc import Callable
from contextlib import suppress
from datetime import datetime, timezone
from logging.handlers import QueueHandler, QueueListener, RotatingFileHandler
from pathlib import Path
from queue import Queue
from typing import Any, Literal

# Database clients
from neo4j import GraphDatabase
from neo4j.exceptions import Neo4jError
from pymongo import MongoClient
from pymongo.errors import PyMongoError
import psycopg2
from psycopg2 import DatabaseError as PostgresError, OperationalError
import snowflake.connector
from snowflake.connector.errors import DatabaseError as SnowflakeError


# ================= Type Aliases =================

LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
LogFormat = Literal["json", "text"]
DatabaseType = Literal["mongodb", "postgresql", "neo4j", "snowflake"]


# ================= Exceptions =================

class LoggerError(Exception):
    """Base exception for logger errors."""
    pass


class DatabaseHandlerError(LoggerError):
    """Raised when database handler setup fails."""
    pass


# ================= JSON Formatter =================

class JsonFormatter(logging.Formatter):
    """Custom JSON formatter for structured logging."""
    
    def __init__(
        self,
        json_formatter_func: Callable[[logging.LogRecord], str],
        **kwargs: Any
    ) -> None:
        """
        Initialize JSON formatter.
        
        Args:
            json_formatter_func: Function to format log records as JSON
            **kwargs: Additional formatter arguments
        """
        super().__init__(**kwargs)
        self.json_formatter_func = json_formatter_func

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        return self.json_formatter_func(record)


# ================= Universal Logger =================

class UniversalLogger:
    """
    Universal logger with multi-backend support and async capabilities.
    
    Features:
    - Structured JSON logging
    - Async-safe with queue handlers
    - Rotating file handlers
    - Multiple database backends
    - Automatic exception logging
    """
    
    def __init__(
        self,
        name: str,
        log_file: str | Path = "app.log",
        log_level: LogLevel = "INFO",
        max_file_size: int = 5 * 1024 * 1024,  # 5MB
        backup_count: int = 3,
        log_format: LogFormat = "json",
        console_output: bool = True,
        async_safe: bool = True,
        log_dir: str | Path | None = None,
    ) -> None:
        """
        Initialize the universal logger.
        
        Args:
            name: Logger name
            log_file: Log file path
            log_level: Logging level
            max_file_size: Maximum log file size before rotation
            backup_count: Number of backup files to keep
            log_format: Log format (json or text)
            console_output: Enable console output
            async_safe: Enable async-safe logging with queues
            log_dir: Directory for log files (created if doesn't exist)
        """
        self.name = name
        self.log_format = log_format
        self.async_safe = async_safe
        
        # Set up log directory
        if log_dir:
            log_path = Path(log_dir) / log_file
            log_path.parent.mkdir(parents=True, exist_ok=True)
        else:
            log_path = Path(log_file)
        
        self.log_file = log_path
        
        # Create logger
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
        self.logger.propagate = False  # Prevent duplicate logs
        
        # Set up handlers
        if not self.logger.handlers:
            self._setup_handlers(
                console_output=console_output,
                max_file_size=max_file_size,
                backup_count=backup_count,
            )
    
    def _setup_handlers(
        self,
        console_output: bool,
        max_file_size: int,
        backup_count: int,
    ) -> None:
        """Set up logging handlers."""
        
        # Create formatter
        formatter = self._create_formatter()
        
        # Create handlers
        handlers: list[logging.Handler] = []
        
        if console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(formatter)
            handlers.append(console_handler)
        
        # File handler with rotation
        file_handler = RotatingFileHandler(
            self.log_file,
            maxBytes=max_file_size,
            backupCount=backup_count,
            encoding="utf-8",
        )
        file_handler.setFormatter(formatter)
        handlers.append(file_handler)
        
        # Set up async-safe logging if enabled
        if self.async_safe:
            log_queue: Queue = Queue(-1)
            queue_handler = QueueHandler(log_queue)
            
            self.queue_listener = QueueListener(
                log_queue,
                *handlers,
                respect_handler_level=True
            )
            self.queue_listener.start()
            self.logger.addHandler(queue_handler)
        else:
            for handler in handlers:
                self.logger.addHandler(handler)
    
    def _create_formatter(self) -> logging.Formatter:
        """Create log formatter based on format type."""
        
        if self.log_format == "json":
            return JsonFormatter(self._json_formatter)
        else:
            return logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - '
                '%(filename)s:%(lineno)d - %(message)s'
            )
    
    def _json_formatter(self, record: logging.LogRecord) -> str:
        """
        Format log record as JSON.
        
        Args:
            record: Log record to format
        
        Returns:
            JSON-formatted log string
        """
        # Core log fields
        log_record: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "filename": record.filename,
            "lineno": record.lineno,
            "thread": record.threadName,
            "thread_id": record.thread,
            "process": record.process,
        }
        
        # Add extra fields if present
        if hasattr(record, 'extra') and record.extra:
            log_record.update(record.extra)
        
        # Add exception info if present
        if record.exc_info:
            log_record["exception"] = {
                "type": record.exc_info[0].__name__,
                "message": str(record.exc_info[1]),
                "traceback": "".join(
                    traceback.format_exception(*record.exc_info)
                ),
            }
        
        return json.dumps(log_record, default=str)
    
    def log(
        self,
        level: LogLevel,
        message: str,
        extra: dict[str, Any] | None = None,
        exc_info: bool = False,
    ) -> None:
        """
        Log a message at specified level.
        
        Args:
            level: Log level
            message: Log message
            extra: Extra fields to include in log
            exc_info: Include exception info
        """
        try:
            log_level = getattr(logging, level.upper(), logging.INFO)
            self.logger.log(
                log_level,
                message,
                extra={"extra": extra} if extra else None,
                exc_info=exc_info,
            )
        except Exception as e:
            print(f"[Logger Error] {e}", file=sys.stderr)
    
    def debug(
        self,
        message: str,
        extra: dict[str, Any] | None = None
    ) -> None:
        """Log debug message."""
        self.log("DEBUG", message, extra=extra)
    
    def info(
        self,
        message: str,
        extra: dict[str, Any] | None = None
    ) -> None:
        """Log info message."""
        self.log("INFO", message, extra=extra)
    
    def warning(
        self,
        message: str,
        extra: dict[str, Any] | None = None
    ) -> None:
        """Log warning message."""
        self.log("WARNING", message, extra=extra)
    
    def error(
        self,
        message: str,
        extra: dict[str, Any] | None = None
    ) -> None:
        """Log error message."""
        self.log("ERROR", message, extra=extra)
    
    def critical(
        self,
        message: str,
        extra: dict[str, Any] | None = None
    ) -> None:
        """Log critical message."""
        self.log("CRITICAL", message, extra=extra)
    
    def exception(
        self,
        message: str,
        extra: dict[str, Any] | None = None
    ) -> None:
        """Log exception with traceback."""
        self.log("ERROR", message, extra=extra, exc_info=True)
    
    def add_db_handler(
        self,
        db_type: DatabaseType,
        config: dict[str, Any],
        table_or_collection: str = "logs",
    ) -> None:
        """
        Add database handler for logging to a database.
        
        Args:
            db_type: Database type
            config: Database connection configuration
            table_or_collection: Table/collection name for logs
        
        Raises:
            DatabaseHandlerError: If handler setup fails
        """
        db_type_lower = db_type.lower()
        
        try:
            handler = self._create_db_handler(
                db_type_lower,
                config,
                table_or_collection
            )
            
            if handler:
                handler.setFormatter(JsonFormatter(self._json_formatter))
                
                if hasattr(self, 'queue_listener'):
                    # Add to queue listener handlers
                    self.queue_listener.handlers += (handler,)
                else:
                    self.logger.addHandler(handler)
                
                self.info(
                    f"Database handler added",
                    extra={"db_type": db_type, "table": table_or_collection}
                )
            
        except Exception as e:
            raise DatabaseHandlerError(
                f"Failed to add {db_type} handler: {e}"
            ) from e
    
    def _create_db_handler(
        self,
        db_type: str,
        config: dict[str, Any],
        table_or_collection: str,
    ) -> logging.Handler | None:
        """Create database-specific handler."""
        
        match db_type:
            case "mongodb":
                return self._create_mongodb_handler(config, table_or_collection)
            case "postgresql":
                return self._create_postgresql_handler(config, table_or_collection)
            case "neo4j":
                return self._create_neo4j_handler(config, table_or_collection)
            case "snowflake":
                return self._create_snowflake_handler(config, table_or_collection)
            case _:
                raise ValueError(f"Unsupported database type: {db_type}")
    
    def _create_mongodb_handler(
        self,
        config: dict[str, Any],
        collection_name: str,
    ) -> logging.Handler:
        """Create MongoDB logging handler."""
        
        client = MongoClient(config["uri"])
        collection = client[config["database"]][collection_name]
        
        class MongoHandler(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                try:
                    log_entry = self.format(record)
                    collection.insert_one(json.loads(log_entry))
                except PyMongoError as e:
                    print(f"[MongoDB Error] {e}", file=sys.stderr)
        
        return MongoHandler()
    
    def _create_postgresql_handler(
        self,
        config: dict[str, Any],
        table_name: str,
    ) -> logging.Handler:
        """Create PostgreSQL logging handler."""
        
        conn = psycopg2.connect(**config)
        cursor = conn.cursor()
        
        # Create table if not exists
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {table_name} (
                id SERIAL PRIMARY KEY,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                log_data JSONB NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_{table_name}_timestamp 
            ON {table_name}(timestamp);
        """)
        conn.commit()
        
        class PostgresHandler(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                try:
                    log_entry = self.format(record)
                    cursor.execute(
                        f"INSERT INTO {table_name} (log_data) VALUES (%s)",
                        [log_entry]
                    )
                    conn.commit()
                except (OperationalError, PostgresError) as e:
                    print(f"[PostgreSQL Error] {e}", file=sys.stderr)
        
        return PostgresHandler()
    
    def _create_neo4j_handler(
        self,
        config: dict[str, Any],
        label: str,
    ) -> logging.Handler:
        """Create Neo4j logging handler."""
        
        driver = GraphDatabase.driver(
            config["uri"],
            auth=(config["username"], config["password"])
        )
        
        class Neo4jHandler(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                try:
                    log_entry = self.format(record)
                    with driver.session() as session:
                        session.run(
                            f"CREATE (l:{label} {{log_data: $log_data}})",
                            log_data=log_entry
                        )
                except Neo4jError as e:
                    print(f"[Neo4j Error] {e}", file=sys.stderr)
        
        return Neo4jHandler()
    
    def _create_snowflake_handler(
        self,
        config: dict[str, Any],
        table_name: str,
    ) -> logging.Handler:
        """Create Snowflake logging handler."""
        
        conn = snowflake.connector.connect(**config)
        cursor = conn.cursor()
        
        # Create table if not exists
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {table_name} (
                id INTEGER AUTOINCREMENT PRIMARY KEY,
                timestamp TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
                log_data VARIANT
            )
        """)
        
        class SnowflakeHandler(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                try:
                    log_entry = self.format(record)
                    cursor.execute(
                        f"INSERT INTO {table_name} (log_data) VALUES (PARSE_JSON(%s))",
                        (log_entry,)
                    )
                    conn.commit()
                except SnowflakeError as e:
                    print(f"[Snowflake Error] {e}", file=sys.stderr)
        
        return SnowflakeHandler()
    
    def get_handlers(self) -> list[logging.Handler]:
        """
        Get all active handlers.
        
        Returns:
            List of logging handlers
        """
        if hasattr(self, 'queue_listener'):
            return list(self.queue_listener.handlers)
        else:
            return list(self.logger.handlers)
    
    def shutdown(self) -> None:
        """Gracefully shutdown logger and cleanup resources."""
        
        # Flush all handlers
        for handler in self.logger.handlers:
            handler.flush()
            if hasattr(handler, 'close'):
                handler.close()
        
        # Stop queue listener if async
        if hasattr(self, 'queue_listener'):
            self.queue_listener.stop()
        
        self.info("Logger shutdown complete")
    
    def __enter__(self) -> "UniversalLogger":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.shutdown()


# ================= Auto-logging Utilities =================

def auto_log_exceptions(logger: UniversalLogger) -> None:
    """
    Set global exception hook to log uncaught exceptions.
    
    Args:
        logger: UniversalLogger instance
    
    Example:
        >>> logger = UniversalLogger("app")
        >>> auto_log_exceptions(logger)
    """
    def handle_exception(
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_traceback: Any,
    ) -> None:
        # Don't log KeyboardInterrupt
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        
        logger.exception(
            f"Uncaught exception: {exc_value}",
            extra={
                "exception_type": exc_type.__name__,
                "exception_value": str(exc_value),
            }
        )
    
    sys.excepthook = handle_exception


def auto_log_function(
    logger: UniversalLogger,
    level: LogLevel = "INFO"
) -> Callable:
    """
    Decorator to log function entry, exit, and exceptions.
    
    Args:
        logger: UniversalLogger instance
        level: Log level for function calls
    
    Returns:
        Decorator function
    
    Example:
        >>> @auto_log_function(logger)
        ... def my_function(x, y):
        ...     return x + y
    """
    def decorator(func: Callable) -> Callable:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            func_name = func.__name__
            
            logger.log(
                level,
                f"Calling {func_name}",
                extra={
                    "function": func_name,
                    "args": str(args)[:100],  # Limit length
                    "kwargs": str(kwargs)[:100],
                }
            )
            
            try:
                result = func(*args, **kwargs)
                logger.log(
                    level,
                    f"{func_name} returned",
                    extra={
                        "function": func_name,
                        "result": str(result)[:100],
                    }
                )
                return result
            except Exception as e:
                logger.exception(
                    f"Exception in {func_name}",
                    extra={"function": func_name}
                )
                raise
        
        return wrapper
    return decorator


def auto_log_standard(logger: UniversalLogger) -> None:
    """
    Attach logger handlers to root logger for standard logging capture.
    
    Args:
        logger: UniversalLogger instance
    
    Example:
        >>> logger = UniversalLogger("app")
        >>> auto_log_standard(logger)
        >>> import logging
        >>> logging.info("This will be captured")
    """
    root_logger = logging.getLogger()
    
    for handler in logger.get_handlers():
        if handler not in root_logger.handlers:
            root_logger.addHandler(handler)


def auto_log_fastapi(app: Any, logger: UniversalLogger) -> None:
    """
    Add logging middleware to FastAPI application.
    
    Args:
        app: FastAPI application instance
        logger: UniversalLogger instance
    
    Example:
        >>> from fastapi import FastAPI
        >>> app = FastAPI()
        >>> logger = UniversalLogger("api")
        >>> auto_log_fastapi(app, logger)
    """
    from fastapi import Request
    from starlette.middleware.base import BaseHTTPMiddleware
    import time
    
    class LoggingMiddleware(BaseHTTPMiddleware):
        async def dispatch(
            self,
            request: Request,
            call_next: Callable
        ) -> Any:
            # Log request
            logger.info(
                "HTTP Request",
                extra={
                    "path": request.url.path,
                    "method": request.method,
                    "query_params": dict(request.query_params),
                    "client_host": request.client.host if request.client else None,
                    "user_agent": request.headers.get("user-agent"),
                }
            )
            
            start_time = time.perf_counter()
            
            try:
                response = await call_next(request)
            except Exception as exc:
                logger.exception(
                    "HTTP Exception",
                    extra={"path": request.url.path, "method": request.method}
                )
                raise
            
            process_time = time.perf_counter() - start_time
            
            # Log response
            logger.info(
                "HTTP Response",
                extra={
                    "path": request.url.path,
                    "method": request.method,
                    "status_code": response.status_code,
                    "process_time": f"{process_time:.3f}s",
                }
            )
            
            return response
    
    app.add_middleware(LoggingMiddleware)


def auto_log_flask(app: Any, logger: UniversalLogger) -> None:
    """
    Add logging hooks to Flask application.
    
    Args:
        app: Flask application instance
        logger: UniversalLogger instance
    
    Example:
        >>> from flask import Flask
        >>> app = Flask(__name__)
        >>> logger = UniversalLogger("api")
        >>> auto_log_flask(app, logger)
    """
    from flask import request
    
    @app.before_request
    def log_request() -> None:
        logger.info(
            "HTTP Request",
            extra={
                "path": request.path,
                "method": request.method,
                "query_args": request.args.to_dict(),
                "remote_addr": request.remote_addr,
                "user_agent": request.user_agent.string,
            }
        )
    
    @app.after_request
    def log_response(response: Any) -> Any:
        logger.info(
            "HTTP Response",
            extra={
                "path": request.path,
                "method": request.method,
                "status": response.status,
            }
        )
        return response
    
    @app.teardown_request
    def log_exception(exc: Exception | None) -> None:
        if exc:
            logger.exception(
                "HTTP Exception",
                extra={"path": request.path, "method": request.method}
            )


# ================= Convenience Functions =================

def create_logger(
    name: str,
    **kwargs: Any
) -> UniversalLogger:
    """
    Convenience function to create a logger.
    
    Args:
        name: Logger name
        **kwargs: Additional logger configuration
    
    Returns:
        Configured UniversalLogger instance
    
    Example:
        >>> logger = create_logger("my_app", log_level="DEBUG")
    """
    return UniversalLogger(name, **kwargs)
