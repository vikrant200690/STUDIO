"""
Universal Logging Package

A comprehensive logging solution with:
- Structured JSON logging
- Async-safe queue handlers
- Multiple database backend support (MongoDB, PostgreSQL, Neo4j, Snowflake)
- Rotating file handlers
- Framework integrations (Flask, FastAPI)
- Automatic exception logging
- Function call logging decorators

Example:
    >>> from logging_utils import create_logger, auto_log_exceptions
    >>> 
    >>> logger = create_logger("my_app", log_level="INFO")
    >>> auto_log_exceptions(logger)
    >>> 
    >>> logger.info("Application started", extra={"user": "admin"})
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__license__ = "MIT"


# ================= Core Imports =================

from .logging_utils import (
    # Main Logger Class
    UniversalLogger,
    
    # Formatters
    JsonFormatter,
    
    # Exceptions
    LoggerError,
    DatabaseHandlerError,
    
    # Auto-logging Utilities
    auto_log_exceptions,
    auto_log_function,
    auto_log_standard,
    auto_log_flask,
    auto_log_fastapi,
    
    # Convenience Functions
    create_logger,
    
    # Type Aliases
    LogLevel,
    LogFormat,
    DatabaseType,
)


# ================= Public API =================

__all__ = [
    # Main Classes
    "UniversalLogger",
    "JsonFormatter",
    
    # Exceptions
    "LoggerError",
    "DatabaseHandlerError",
    
    # Auto-logging Utilities
    "auto_log_exceptions",
    "auto_log_function",
    "auto_log_standard",
    "auto_log_flask",
    "auto_log_fastapi",
    
    # Convenience Functions
    "create_logger",
    "quick_logger",
    "get_default_logger",
    
    # Type Aliases
    "LogLevel",
    "LogFormat",
    "DatabaseType",
]


# ================= Package Information =================

__package_info__ = {
    "name": "logging_utils",
    "version": __version__,
    "description": "Universal logging with multi-backend support and framework integrations",
    "author": __author__,
    "license": __license__,
    "features": [
        "Structured JSON logging",
        "Async-safe queue handlers",
        "Rotating file handlers",
        "Multiple database backends (MongoDB, PostgreSQL, Neo4j, Snowflake)",
        "Framework integrations (Flask, FastAPI)",
        "Automatic exception logging",
        "Function call logging decorators",
        "Context manager support",
        "Thread-safe operations",
    ],
    "supported_databases": [
        "MongoDB",
        "PostgreSQL",
        "Neo4j",
        "Snowflake",
    ],
    "supported_frameworks": [
        "FastAPI",
        "Flask",
    ],
}


# ================= Convenience Functions =================

def quick_logger(
    name: str = "app",
    log_level: LogLevel = "INFO",
    log_to_console: bool = True,
    log_to_file: bool = False,
    log_file: str = "app.log",
) -> UniversalLogger:
    """
    Create a logger with minimal configuration.
    
    Args:
        name: Logger name
        log_level: Logging level
        log_to_console: Enable console output
        log_to_file: Enable file output
        log_file: Log file path if file logging enabled
    
    Returns:
        Configured UniversalLogger instance
    
    Example:
        >>> logger = quick_logger("my_app", log_level="DEBUG")
        >>> logger.info("Hello world!")
    """
    return UniversalLogger(
        name=name,
        log_level=log_level,
        console_output=log_to_console,
        log_file=log_file if log_to_file else "temp.log",
        async_safe=True,
    )


# Global default logger instance
_default_logger: UniversalLogger | None = None


def get_default_logger() -> UniversalLogger:
    """
    Get or create the default logger instance.
    
    Returns:
        Default UniversalLogger instance
    
    Example:
        >>> from logging_utils import get_default_logger
        >>> logger = get_default_logger()
        >>> logger.info("Using default logger")
    """
    global _default_logger
    
    if _default_logger is None:
        _default_logger = UniversalLogger(
            name="default",
            log_level="INFO",
            console_output=True,
            async_safe=True,
        )
    
    return _default_logger


def setup_application_logging(
    app_name: str,
    log_level: LogLevel = "INFO",
    log_dir: str = "logs",
    enable_db_logging: bool = False,
    db_config: dict[str, Any] | None = None,
) -> UniversalLogger:
    """
    Set up comprehensive application logging.
    
    Args:
        app_name: Application name
        log_level: Logging level
        log_dir: Directory for log files
        enable_db_logging: Enable database logging
        db_config: Database configuration if enabled
    
    Returns:
        Configured UniversalLogger instance
    
    Example:
        >>> logger = setup_application_logging(
        ...     "my_app",
        ...     log_level="DEBUG",
        ...     log_dir="/var/log/myapp"
        ... )
    """
    from pathlib import Path
    
    # Create logger
    logger = UniversalLogger(
        name=app_name,
        log_level=log_level,
        log_dir=log_dir,
        log_file=f"{app_name}.log",
        console_output=True,
        async_safe=True,
        max_file_size=10 * 1024 * 1024,  # 10MB
        backup_count=5,
    )
    
    # Set up database logging if configured
    if enable_db_logging and db_config:
        try:
            logger.add_db_handler(
                db_type=db_config["type"],
                config=db_config["config"],
                table_or_collection=db_config.get("table", "logs"),
            )
        except Exception as e:
            logger.error(f"Failed to set up database logging: {e}")
    
    # Set up automatic exception logging
    auto_log_exceptions(logger)
    
    # Capture standard library logging
    auto_log_standard(logger)
    
    logger.info(
        f"Application logging initialized",
        extra={
            "app_name": app_name,
            "log_level": log_level,
            "log_dir": log_dir,
        }
    )
    
    return logger


def get_version() -> str:
    """
    Get package version.
    
    Returns:
        Version string
    """
    return __version__


def print_package_info() -> None:
    """Print detailed package information."""
    info = __package_info__
    
    print(f"\n{'='*70}")
    print(f"{info['name'].upper()} v{info['version']}")
    print(f"{'='*70}")
    print(f"\n{info['description']}\n")
    
    print("Features:")
    for feature in info['features']:
        print(f"  • {feature}")
    
    print(f"\nSupported Databases: {', '.join(info['supported_databases'])}")
    print(f"Supported Frameworks: {', '.join(info['supported_frameworks'])}")
    print(f"\n{'='*70}\n")


def quick_start_example() -> str:
    """
    Get quick start example code.
    
    Returns:
        Example code as string
    """
    return '''
# Quick Start Example

from logging_utils import create_logger, auto_log_exceptions, auto_log_function

# Create logger
logger = create_logger("my_app", log_level="INFO")

# Set up automatic exception logging
auto_log_exceptions(logger)

# Use decorator for function logging
@auto_log_function(logger)
def my_function(x, y):
    return x + y

# Basic logging
logger.info("Application started", extra={"user": "admin"})
logger.debug("Debug information", extra={"data": {"key": "value"}})
logger.error("An error occurred", extra={"error_code": 500})

# Exception logging
try:
    raise ValueError("Something went wrong")
except Exception:
    logger.exception("Caught exception")

# Database logging (optional)
logger.add_db_handler(
    db_type="mongodb",
    config={"uri": "mongodb://localhost:27017", "database": "logs"},
    table_or_collection="app_logs"
)

# FastAPI integration
from fastapi import FastAPI
from logging_utils import auto_log_fastapi

app = FastAPI()
auto_log_fastapi(app, logger)

# Context manager usage
with create_logger("temp_logger") as temp_logger:
    temp_logger.info("Temporary logging session")
# Logger automatically shut down after context
'''


def validate_dependencies() -> dict[str, bool]:
    """
    Validate that optional dependencies are installed.
    
    Returns:
        Dictionary of dependency availability
    """
    dependencies = {
        "pymongo": False,
        "psycopg2": False,
        "neo4j": False,
        "snowflake-connector-python": False,
        "fastapi": False,
        "flask": False,
    }
    
    # Check each dependency
    for package in dependencies:
        try:
            __import__(package.replace("-", "_"))
            dependencies[package] = True
        except ImportError:
            pass
    
    return dependencies


def print_dependency_status() -> None:
    """Print status of optional dependencies."""
    deps = validate_dependencies()
    
    print("\n" + "="*70)
    print("Dependency Status")
    print("="*70)
    
    print("\nCore dependencies (always available):")
    print("  ✓ logging (stdlib)")
    print("  ✓ json (stdlib)")
    print("  ✓ pathlib (stdlib)")
    
    print("\nOptional dependencies:")
    
    db_deps = ["pymongo", "psycopg2", "neo4j", "snowflake-connector-python"]
    print("\n  Database backends:")
    for dep in db_deps:
        status = "✓" if deps[dep] else "✗"
        print(f"    {status} {dep}")
    
    framework_deps = ["fastapi", "flask"]
    print("\n  Framework integrations:")
    for dep in framework_deps:
        status = "✓" if deps[dep] else "✗"
        print(f"    {status} {dep}")
    
    print("\n" + "="*70 + "\n")


def get_supported_features() -> dict[str, list[str]]:
    """
    Get list of supported features based on installed dependencies.
    
    Returns:
        Dictionary mapping feature categories to available options
    """
    deps = validate_dependencies()
    
    features: dict[str, list[str]] = {
        "log_formats": ["json", "text"],
        "handlers": ["console", "file", "rotating_file", "queue"],
        "databases": [],
        "frameworks": [],
    }
    
    # Check database support
    if deps["pymongo"]:
        features["databases"].append("mongodb")
    if deps["psycopg2"]:
        features["databases"].append("postgresql")
    if deps["neo4j"]:
        features["databases"].append("neo4j")
    if deps["snowflake-connector-python"]:
        features["databases"].append("snowflake")
    
    # Check framework support
    if deps["fastapi"]:
        features["frameworks"].append("fastapi")
    if deps["flask"]:
        features["frameworks"].append("flask")
    
    return features


# ================= Type Imports for External Use =================

# Re-export types for easier access
from typing import Any


# ================= Module Initialization =================

def _initialize_module() -> None:
    """Initialize module on import."""
    import logging
    
    # Set up module logger
    module_logger = logging.getLogger(__name__)
    module_logger.info(f"Logging Utils v{__version__} loaded")


# Run initialization
_initialize_module()


# ================= CLI Entry Point =================

def main() -> None:
    """
    CLI entry point for package information.
    
    Usage:
        python -m logging_utils
    """
    import sys
    
    if len(sys.argv) > 1:
        match sys.argv[1]:
            case "--version":
                print(f"logging_utils v{__version__}")
            case "--info":
                print_package_info()
            case "--deps" | "--dependencies":
                print_dependency_status()
            case "--example":
                print(quick_start_example())
            case "--features":
                features = get_supported_features()
                print("\nSupported Features:")
                for category, items in features.items():
                    print(f"\n{category.replace('_', ' ').title()}:")
                    for item in items:
                        print(f"  • {item}")
            case _:
                print(f"Unknown command: {sys.argv[1]}")
                print("\nAvailable commands:")
                print("  --version       Show version")
                print("  --info          Show package info")
                print("  --deps          Show dependency status")
                print("  --example       Show example code")
                print("  --features      Show supported features")
    else:
        print_package_info()
        print("\nFor quick start example, run:")
        print("  python -m logging_utils --example")


if __name__ == "__main__":
    main()
