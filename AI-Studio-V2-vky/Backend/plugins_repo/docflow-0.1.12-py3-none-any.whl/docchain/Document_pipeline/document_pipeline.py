"""Document processing pipeline with embedding generation and vector storage."""

import logging
import re
from pathlib import Path
from typing import Protocol
from contextlib import closing

import docx
import PyPDF2
import sqlite3
import pymongo
import snowflake.connector
import mysql.connector
import psycopg2
from dotenv import load_dotenv
from openai import OpenAI


# Load environment variables
load_dotenv()


# Initialize OpenAI client
client = OpenAI()  # Automatically reads OPENAI_API_KEY from env


# Logging setup with structured format
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger("document_pipeline")


# ---------------------- File Reading ----------------------
def read_file(file_path: str | Path) -> str:
    """Read content from text, PDF, or DOCX files."""
    path = Path(file_path)
    logger.info(f"Reading file: {path}")
    
    match path.suffix.lower():
        case ".txt":
            return path.read_text(encoding="utf-8")
        case ".pdf":
            with path.open("rb") as f:
                reader = PyPDF2.PdfReader(f)
                return "\n".join(
                    page.extract_text() 
                    for page in reader.pages 
                    if page.extract_text()
                )
        case ".docx":
            doc = docx.Document(path)
            return "\n".join(p.text for p in doc.paragraphs)
        case _:
            raise ValueError(f"Unsupported file type: {path.suffix}")


# ---------------------- Cleaning ----------------------
def clean_text(text: str) -> str:
    """Normalize whitespace in text."""
    return re.sub(r"\s+", " ", text).strip()


# ---------------------- Chunking ----------------------
def chunk_text(text: str, max_tokens: int = 100) -> list[str]:
    """Split text into chunks based on sentence boundaries."""
    sentences = re.split(r'(?<=[.?!]) +', text)
    chunks: list[str] = []
    current = ""
    
    for sentence in sentences:
        if len((current + sentence).split()) <= max_tokens:
            current += " " + sentence
        else:
            if current:
                chunks.append(current.strip())
            current = sentence
    
    if current:
        chunks.append(current.strip())
    
    return chunks


# ---------------------- Embedding ----------------------
def embed_text(text: str) -> list[float]:
    """Generate embeddings using OpenAI API."""
    response = client.embeddings.create(
        input=[text],
        model="text-embedding-3-small"
    )
    return response.data[0].embedding


# ---------------------- Vector Store Protocol ----------------------
class VectorStore(Protocol):
    """Protocol defining vector storage interface."""
    
    def save(self, embeddings: list[list[float]], metadatas: list[dict]) -> None:
        """Save embeddings with metadata to storage."""
        ...


# ---------------------- Implementations ----------------------
class SQLiteVectorStore:
    """SQLite-based vector storage."""
    
    def __init__(self, db_path: str | Path = "vectors.db") -> None:
        self.db_path = Path(db_path)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS vectors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chunk TEXT NOT NULL,
                embedding TEXT NOT NULL,
                metadata TEXT NOT NULL
            )"""
        )
        self.conn.commit()

    def save(self, embeddings: list[list[float]], metadatas: list[dict]) -> None:
        """Save embeddings to SQLite database."""
        with closing(self.conn.cursor()) as cur:
            cur.executemany(
                "INSERT INTO vectors (chunk, embedding, metadata) VALUES (?, ?, ?)",
                [(meta["chunk"], str(emb), str(meta)) for emb, meta in zip(embeddings, metadatas)]
            )
        self.conn.commit()
    
    def __del__(self) -> None:
        """Close database connection on cleanup."""
        if hasattr(self, 'conn'):
            self.conn.close()


class MongoDBVectorStore:
    """MongoDB-based vector storage."""
    
    def __init__(
        self, 
        uri: str = "mongodb://localhost:27017", 
        db_name: str = "doc_db", 
        collection_name: str = "vectors"
    ) -> None:
        self.client = pymongo.MongoClient(uri)
        self.collection = self.client[db_name][collection_name]

    def save(self, embeddings: list[list[float]], metadatas: list[dict]) -> None:
        """Save embeddings to MongoDB collection."""
        docs = [{"embedding": emb, **meta} for emb, meta in zip(embeddings, metadatas)]
        self.collection.insert_many(docs)


class PostgresVectorStore:
    """PostgreSQL-based vector storage."""
    
    def __init__(self, host: str, user: str, password: str, dbname: str) -> None:
        self.conn = psycopg2.connect(
            host=host, 
            user=user, 
            password=password, 
            dbname=dbname
        )
        with closing(self.conn.cursor()) as cur:
            cur.execute(
                """CREATE TABLE IF NOT EXISTS vectors (
                    id SERIAL PRIMARY KEY,
                    chunk TEXT NOT NULL,
                    embedding TEXT NOT NULL,
                    metadata JSONB
                )"""
            )
        self.conn.commit()

    def save(self, embeddings: list[list[float]], metadatas: list[dict]) -> None:
        """Save embeddings to PostgreSQL table."""
        with closing(self.conn.cursor()) as cur:
            cur.executemany(
                "INSERT INTO vectors (chunk, embedding, metadata) VALUES (%s, %s, %s)",
                [(meta["chunk"], str(emb), str(meta)) for emb, meta in zip(embeddings, metadatas)]
            )
        self.conn.commit()
    
    def __del__(self) -> None:
        """Close database connection on cleanup."""
        if hasattr(self, 'conn'):
            self.conn.close()


class MySQLVectorStore:
    """MySQL-based vector storage."""
    
    def __init__(self, host: str, user: str, password: str, database: str) -> None:
        self.conn = mysql.connector.connect(
            host=host, 
            user=user, 
            password=password, 
            database=database
        )
        with closing(self.conn.cursor()) as cur:
            cur.execute(
                """CREATE TABLE IF NOT EXISTS vectors (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    chunk TEXT NOT NULL,
                    embedding TEXT NOT NULL,
                    metadata TEXT
                )"""
            )
        self.conn.commit()

    def save(self, embeddings: list[list[float]], metadatas: list[dict]) -> None:
        """Save embeddings to MySQL table."""
        with closing(self.conn.cursor()) as cur:
            cur.executemany(
                "INSERT INTO vectors (chunk, embedding, metadata) VALUES (%s, %s, %s)",
                [(meta["chunk"], str(emb), str(meta)) for emb, meta in zip(embeddings, metadatas)]
            )
        self.conn.commit()
    
    def __del__(self) -> None:
        """Close database connection on cleanup."""
        if hasattr(self, 'conn'):
            self.conn.close()


class SnowflakeVectorStore:
    """Snowflake-based vector storage."""
    
    def __init__(
        self, 
        user: str, 
        password: str, 
        account: str, 
        warehouse: str, 
        database: str, 
        schema: str
    ) -> None:
        self.conn = snowflake.connector.connect(
            user=user,
            password=password,
            account=account,
            warehouse=warehouse,
            database=database,
            schema=schema
        )
        with closing(self.conn.cursor()) as cur:
            cur.execute(
                """CREATE TABLE IF NOT EXISTS vectors (
                    id INTEGER AUTOINCREMENT,
                    chunk STRING,
                    embedding STRING,
                    metadata STRING
                )"""
            )

    def save(self, embeddings: list[list[float]], metadatas: list[dict]) -> None:
        """Save embeddings to Snowflake table."""
        with closing(self.conn.cursor()) as cur:
            cur.executemany(
                "INSERT INTO vectors (chunk, embedding, metadata) VALUES (%s, %s, %s)",
                [(meta["chunk"], str(emb), str(meta)) for emb, meta in zip(embeddings, metadatas)]
            )
    
    def __del__(self) -> None:
        """Close database connection on cleanup."""
        if hasattr(self, 'conn'):
            self.conn.close()


# ---------------------- Pipeline ----------------------
class DocumentPipeline:
    """Pipeline for processing documents into vector embeddings."""
    
    def __init__(self, vector_store: VectorStore) -> None:
        self.vector_store = vector_store

    def run(self, file_path: str | Path) -> None:
        """Execute the complete document processing pipeline."""
        try:
            path = Path(file_path)
            text = read_file(path)
            cleaned = clean_text(text)
            chunks = chunk_text(cleaned)
            
            logger.info(f"Generating embeddings for {len(chunks)} chunks")
            embeddings = [embed_text(chunk) for chunk in chunks]
            
            metadatas = [
                {"chunk": chunk, "chunk_index": i, "source": str(path)} 
                for i, chunk in enumerate(chunks)
            ]
            
            self.vector_store.save(embeddings, metadatas)
            logger.info(f"Successfully stored {len(chunks)} chunks from {path.name}")
            
        except Exception as e:
            logger.error(f"Pipeline failed for {file_path}: {e}", exc_info=True)
            raise


# ---------------------- Main Wrapper ----------------------
def process_file(
    file_path: str | Path, 
    vector_store: VectorStore | None = None
) -> None:
    """Process a document file and store embeddings."""
    path = Path(file_path)
    supported_extensions = {'.txt', '.pdf', '.docx'}

    if path.suffix.lower() not in supported_extensions:
        logger.error(f"Unsupported file type: {path.suffix}")
        return

    if not path.is_file():
        logger.error(f"File not found: {path}")
        return

    if vector_store is None:
        vector_store = SQLiteVectorStore("default_vectors.db")

    pipeline = DocumentPipeline(vector_store=vector_store)
    pipeline.run(path)


if __name__ == "__main__":
    # Example usage
    process_file("example.txt")
