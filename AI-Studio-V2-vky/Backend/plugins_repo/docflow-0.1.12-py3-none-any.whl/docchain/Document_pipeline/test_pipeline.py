"""Example script demonstrating document pipeline usage."""

from pathlib import Path
from document_pipeline import process_file


def main() -> None:
    """Main entry point for the script."""
    demo_file = Path("demo.pdf")
    
    if not demo_file.exists():
        print(f"Error: {demo_file} not found")
        return
    
    print(f"Processing {demo_file}...")
    process_file(demo_file)
    print("Processing complete!")


if __name__ == "__main__":
    main()
