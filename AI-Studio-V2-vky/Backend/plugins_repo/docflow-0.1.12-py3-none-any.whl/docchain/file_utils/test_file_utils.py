"""Test suite for UniversalFileHandler with local and cloud operations."""

from pathlib import Path
from typing import Any

from file_handler import UniversalFileHandler, CloudUploadError, load_credentials_from_env


# Setup directories
BASE_DIR = Path("test_uploaded_files")
INPUT_DIR = BASE_DIR / "input_files"
OUTPUT_DIR = BASE_DIR / "output"

INPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# Initialize handler
handler = UniversalFileHandler(default_dir=OUTPUT_DIR)


# Sample test files
SAMPLE_FILES = [
    "sample.txt",
    "sample1.json",
    "industry.csv",
    "sample1.yaml",
    "sample.pdf",
    "technology.docx"
]


def get_file_paths() -> list[Path]:
    """Get list of test file paths."""
    return [INPUT_DIR / filename for filename in SAMPLE_FILES]


def test_validate_files_default() -> None:
    """Test file validation with default settings."""
    print("\n=== Validate Each File (default) ===")
    
    for path in get_file_paths():
        try:
            handler.validate_file(path)
            print(f"✓ Validated: {path.name}")
        except Exception as e:
            print(f"✗ Validation failed: {path.name}, Error: {e}")


def test_validate_files_with_constraints() -> None:
    """Test file validation with extension and size constraints."""
    print("\n=== Validate Each File (allowed_exts, max_size_mb) ===")
    
    allowed_exts = [".txt", ".json", ".csv", ".yaml", ".pdf", ".docx"]
    
    for path in get_file_paths():
        try:
            handler.validate_file(path, allowed_exts=allowed_exts, max_size_mb=5)
            print(f"✓ Validated (ext/size): {path.name}")
        except Exception as e:
            print(f"✗ Validation (ext/size) failed: {path.name}, Error: {e}")


def test_validate_files_batch() -> None:
    """Test batch file validation."""
    print("\n=== Validate Files (batch) ===")
    
    allowed_exts = [".txt", ".json", ".csv", ".yaml", ".pdf", ".docx"]
    results = handler.validate_files(
        get_file_paths(), 
        allowed_exts=allowed_exts, 
        max_size_mb=5
    )
    
    for result in results:
        status_icon = "✓" if result['status'] == "valid" else "✗"
        print(f"{status_icon} {Path(result['file']).name} -> {result['status']}")


def test_read_files_individual() -> None:
    """Test reading individual files."""
    print("\n=== Read Each File ===")
    
    for path in get_file_paths():
        try:
            result = handler.read_file(path)
            num_lines = result['metadata'].get('num_lines', 'N/A')
            print(f"✓ Read: {path.name}, Lines: {num_lines}")
        except Exception as e:
            print(f"✗ Read failed: {path.name}, Error: {e}")


def test_read_files_batch() -> None:
    """Test batch file reading."""
    print("\n=== Read Files (batch) ===")
    
    results = handler.read_files(get_file_paths())
    
    for result in results:
        status_icon = "✓" if result['status'] == "success" else "✗"
        print(f"{status_icon} {Path(result['file']).name} -> {result['status']}")


def test_write_files_individual() -> None:
    """Test writing individual files."""
    print("\n=== Write Each File ===")
    
    for path in get_file_paths():
        try:
            result = handler.read_file(path)
            base = path.stem
            ext = path.suffix.lstrip(".")
            
            # Convert to txt for non-structured formats
            write_ext = "txt" if ext in ["txt", "docx", "pdf", "yaml"] else ext
            
            output = handler.write_file(
                result["content"],
                f"{base}_copy",
                ext=write_ext,
                save_dir=OUTPUT_DIR
            )
            print(f"✓ Written: {output.name}")
        except Exception as e:
            print(f"✗ Write failed: {path.name}, Error: {e}")


def test_write_files_batch() -> None:
    """Test batch file writing."""
    print("\n=== Write Files (batch) ===")
    
    data: list[dict[str, Any]] = []
    
    for path in get_file_paths():
        try:
            result = handler.read_file(path)
            data.append({
                "content": result["content"],
                "filename": f"{path.stem}_batch"
            })
        except Exception as e:
            print(f"✗ Failed to prepare: {path.name}, Error: {e}")
    
    results = handler.write_files(data, ext="txt", save_dir=OUTPUT_DIR)
    
    for result in results:
        status_icon = "✓" if result['status'] == "success" else "✗"
        print(f"{status_icon} {result['filename']} -> {result['status']}")


def test_remove_file() -> None:
    """Test file removal."""
    print("\n=== Remove Temp File ===")
    
    temp_path = OUTPUT_DIR / "temp.txt"
    temp_path.write_text("delete me", encoding="utf-8")
    
    try:
        handler.remove_file(temp_path)
        print("✓ Temp file removed successfully")
    except Exception as e:
        print(f"✗ Remove failed: {e}")


def test_upload_file_local() -> None:
    """Test local file upload."""
    print("\n=== Upload File (Local) ===")
    
    test_file = INPUT_DIR / "sample.txt"
    
    try:
        uploaded = handler.upload_file(
            test_file,
            storage_type="local",
            destination=OUTPUT_DIR
        )
        print(f"✓ Uploaded locally: {Path(uploaded).name}")
    except Exception as e:
        print(f"✗ Local upload failed: {e}")


def test_upload_files_batch_local() -> None:
    """Test batch local file upload."""
    print("\n=== Upload Files (Local, batch) ===")
    
    results = handler.upload_files(
        get_file_paths(),
        storage_type="local",
        destination=OUTPUT_DIR
    )
    
    for result in results:
        status_icon = "✓" if result['status'] == "success" else "✗"
        file_name = Path(result['file']).name
        print(f"{status_icon} {file_name} -> {result['status']}")


def test_cloud_credentials() -> None:
    """Test cloud credential detection from environment."""
    print("\n=== .env Credential Access ===")
    
    provider, creds = load_credentials_from_env()
    
    if provider:
        print(f"✓ Detected provider: {provider.upper()}, Credentials found")
        return provider, creds
    else:
        print("⚠ No provider credentials found in .env")
        return None, None


def test_cloud_upload(provider: str | None, creds: dict[str, str] | None) -> str | None:
    """Test cloud file upload."""
    print("\n=== Cloud Upload Using .env ===")
    
    import os
    bucket_name = os.getenv("AWS_BUCKET_NAME")
    test_file = INPUT_DIR / "sample.txt"
    
    if not (provider and creds and bucket_name):
        print("⚠ Skipping cloud upload: No credentials or bucket name")
        return None
    
    try:
        uploaded = handler.upload_file(
            test_file,
            storage_type="cloud",
            destination=bucket_name
        )
        print(f"✓ Uploaded to cloud ({provider.upper()}): {uploaded}")
        
        # Extract remote path
        remote_path = uploaded.replace("s3://", "").replace("gs://", "").replace("azure://", "")
        return remote_path
        
    except CloudUploadError as e:
        print(f"✗ Cloud upload failed: {e}")
        return None
    except Exception as e:
        print(f"✗ Cloud upload failed (unexpected): {e}")
        return None


def test_cloud_download(
    provider: str | None,
    creds: dict[str, str] | None,
    remote_path: str | None
) -> None:
    """Test cloud file download."""
    print("\n=== Cloud Download Using .env ===")
    
    if not (provider and creds and remote_path):
        print("⚠ Skipping cloud download: Upload path not found")
        return
    
    try:
        local_file = OUTPUT_DIR / f"downloaded_{Path(remote_path).name}"
        downloaded = handler.download_file(provider, creds, remote_path, local_file)
        print(f"✓ Downloaded from cloud: {downloaded.name}")
    except Exception as e:
        print(f"✗ Cloud download failed: {e}")


def run_tests() -> None:
    """Execute all test cases."""
    print("=" * 60)
    print("UniversalFileHandler Test Suite")
    print("=" * 60)
    
    # File validation tests
    test_validate_files_default()
    test_validate_files_with_constraints()
    test_validate_files_batch()
    
    # File reading tests
    test_read_files_individual()
    test_read_files_batch()
    
    # File writing tests
    test_write_files_individual()
    test_write_files_batch()
    
    # File removal test
    test_remove_file()
    
    # Local upload tests
    test_upload_file_local()
    test_upload_files_batch_local()
    
    # Cloud operation tests
    provider, creds = test_cloud_credentials()
    remote_path = test_cloud_upload(provider, creds)
    test_cloud_download(provider, creds, remote_path)
    
    print("\n" + "=" * 60)
    print("Test Suite Complete")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
