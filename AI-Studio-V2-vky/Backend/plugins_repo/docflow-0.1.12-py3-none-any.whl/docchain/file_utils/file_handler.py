"""Universal file handler supporting local and multi-cloud storage operations."""

import json
import os
import uuid
from pathlib import Path
from typing import Any, Literal

import boto3
import magic
import pandas as pd
import pytesseract
import yaml
from azure.storage.blob import BlobServiceClient
from docx import Document
from dotenv import load_dotenv
from google.cloud import storage as gcp_storage
from PIL import Image
from pydantic import BaseModel, Field, field_validator
from PyPDF2 import PdfReader


load_dotenv()


def config_loader(key: str, default: Any = None) -> str | None:
    """Load configuration value from environment variables."""
    return os.getenv(key, default)


# Custom Exceptions
class CloudUploadError(Exception):
    """Raised when cloud upload/download operations fail."""
    pass


class FileValidationError(Exception):
    """Raised when file validation fails."""
    pass


# Pydantic Models for Cloud Credentials
class AWSConnectionDetails(BaseModel):
    """AWS S3 connection configuration."""
    aws_access_key_id: str = Field(min_length=1)
    aws_secret_access_key: str = Field(min_length=1)
    region: str = Field(min_length=1)


class GCPConnectionDetails(BaseModel):
    """GCP Cloud Storage connection configuration."""
    service_account_json: str = Field(min_length=1)
    
    @field_validator("service_account_json")
    @classmethod
    def validate_json_path(cls, v: str) -> str:
        """Validate that service account JSON file exists."""
        if not Path(v).exists():
            raise ValueError(f"GCP service account JSON file not found: {v}")
        return v


class AzureConnectionDetails(BaseModel):
    """Azure Blob Storage connection configuration."""
    connection_string: str = Field(min_length=1)


# Type aliases
CloudProvider = Literal["aws", "gcp", "azure"]
StorageType = Literal["local", "cloud"]


class CloudConnectionValidator:
    """Validator for cloud provider connection details."""
    
    @staticmethod
    def validate(
        provider: str, 
        conn: dict[str, Any]
    ) -> AWSConnectionDetails | GCPConnectionDetails | AzureConnectionDetails:
        """Validate connection details for specified cloud provider."""
        match provider.lower():
            case "aws":
                return AWSConnectionDetails(**conn)
            case "gcp":
                return GCPConnectionDetails(**conn)
            case "azure":
                return AzureConnectionDetails(**conn)
            case _:
                raise ValueError(f"Unsupported cloud provider: {provider}")


def load_credentials_from_env() -> tuple[str | None, dict[str, str] | None]:
    """
    Auto-detect cloud provider and return credentials from environment.
    Priority order: AWS → GCP → Azure.
    
    Returns:
        Tuple of (provider_name, credentials_dict) or (None, None) if not found
    """
    # Check AWS
    if all([
        config_loader("AWS_ACCESS_KEY_ID"),
        config_loader("AWS_SECRET_ACCESS_KEY"),
        config_loader("AWS_REGION")
    ]):
        return "aws", {
            "aws_access_key_id": config_loader("AWS_ACCESS_KEY_ID"),
            "aws_secret_access_key": config_loader("AWS_SECRET_ACCESS_KEY"),
            "region": config_loader("AWS_REGION")
        }
    
    # Check GCP
    if config_loader("GCP_SERVICE_ACCOUNT_JSON"):
        return "gcp", {
            "service_account_json": config_loader("GCP_SERVICE_ACCOUNT_JSON")
        }
    
    # Check Azure
    if config_loader("AZURE_CONNECTION_STRING"):
        return "azure", {
            "connection_string": config_loader("AZURE_CONNECTION_STRING")
        }
    
    return None, None


class UniversalFileHandler:
    """Universal file handler for local and cloud storage operations."""
    
    def __init__(self, default_dir: str | Path = "uploaded_files") -> None:
        self.default_dir = Path(default_dir)
        self.default_dir.mkdir(parents=True, exist_ok=True)

    def upload_file(
        self,
        filepath: str | Path,
        storage_type: StorageType = "local",
        destination: str | Path | None = None,
        cloud_provider: str | None = None,
        connection_details: dict[str, str] | None = None
    ) -> str:
        """
        Upload a single file to local or cloud storage.
        
        Args:
            filepath: Path to the file to upload
            storage_type: Target storage type ("local" or "cloud")
            destination: Destination path/bucket/container name
            cloud_provider: Cloud provider name (aws/gcp/azure)
            connection_details: Cloud connection credentials
        
        Returns:
            Path or URI of uploaded file
        """
        path = Path(filepath)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        unique_name = f"{uuid.uuid4()}_{path.name}"
        
        if storage_type == "local":
            return str(self._upload_to_local(path, destination, unique_name))
        
        elif storage_type == "cloud":
            # Auto-detect credentials if not provided
            if not cloud_provider or not connection_details:
                auto_provider, auto_creds = load_credentials_from_env()
                if auto_provider and auto_creds:
                    cloud_provider = cloud_provider or auto_provider
                    connection_details = connection_details or auto_creds
                    print(f"[INFO] Using cloud provider from .env: {cloud_provider}")
                else:
                    print("[WARN] No cloud credentials found. Falling back to local upload.")
                    return str(self._upload_to_local(path, destination, unique_name))
            
            CloudConnectionValidator.validate(cloud_provider, connection_details)
            return self._upload_to_cloud(
                path, unique_name, cloud_provider.lower(), 
                destination, connection_details
            )
        
        else:
            raise ValueError(f"Invalid storage type: {storage_type}")

    def upload_files(
        self,
        filepaths: list[str | Path],
        storage_type: StorageType = "local",
        destination: str | Path | None = None,
        cloud_provider: str | None = None,
        connection_details: dict[str, str] | None = None
    ) -> list[dict[str, Any]]:
        """Upload multiple files with individual error handling."""
        results = []
        
        for filepath in filepaths:
            try:
                uploaded = self.upload_file(
                    filepath, storage_type, destination, 
                    cloud_provider, connection_details
                )
                results.append({
                    "file": str(filepath),
                    "status": "success",
                    "uploaded_as": uploaded
                })
            except Exception as e:
                results.append({
                    "file": str(filepath),
                    "status": "failed",
                    "error": str(e)
                })
        
        return results

    def _upload_to_local(
        self,
        filepath: Path,
        destination: str | Path | None,
        unique_name: str
    ) -> Path:
        """Upload file to local storage with version control."""
        target_dir = Path(destination) if destination else self.default_dir
        target_dir.mkdir(parents=True, exist_ok=True)
        
        # Handle versioning
        name, ext = filepath.stem, filepath.suffix
        version = 1
        candidate_path = target_dir / f"{name}{ext}"
        
        while candidate_path.exists():
            version += 1
            candidate_path = target_dir / f"{name}_v{version}{ext}"
        
        # Copy file
        candidate_path.write_bytes(filepath.read_bytes())
        
        print(f"[INFO] File saved as: {candidate_path.name}")
        return candidate_path

    def _upload_to_cloud(
        self,
        filepath: Path,
        unique_name: str,
        cloud_provider: str,
        destination: str | None,
        connection_details: dict[str, str]
    ) -> str:
        """Upload file to cloud storage."""
        try:
            match cloud_provider:
                case "aws":
                    return self._upload_to_aws(
                        filepath, unique_name, destination, connection_details
                    )
                case "gcp":
                    return self._upload_to_gcp(
                        filepath, unique_name, destination, connection_details
                    )
                case "azure":
                    return self._upload_to_azure(
                        filepath, unique_name, destination, connection_details
                    )
                case _:
                    raise NotImplementedError(
                        f"Unsupported cloud provider: {cloud_provider}"
                    )
        except Exception as e:
            raise CloudUploadError(
                f"{cloud_provider.capitalize()} upload failed: {e}"
            ) from e

    def _upload_to_aws(
        self,
        filepath: Path,
        unique_name: str,
        bucket_name: str,
        connection_details: dict[str, str]
    ) -> str:
        """Upload file to AWS S3."""
        required_keys = ['aws_access_key_id', 'aws_secret_access_key', 'region']
        
        for key in required_keys:
            if not connection_details.get(key):
                raise CloudUploadError(
                    f"Missing AWS credential: {key}. Check .env or connection_details."
                )
        
        s3 = boto3.client(
            's3',
            aws_access_key_id=connection_details['aws_access_key_id'],
            aws_secret_access_key=connection_details['aws_secret_access_key'],
            region_name=connection_details['region']
        )
        s3.upload_file(str(filepath), bucket_name, unique_name)
        return f"s3://{bucket_name}/{unique_name}"

    def _upload_to_gcp(
        self,
        filepath: Path,
        unique_name: str,
        bucket_name: str,
        connection_details: dict[str, str]
    ) -> str:
        """Upload file to GCP Cloud Storage."""
        client = gcp_storage.Client.from_service_account_json(
            connection_details['service_account_json']
        )
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(unique_name)
        blob.upload_from_filename(str(filepath))
        return f"gs://{bucket_name}/{unique_name}"

    def _upload_to_azure(
        self,
        filepath: Path,
        unique_name: str,
        container_name: str,
        connection_details: dict[str, str]
    ) -> str:
        """Upload file to Azure Blob Storage."""
        blob_service_client = BlobServiceClient.from_connection_string(
            connection_details['connection_string']
        )
        blob_client = blob_service_client.get_blob_client(
            container=container_name, blob=unique_name
        )
        
        with filepath.open("rb") as data:
            blob_client.upload_blob(data, overwrite=True)
        
        return f"azure://{container_name}/{unique_name}"

    def download_file(
        self,
        cloud_provider: str,
        connection_details: dict[str, str],
        remote_path: str,
        local_path: str | Path
    ) -> Path:
        """Download file from cloud storage to local path."""
        local = Path(local_path)
        local.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            CloudConnectionValidator.validate(cloud_provider, connection_details)
            
            match cloud_provider.lower():
                case "aws":
                    self._download_from_aws(remote_path, local, connection_details)
                case "gcp":
                    self._download_from_gcp(remote_path, local, connection_details)
                case "azure":
                    self._download_from_azure(remote_path, local, connection_details)
                case _:
                    raise NotImplementedError(
                        f"Unsupported cloud provider: {cloud_provider}"
                    )
            
            return local
            
        except Exception as e:
            raise CloudUploadError(
                f"{cloud_provider.capitalize()} download failed: {e}"
            ) from e

    def _download_from_aws(
        self,
        remote_path: str,
        local_path: Path,
        connection_details: dict[str, str]
    ) -> None:
        """Download file from AWS S3."""
        bucket, key = remote_path.split("/", 1)
        s3 = boto3.client(
            's3',
            aws_access_key_id=connection_details['aws_access_key_id'],
            aws_secret_access_key=connection_details['aws_secret_access_key'],
            region_name=connection_details['region']
        )
        s3.download_file(bucket, key, str(local_path))

    def _download_from_gcp(
        self,
        remote_path: str,
        local_path: Path,
        connection_details: dict[str, str]
    ) -> None:
        """Download file from GCP Cloud Storage."""
        bucket_name, blob_path = remote_path.split("/", 1)
        client = gcp_storage.Client.from_service_account_json(
            connection_details['service_account_json']
        )
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(blob_path)
        blob.download_to_filename(str(local_path))

    def _download_from_azure(
        self,
        remote_path: str,
        local_path: Path,
        connection_details: dict[str, str]
    ) -> None:
        """Download file from Azure Blob Storage."""
        container_name, blob_path = remote_path.split("/", 1)
        blob_service_client = BlobServiceClient.from_connection_string(
            connection_details['connection_string']
        )
        blob_client = blob_service_client.get_blob_client(
            container=container_name, blob=blob_path
        )
        
        local_path.write_bytes(blob_client.download_blob().readall())

    def validate_file(
        self,
        filepath: str | Path,
        allowed_exts: list[str] | None = None,
        max_size_mb: float = 50
    ) -> bool:
        """
        Validate file existence, type, and size.
        
        Args:
            filepath: Path to file to validate
            allowed_exts: List of allowed file extensions (e.g., ['.pdf', '.docx'])
            max_size_mb: Maximum file size in megabytes
        
        Returns:
            True if validation passes
        
        Raises:
            FileValidationError: If validation fails
        """
        path = Path(filepath)
        
        if not path.exists():
            raise FileValidationError(f"File not found: {path}")
        
        if allowed_exts and path.suffix.lower() not in allowed_exts:
            raise FileValidationError(
                f"Unsupported file type: {path.suffix}. Allowed: {allowed_exts}"
            )
        
        size_mb = path.stat().st_size / (1024 * 1024)
        if size_mb > max_size_mb:
            raise FileValidationError(
                f"File exceeds {max_size_mb} MB limit (actual: {size_mb:.2f} MB)"
            )
        
        return True

    def validate_files(
        self,
        filepaths: list[str | Path],
        allowed_exts: list[str] | None = None,
        max_size_mb: float = 50
    ) -> list[dict[str, Any]]:
        """Validate multiple files with individual error handling."""
        results = []
        
        for filepath in filepaths:
            try:
                self.validate_file(filepath, allowed_exts, max_size_mb)
                results.append({"file": str(filepath), "status": "valid"})
            except Exception as e:
                results.append({
                    "file": str(filepath),
                    "status": "invalid",
                    "error": str(e)
                })
        
        return results

    def remove_file(self, filepath: str | Path) -> bool:
        """Remove file from filesystem."""
        path = Path(filepath)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        path.unlink()
        return True

    def read_file(
        self,
        filepath: str | Path,
        encoding: str = "utf-8"
    ) -> dict[str, Any]:
        """
        Read file content with automatic format detection.
        
        Args:
            filepath: Path to file to read
            encoding: Text encoding (default: utf-8)
        
        Returns:
            Dict containing 'content' and 'metadata' keys
        """
        path = Path(filepath)
        
        try:
            mime_type = magic.from_file(str(path), mime=True)
            ext = path.suffix.lower()
            
            # Override MIME type for specific text formats
            if mime_type == "text/plain":
                match ext:
                    case ".json":
                        mime_type = "application/json"
                    case ".yaml" | ".yml":
                        mime_type = "application/x-yaml"
                    case ".csv":
                        mime_type = "text/csv"
            
            print(f"[INFO] Detected MIME type: {mime_type}")
            
            # Read content based on MIME type
            match mime_type:
                case "text/plain":
                    content = path.read_text(encoding=encoding)
                
                case "application/json":
                    with path.open("r", encoding=encoding) as f:
                        content = json.load(f)
                
                case "application/x-yaml" | "text/yaml":
                    with path.open("r", encoding=encoding) as f:
                        content = yaml.safe_load(f)
                
                case "text/csv":
                    content = pd.read_csv(path, encoding=encoding).to_dict(orient="records")
                
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                    doc = Document(path)
                    content = "\n".join(p.text for p in doc.paragraphs)
                
                case "application/pdf":
                    reader = PdfReader(path)
                    page_texts = []
                    
                    for idx, page in enumerate(reader.pages):
                        try:
                            text = page.extract_text()
                            page_texts.append(text if text else "")
                        except Exception as e:
                            print(f"[WARN] Skipping unreadable page {idx + 1}: {e}")
                            page_texts.append(f"[PAGE {idx + 1} UNREADABLE]")
                    
                    content = "\n".join(page_texts)
                
                case _:
                    raise ValueError(f"Unsupported MIME type: {mime_type}")
            
            # Prepare metadata
            metadata = {
                "filename": path.name,
                "size_kb": round(path.stat().st_size / 1024, 2),
                "filetype": mime_type
            }
            
            if isinstance(content, str):
                metadata["num_lines"] = content.count("\n") + 1
            
            return {"content": content, "metadata": metadata}
        
        except UnicodeDecodeError as e:
            raise RuntimeError(
                f"Encoding issue reading file. Try different encoding: {e}"
            ) from e
        except Exception as e:
            raise RuntimeError(f"Failed to read file: {e}") from e

    def read_files(
        self,
        filepaths: list[str | Path],
        encoding: str = "utf-8"
    ) -> list[dict[str, Any]]:
        """Read multiple files with individual error handling."""
        results = []
        
        for filepath in filepaths:
            try:
                data = self.read_file(filepath, encoding=encoding)
                results.append({
                    "file": str(filepath),
                    "status": "success",
                    "data": data
                })
            except Exception as e:
                results.append({
                    "file": str(filepath),
                    "status": "failed",
                    "error": str(e)
                })
        
        return results

    def write_file(
        self,
        content: Any,
        filename: str,
        ext: str = "txt",
        save_dir: str | Path | None = None
    ) -> Path:
        """
        Write content to file in specified format.
        
        Args:
            content: Content to write
            filename: Base filename (without extension)
            ext: File extension/format (txt, json, csv)
            save_dir: Directory to save file
        
        Returns:
            Path to saved file
        """
        target_dir = Path(save_dir) if save_dir else self.default_dir
        target_dir.mkdir(parents=True, exist_ok=True)
        save_path = target_dir / f"{filename}.{ext}"
        
        try:
            match ext:
                case "txt":
                    content_str = content if isinstance(content, str) else str(content)
                    save_path.write_text(content_str, encoding="utf-8")
                
                case "json":
                    with save_path.open("w", encoding="utf-8") as f:
                        json.dump(content, f, indent=2, ensure_ascii=False)
                
                case "csv":
                    if not isinstance(content, list):
                        raise ValueError("CSV writing expects list of dicts")
                    pd.DataFrame(content).to_csv(save_path, index=False)
                
                case _:
                    raise ValueError(f"Unsupported write format: .{ext}")
            
            return save_path
        
        except Exception as e:
            raise RuntimeError(f"Failed to write file: {e}") from e

    def write_files(
        self,
        file_data_list: list[dict[str, Any]],
        ext: str = "txt",
        save_dir: str | Path | None = None
    ) -> list[dict[str, Any]]:
        """Write multiple files with individual error handling."""
        results = []
        
        for file_data in file_data_list:
            try:
                path = self.write_file(
                    content=file_data["content"],
                    filename=file_data["filename"],
                    ext=ext,
                    save_dir=save_dir
                )
                results.append({
                    "filename": file_data["filename"],
                    "status": "success",
                    "saved_to": str(path)
                })
            except Exception as e:
                results.append({
                    "filename": file_data.get("filename", "unknown"),
                    "status": "failed",
                    "error": str(e)
                })
        
        return results
