"""Demo script for document embedding generation using multiple providers."""

from pathlib import Path
from typing import Any

from docchain.Embedding_utils.embedding import embedder_demo


def main() -> None:
    """Main entry point for embedding demo."""
    
    # Configuration parameters
    params: dict[str, Any] = {
        "doc_path": Path("Document_template.docx"),
        "provider": "Huggingface",
        "model": "sentence-transformer",
        "output_path": Path("test_output.txt"),
        "sentences_per_chunk": 3
    }
    
    # Validate input file exists
    doc_path = params["doc_path"]
    if isinstance(doc_path, Path) and not doc_path.exists():
        print(f"Error: Document file not found: {doc_path}")
        return
    
    print(f"Starting embedding generation for: {params['doc_path']}")
    print(f"Provider: {params['provider']}, Model: {params['model']}")
    
    try:
        # Convert Path objects to strings if needed for compatibility
        params_str = {
            k: str(v) if isinstance(v, Path) else v 
            for k, v in params.items()
        }
        embedder_demo(**params_str)
        print(f"Embeddings saved to: {params['output_path']}")
        
    except Exception as e:
        print(f"Error during embedding generation: {e}")
        raise


if __name__ == "__main__":
    main()
