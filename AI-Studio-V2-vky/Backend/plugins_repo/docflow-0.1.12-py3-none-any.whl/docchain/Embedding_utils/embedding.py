"""Multi-provider embedding generation system with file processing capabilities."""

import json
import logging
import traceback
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Self
from contextlib import suppress

from dotenv import load_dotenv


load_dotenv()


def config_loader(key: str, default: Any = None) -> str | None:
    """Load configuration value from environment."""
    import os
    return os.getenv(key, default)


def get_logger(name: str = "embedder", level: int = logging.INFO) -> logging.Logger:
    """Configure and return a logger instance."""
    logger = logging.getLogger(name)
    if not logger.hasHandlers():
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "[%(asctime)s] %(levelname)s - %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(level)
    return logger


# Custom Exception Hierarchy
class EmbeddingError(Exception):
    """Base exception for embedding operations."""
    pass


class InvalidConfigurationError(EmbeddingError):
    """Raised when configuration parameters are invalid."""
    pass


class FileProcessingError(EmbeddingError):
    """Raised when file processing fails."""
    pass


class ProviderNotAvailableError(EmbeddingError):
    """Raised when required provider package is not installed."""
    pass


# Import checks with lazy loading
_PROVIDER_AVAILABILITY: dict[str, bool] = {}


def check_provider_availability(provider: str) -> bool:
    """Check if provider package is available."""
    if provider in _PROVIDER_AVAILABILITY:
        return _PROVIDER_AVAILABILITY[provider]
    
    match provider.lower():
        case "openai":
            with suppress(ImportError):
                import openai
                _PROVIDER_AVAILABILITY["openai"] = True
                return True
        case "cohere":
            with suppress(ImportError):
                import cohere
                _PROVIDER_AVAILABILITY["cohere"] = True
                return True
        case "gemini":
            with suppress(ImportError):
                import google.generativeai
                _PROVIDER_AVAILABILITY["gemini"] = True
                return True
    
    _PROVIDER_AVAILABILITY[provider] = False
    return False


@dataclass
class UserConfig:
    """Configuration for embedding parameters with validation."""
    
    provider: str
    model: str | None = None
    max_tokens_per_batch: int = 1000
    sentences_per_chunk: int = 3
    batch_size: int = 100
    
    # Default models per provider
    _default_models: dict[str, str] = field(
        default_factory=lambda: {
            'openai': 'text-embedding-3-small',
            'cohere': 'embed-english-v3.0',
            'gemini': 'models/embedding-001'
        },
        init=False,
        repr=False
    )
    
    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        self.provider = self.provider.lower()
        
        # Validate provider
        if self.provider not in ['openai', 'cohere', 'gemini']:
            raise InvalidConfigurationError(f"Unsupported provider: {self.provider}")
        
        # Validate parameters
        if self.max_tokens_per_batch <= 0:
            raise InvalidConfigurationError("max_tokens_per_batch must be positive")
        if self.sentences_per_chunk <= 0:
            raise InvalidConfigurationError("sentences_per_chunk must be positive")
        if self.batch_size <= 0:
            raise InvalidConfigurationError("batch_size must be positive")
        
        # Set default model if not provided
        if not self.model:
            self.model = self._default_models.get(self.provider)


class Embedder:
    """Multi-provider embedding generation with file processing."""
    
    def __init__(self, user_config: UserConfig, api_key: str | None = None) -> None:
        self.logger = get_logger()
        self.config = user_config
        self.api_key = api_key or self._get_api_key(user_config.provider)
        self.model = user_config.model
        
        self._validate_provider()
        self._client = self._initialize_client()
        
        self.logger.info(f"Initialized {self.config.provider} embedder with model: {self.model}")

    def _get_api_key(self, provider: str) -> str:
        """Retrieve API key for the specified provider."""
        key = config_loader(f"{provider.upper()}_API_KEY")
        if not key:
            raise EmbeddingError(
                f"API key for provider '{provider}' not found. "
                f"Set {provider.upper()}_API_KEY environment variable."
            )
        return key

    def _validate_provider(self) -> None:
        """Validate that required provider package is available."""
        if not check_provider_availability(self.config.provider):
            package_names = {
                'openai': 'openai',
                'cohere': 'cohere',
                'gemini': 'google-generativeai'
            }
            pkg = package_names.get(self.config.provider, self.config.provider)
            raise ProviderNotAvailableError(
                f"{self.config.provider.title()} package not installed. "
                f"Install with: pip install {pkg}"
            )

    def _initialize_client(self) -> Any:
        """Initialize the appropriate client based on provider."""
        match self.config.provider:
            case 'openai':
                from openai import OpenAI
                return OpenAI(api_key=self.api_key)
            case 'cohere':
                import cohere
                return cohere.Client(self.api_key)
            case 'gemini':
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                return genai
            case _:
                raise EmbeddingError(f"Cannot initialize client for {self.config.provider}")

    def process_uploaded_file(
        self, 
        file_path: str | Path, 
        file_handler: Any = None
    ) -> dict[str, Any]:
        """
        Process an uploaded file and generate embeddings.
        
        Args:
            file_path: Path to the uploaded file
            file_handler: UniversalFileHandler instance (optional)
        
        Returns:
            Dict with embeddings, metadata, and processing info
        """
        path = Path(file_path)
        
        try:
            # Import file handler if not provided
            if file_handler is None:
                from docchain.file_utils.file_handler import UniversalFileHandler
                file_handler = UniversalFileHandler()
            
            self.logger.info(f"Processing file: {path}")
            
            # Read file content
            file_data = file_handler.read_file(str(path))
            content = file_data["content"]
            metadata = file_data["metadata"]
            
            self.logger.info(
                f"File read successfully. Type: {metadata['filetype']}, "
                f"Size: {metadata['size_kb']} KB"
            )
            
            # Extract and validate text content
            text_content = self._extract_text_content(content)
            
            if not text_content or not text_content.strip():
                raise FileProcessingError("No text content found in the file")
            
            # Chunk the text
            chunks = self._chunk_text(text_content)
            
            if not chunks:
                raise FileProcessingError("No chunks created from the text content")
            
            self.logger.info(f"Created {len(chunks)} chunks from the text")
            
            # Generate embeddings
            embeddings = self._generate_embeddings(chunks)
            
            # Prepare response
            return {
                "status": "success",
                "file_metadata": metadata,
                "embeddings": embeddings,
                "chunks": chunks,
                "processing_info": {
                    "provider_used": self.config.provider,
                    "model_used": self.model,
                    "total_chunks": len(chunks),
                    "embedding_dimension": len(embeddings[0]) if embeddings else 0,
                    "total_tokens_estimated": sum(
                        self._count_tokens(chunk) for chunk in chunks
                    ),
                    "configuration": {
                        "max_tokens_per_batch": self.config.max_tokens_per_batch,
                        "sentences_per_chunk": self.config.sentences_per_chunk,
                        "batch_size": self.config.batch_size
                    }
                }
            }
            
        except Exception as e:
            error_response = {
                "status": "error",
                "error": str(e),
                "error_type": type(e).__name__,
                "file_path": str(path),
                "traceback": traceback.format_exc()
            }
            self.logger.error(f"Error processing file {path}: {e}", exc_info=True)
            return error_response

    def _extract_text_content(self, content: Any) -> str:
        """Extract text content from various data types."""
        match content:
            case str():
                return content
            case list():
                return "\n".join(str(item) for item in content)
            case dict():
                return json.dumps(content, indent=2)
            case _:
                return str(content)

    def _chunk_text(self, text: str) -> list[str]:
        """Chunk text based on user configuration."""
        return sentence_chunk(text, sentences_per_chunk=self.config.sentences_per_chunk)

    def _generate_embeddings(self, chunks: list[str]) -> list[list[float]]:
        """Generate embeddings for text chunks."""
        self.logger.info(f"Generating embeddings for {len(chunks)} chunks")
        
        # Create batches based on token limits
        batches = self._token_based_batches(chunks, self.config.max_tokens_per_batch)
        results: list[list[float]] = []
        
        for i, batch in enumerate(batches):
            self.logger.info(f"Processing batch {i+1}/{len(batches)} with {len(batch)} chunks")
            
            match self.config.provider:
                case 'openai':
                    batch_results = self._embed_texts_openai(batch)
                case 'cohere':
                    batch_results = self._embed_texts_cohere(batch)
                case 'gemini':
                    batch_results = self._embed_texts_gemini(batch)
                case _:
                    raise EmbeddingError(f"Unknown provider: {self.config.provider}")
            
            results.extend(batch_results)
        
        return results

    def _embed_texts_openai(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings using OpenAI API."""
        results: list[list[float]] = []
        for i in range(0, len(texts), self.config.batch_size):
            batch = texts[i:i + self.config.batch_size]
            response = self._client.embeddings.create(input=batch, model=self.model)
            results.extend([item.embedding for item in response.data])
        return results

    def _embed_texts_cohere(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings using Cohere API."""
        results: list[list[float]] = []
        for i in range(0, len(texts), self.config.batch_size):
            batch = texts[i:i + self.config.batch_size]
            response = self._client.embed(
                texts=batch, 
                model=self.model, 
                input_type='search_document'
            )
            results.extend(response.embeddings)
        return results

    def _embed_texts_gemini(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings using Gemini API."""
        results: list[list[float]] = []
        for i in range(0, len(texts), self.config.batch_size):
            batch = texts[i:i + self.config.batch_size]
            embeddings = []
            for text in batch:
                response = self._client.embed_content(model=self.model, content=text)
                embeddings.append(response['embedding'])
            results.extend(embeddings)
        return results

    def _token_based_batches(
        self, 
        texts: list[str], 
        max_tokens: int
    ) -> list[list[str]]:
        """Create batches based on token count limits."""
        batches: list[list[str]] = []
        current_batch: list[str] = []
        current_tokens = 0
        
        for text in texts:
            tokens = self._count_tokens(text)
            if current_batch and current_tokens + tokens > max_tokens:
                batches.append(current_batch)
                current_batch = [text]
                current_tokens = tokens
            else:
                current_batch.append(text)
                current_tokens += tokens
        
        if current_batch:
            batches.append(current_batch)
        
        return batches

    def _count_tokens(self, text: str) -> int:
        """Count tokens in text using tiktoken or word approximation."""
        with suppress(ImportError, Exception):
            import tiktoken
            enc = tiktoken.get_encoding('cl100k_base')
            return len(enc.encode(text))
        
        # Fallback to word count approximation
        return len(text.split())


# Utility Functions
def sentence_chunk(text: str, sentences_per_chunk: int = 3) -> list[str]:
    """
    Chunk text by sentences.
    
    Args:
        text: Input text to chunk
        sentences_per_chunk: Number of sentences per chunk
    
    Returns:
        List of text chunks
    """
    import re
    
    if not text or not isinstance(text, str):
        return []
    
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]
    
    return [
        " ".join(sentences[i:i + sentences_per_chunk])
        for i in range(0, len(sentences), sentences_per_chunk)
    ]


def create_embedder_from_config(
    config_dict: dict[str, Any], 
    api_key: str | None = None
) -> Embedder:
    """Create embedder instance from configuration dictionary."""
    user_config = UserConfig(**config_dict)
    return Embedder(user_config, api_key)


def process_file_with_embeddings(
    file_path: str | Path, 
    config: dict[str, Any], 
    api_key: str | None = None,
    file_handler: Any = None
) -> dict[str, Any]:
    """
    Process uploaded file and generate embeddings.
    
    Args:
        file_path: Path to the uploaded file
        config: Configuration dict with provider, model, token limits, etc.
        api_key: Optional API key override
        file_handler: Optional file handler instance
    
    Returns:
        Dict with embeddings and processing info or error details
    """
    embedder = create_embedder_from_config(config, api_key)
    return embedder.process_uploaded_file(file_path, file_handler)


# Backward Compatibility Functions
def embed_texts(
    texts: str | list[str], 
    provider: str = "openai", 
    **kwargs: Any
) -> list[list[float]]:
    """
    Generate embeddings for texts (backward compatibility).
    
    Args:
        texts: Single text or list of texts
        provider: Embedding provider name
        **kwargs: Additional configuration parameters
    
    Returns:
        List of embedding vectors
    """
    config = {"provider": provider, **kwargs}
    embedder = create_embedder_from_config(config)
    
    if isinstance(texts, str):
        texts = [texts]
    
    return embedder._generate_embeddings(texts)


def create_embedder(provider: str = "openai", **kwargs: Any) -> Embedder:
    """
    Create embedder instance (backward compatibility).
    
    Args:
        provider: Embedding provider name
        **kwargs: Additional configuration parameters
    
    Returns:
        Embedder instance
    """
    config = {"provider": provider, **kwargs}
    return create_embedder_from_config(config)
