"""Test suite for memory utilities with unittest/pytest compatibility."""

import unittest
from typing import Any

import pytest
from pydantic import ValidationError

from real_tests.mocks import MockLLM
from memory_utils import (
    BufferMemory,
    EntityMemory,
    MemoryManager,
    ShortTermMemory,
    SummaryMemory,
    METADATA_TYPE,
    METADATA_USER_ID,
)


class TestShortTermMemory(unittest.TestCase):
    """Test cases for ShortTermMemory functionality."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.stm = ShortTermMemory()

    def test_set_and_get(self) -> None:
        """Test setting and retrieving values."""
        self.stm.set("foo", 123)
        assert self.stm.get("foo") == 123
        
        self.stm.set("bar", 456)
        assert self.stm.get("bar") == 456

    def test_clear(self) -> None:
        """Test clearing memory."""
        self.stm.set("foo", 123)
        self.stm.set("bar", 456)
        self.stm.clear()
        
        assert self.stm.get("foo") is None
        assert self.stm.get("bar") is None


class TestBufferMemory(unittest.TestCase):
    """Test cases for BufferMemory functionality."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.buffer = BufferMemory(buffer_size=3)

    def test_save_and_get_context(self) -> None:
        """Test saving and retrieving context."""
        self.buffer.save_context({"q": "hi"}, {"a": "hello"})
        self.buffer.save_context({"q": "bye"}, {"a": "goodbye"})
        
        assert len(self.buffer.get()) == 2

    def test_delete(self) -> None:
        """Test deleting specific context entry."""
        self.buffer.save_context({"q": "hi"}, {"a": "hello"})
        self.buffer.save_context({"q": "bye"}, {"a": "goodbye"})
        
        self.buffer.delete(0)
        assert len(self.buffer.get()) == 1

    def test_clear(self) -> None:
        """Test clearing all context."""
        self.buffer.save_context({"q": "hi"}, {"a": "hello"})
        self.buffer.clear()
        
        assert len(self.buffer.get()) == 0

    def test_save_context_batch(self) -> None:
        """Test batch context saving."""
        buf = BufferMemory(buffer_size=10)
        turns = [
            ({"user": "hi"}, {"ai": "hello"}),
            ({"user": "bye"}, {"ai": "goodbye"}),
            ({"user": "how are you?"}, {"ai": "I'm fine, thanks!"}),
        ]
        buf.save_context_batch(turns)
        
        assert len(buf.get()) == 3
        assert buf.get()[0]["inputs"] == {"user": "hi"}
        assert buf.get()[1]["outputs"] == {"ai": "goodbye"}
        assert buf.get()[2]["inputs"] == {"user": "how are you?"}

    def test_input_validation(self) -> None:
        """Test input validation for invalid types."""
        with pytest.raises(ValidationError):
            self.buffer.save_context("not a dict", {})


class TestSummaryMemory(unittest.TestCase):
    """Test cases for SummaryMemory functionality."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.summary_memory = SummaryMemory()

    def test_set_and_get(self) -> None:
        """Test setting and retrieving summary."""
        self.summary_memory.set("This is a summary.")
        assert self.summary_memory.get() == "This is a summary."

    def test_update_with_llm(self) -> None:
        """Test updating summary using LLM."""
        self.summary_memory.set("Initial summary.")
        llm = MockLLM(response="Updated summary.")
        self.summary_memory.update("New lines", llm)
        
        assert self.summary_memory.get() == "Updated summary."

    def test_clear(self) -> None:
        """Test clearing summary."""
        self.summary_memory.set("Test summary.")
        self.summary_memory.clear()
        
        assert self.summary_memory.get() is None

    def test_input_validation(self) -> None:
        """Test input validation for invalid types."""
        with pytest.raises(ValidationError):
            self.summary_memory.set(123)

    def test_update_requires_llm(self) -> None:
        """Test that update requires LLM parameter."""
        with pytest.raises(ValueError):
            self.summary_memory.update("test", None)


class TestEntityMemory(unittest.TestCase):
    """Test cases for EntityMemory functionality."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.entity_memory = EntityMemory()

    def test_set_and_get(self) -> None:
        """Test setting and retrieving entities."""
        self.entity_memory.set("person", "Aditya")
        assert self.entity_memory.get("person") == "Aditya"
        
        self.entity_memory.set("location", "Pune")
        assert self.entity_memory.get("location") == "Pune"

    def test_all_entities(self) -> None:
        """Test retrieving all entities."""
        self.entity_memory.set("person", "Aditya")
        self.entity_memory.set("location", "Pune")
        
        all_entities = self.entity_memory.all()
        assert all_entities["person"] == "Aditya"
        assert all_entities["location"] == "Pune"

    def test_clear(self) -> None:
        """Test clearing all entities."""
        self.entity_memory.set("person", "Aditya")
        self.entity_memory.clear()
        
        assert self.entity_memory.all() == {}

    def test_input_validation(self) -> None:
        """Test input validation for invalid key types."""
        with pytest.raises(ValidationError):
            self.entity_memory.set(123, "Aditya")

    def test_update_with_llm(self) -> None:
        """Test updating entities using LLM extraction."""
        llm = MockLLM(response='{"person": "Aditya", "location": "Pune"}')
        self.entity_memory.update("Human: Aditya\nAI: Hello Aditya!", llm)
        
        assert self.entity_memory.get("person") == "Aditya"
        assert self.entity_memory.get("location") == "Pune"

    def test_update_requires_llm(self) -> None:
        """Test that update requires LLM parameter."""
        with pytest.raises(ValueError):
            self.entity_memory.update("test", None)


class TestLLMCaching(unittest.TestCase):
    """Test cases for LLM caching functionality."""

    def test_cache_and_clear(self) -> None:
        """Test LLM response caching and cache clearing."""
        llm = MockLLM(response="cached!")
        prompt = "test prompt"
        
        # First call - cache miss
        result1 = llm.generate(prompt)
        assert result1 == "cached!"
        
        # Change response, but cached value should be returned
        llm.response = "should not see this"
        result2 = llm.generate(prompt)
        assert result2 == "cached!"
        
        # Clear cache and verify new response
        llm.clear_cache()
        result3 = llm.generate(prompt)
        assert result3 == "should not see this"


class TestMemoryManager(unittest.TestCase):
    """Test cases for MemoryManager orchestration."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.llm = MockLLM(response="summary")
        self.manager = MemoryManager(llm=self.llm)

    def test_save_and_load_context(self) -> None:
        """Test saving context and loading all memory types."""
        self.manager.save_context({"q": "hi"}, {"a": "hello"})
        memory = self.manager.load_memory()
        
        assert "history" in memory
        assert "summary" in memory
        assert "entities" in memory

    def test_clear_all(self) -> None:
        """Test clearing all memory types."""
        self.manager.save_context({"q": "hi"}, {"a": "hello"})
        self.manager.clear_all()
        
        memory = self.manager.load_memory()
        assert memory["history"] == []
        assert memory["summary"] is None
        assert memory["entities"] == {}

    def test_is_ready(self) -> None:
        """Test manager readiness status."""
        assert self.manager.is_ready() is True


class TestMetadataConstants(unittest.TestCase):
    """Test cases for metadata constants."""

    def test_metadata_keys(self) -> None:
        """Test metadata constant values."""
        metadata: dict[str, str] = {
            METADATA_USER_ID: "user123",
            METADATA_TYPE: "document"
        }
        
        assert metadata[METADATA_USER_ID] == "user123"
        assert metadata[METADATA_TYPE] == "document"


# Pytest-style test functions (alternative to unittest classes)
def test_short_term_memory_pytest_style() -> None:
    """Pytest-style test for ShortTermMemory."""
    stm = ShortTermMemory()
    stm.set("key", "value")
    
    assert stm.get("key") == "value"
    
    stm.clear()
    assert stm.get("key") is None


def test_buffer_memory_pytest_style() -> None:
    """Pytest-style test for BufferMemory."""
    buffer = BufferMemory(buffer_size=5)
    buffer.save_context({"input": "test"}, {"output": "result"})
    
    assert len(buffer.get()) == 1
    assert buffer.get()[0]["inputs"] == {"input": "test"}


# Parametrized pytest test
@pytest.mark.parametrize("key,value,expected", [
    ("name", "Alice", "Alice"),
    ("age", 30, 30),
    ("city", "Delhi", "Delhi"),
])
def test_short_term_memory_parametrized(key: str, value: Any, expected: Any) -> None:
    """Parametrized test for various data types in ShortTermMemory."""
    stm = ShortTermMemory()
    stm.set(key, value)
    assert stm.get(key) == expected


if __name__ == "__main__":
    # Run with unittest
    unittest.main()
