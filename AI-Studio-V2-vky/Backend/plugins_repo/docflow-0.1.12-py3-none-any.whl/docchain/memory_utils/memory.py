"""Memory management utilities for AI applications with multi-backend support."""

import json
import os
import textwrap
from collections.abc import Callable
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Protocol, Self

from pydantic import BaseModel, Field, ValidationError


# Optional imports with availability tracking
try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    redis = None
    REDIS_AVAILABLE = False

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OpenAI = None
    OPENAI_AVAILABLE = False


# Metadata key constants
METADATA_USER_ID = "user_id"
METADATA_SESSION_ID = "session_id"
METADATA_DOCUMENT_ID = "document_id"
METADATA_TYPE = "type"
METADATA_TEXT = "text"
METADATA_CHUNK_ID = "chunk_id"
METADATA_TIMESTAMP = "timestamp"


# Type aliases
VectorBackend = Literal["faiss", "chroma", "redis", "mongodb", "snowflake"]
LongTermBackend = Literal["redis", "mongodb", "chroma", "snowflake"]


# Protocol for LLM interface
class LLMProtocol(Protocol):
    """Protocol defining LLM interface requirements."""
    
    def generate(self, prompt: str) -> str:
        """Generate text from prompt."""
        ...
    
    def is_ready(self) -> bool:
        """Check if LLM is ready to use."""
        ...


# Pydantic models for validation
class ContextInputModel(BaseModel):
    """Validation model for conversation context."""
    inputs: dict[str, str] = Field(min_length=1)
    outputs: dict[str, str] = Field(min_length=1)


class SummaryInputModel(BaseModel):
    """Validation model for summary text."""
    summary: str = Field(min_length=1)


class EntityInputModel(BaseModel):
    """Validation model for entity key-value pairs."""
    entity: str = Field(min_length=1)
    value: Any


# Base LLM Classes
class BaseLLM:
    """Base class for LLM implementations with caching."""
    
    def __init__(self) -> None:
        self._cache: dict[str, str] = {}

    def _generate(self, prompt: str) -> str:
        """Generate response from prompt. Must be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement _generate()")

    def generate(self, prompt: str) -> str:
        """Generate response with caching."""
        if prompt in self._cache:
            return self._cache[prompt]
        
        try:
            result = self._generate(prompt)
        except Exception as e:
            raise RuntimeError(f"LLM generate() failed: {e}") from e
        
        self._cache[prompt] = result
        return result

    def clear_cache(self) -> None:
        """Clear the response cache."""
        self._cache.clear()

    def is_ready(self) -> bool:
        """Check if LLM is ready to use."""
        return True


class OpenAILLM(BaseLLM):
    """OpenAI LLM implementation."""
    
    def __init__(self, api_key: str, model: str = "gpt-3.5-turbo") -> None:
        super().__init__()
        
        if not api_key:
            raise ValueError("api_key is required for OpenAI LLM")
        
        if not OPENAI_AVAILABLE:
            raise ImportError("openai package required. Install: pip install openai")
        
        self.client = OpenAI(api_key=api_key)
        self.model = model

    def _generate(self, prompt: str) -> str:
        """Generate response using OpenAI API."""
        if not isinstance(prompt, str):
            raise TypeError("Prompt must be a string")
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2,
            )
            return response.choices[0].message.content
        except Exception as e:
            raise RuntimeError(f"OpenAI LLM error: {e}") from e

    def invoke(self, prompt: str) -> str:
        """Alternative method name for compatibility."""
        return self.generate(prompt)

    def is_ready(self) -> bool:
        """Check if client is initialized."""
        return self.client is not None


class GroqLLM(BaseLLM):
    """Groq LLM implementation."""
    
    def __init__(self, api_key: str, model: str = "llama3-8b-8192") -> None:
        super().__init__()
        
        try:
            from groq import Groq
        except ImportError:
            raise ImportError("groq package required. Install: pip install groq")
        
        self.client = Groq(api_key=api_key)
        self.model = model

    def _generate(self, prompt: str) -> str:
        """Generate response using Groq API."""
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return response.choices[0].message.content


class AnthropicLLM(BaseLLM):
    """Anthropic Claude LLM implementation."""
    
    def __init__(self, api_key: str, model: str = "claude-3-opus-20240229") -> None:
        super().__init__()
        
        try:
            import anthropic
        except ImportError:
            raise ImportError("anthropic package required. Install: pip install anthropic")
        
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model

    def _generate(self, prompt: str) -> str:
        """Generate response using Anthropic API."""
        response = self.client.messages.create(
            model=self.model,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        
        content = response.content[0]
        return content.text if hasattr(content, 'text') else str(content)


class CohereLLM(BaseLLM):
    """Cohere LLM implementation."""
    
    def __init__(self, api_key: str, model: str = "command-r-plus") -> None:
        super().__init__()
        
        try:
            import cohere
        except ImportError:
            raise ImportError("cohere package required. Install: pip install cohere")
        
        self.client = cohere.Client(api_key)
        self.model = model

    def _generate(self, prompt: str) -> str:
        """Generate response using Cohere API."""
        response = self.client.chat(
            model=self.model,
            message=prompt,
            temperature=0.2,
        )
        return response.text if hasattr(response, 'text') else str(response)


class GeminiLLM(BaseLLM):
    """Google Gemini LLM implementation."""
    
    def __init__(self, api_key: str, model: str = "gemini-pro") -> None:
        super().__init__()
        
        try:
            import google.generativeai as genai
        except ImportError:
            raise ImportError(
                "google-generativeai package required. "
                "Install: pip install google-generativeai"
            )
        
        genai.configure(api_key=api_key)
        self.client = genai.GenerativeModel(model)
        self.model = model

    def _generate(self, prompt: str) -> str:
        """Generate response using Gemini API."""
        response = self.client.generate_content(prompt)
        return response.text if hasattr(response, 'text') else str(response)


# Memory Classes
class ShortTermMemory:
    """In-memory key-value storage for temporary data."""
    
    def __init__(self) -> None:
        self._store: dict[str, Any] = {}

    def set(self, key: str, value: Any) -> None:
        """Store a value with given key."""
        self._store[key] = value

    def get(self, key: str) -> Any | None:
        """Retrieve value by key."""
        return self._store.get(key)

    def clear(self) -> None:
        """Clear all stored data."""
        self._store.clear()

    def delete(self, key: str) -> None:
        """Delete specific key from storage."""
        self._store.pop(key, None)


class BufferMemory:
    """Fixed-size buffer for conversation history."""
    
    def __init__(self, buffer_size: int = 5) -> None:
        if buffer_size <= 0:
            raise ValueError("buffer_size must be positive")
        
        self.buffer_size = buffer_size
        self._buffer: list[dict[str, dict[str, str]]] = []

    def save_context(
        self,
        inputs: dict[str, str],
        outputs: dict[str, str]
    ) -> None:
        """Save a conversation turn."""
        # Validate with Pydantic
        validated = ContextInputModel(inputs=inputs, outputs=outputs)
        
        turn = {
            "inputs": validated.inputs,
            "outputs": validated.outputs
        }
        
        self._buffer.append(turn)
        
        # Maintain buffer size
        if len(self._buffer) > self.buffer_size:
            self._buffer.pop(0)

    def save_context_batch(
        self,
        turns: list[tuple[dict[str, str], dict[str, str]]]
    ) -> None:
        """Save multiple conversation turns at once."""
        for inputs, outputs in turns:
            self.save_context(inputs, outputs)

    def get(self) -> list[dict[str, dict[str, str]]]:
        """Retrieve all stored conversation turns."""
        return list(self._buffer)

    def clear(self) -> None:
        """Clear all conversation history."""
        self._buffer.clear()

    def delete(self, idx: int) -> None:
        """Delete conversation turn at specific index."""
        if 0 <= idx < len(self._buffer):
            del self._buffer[idx]

    def is_ready(self) -> bool:
        """Check if buffer is ready to use."""
        return True


class SummaryMemory:
    """Progressive conversation summarization using LLM."""
    
    def __init__(self) -> None:
        self._summary: str | None = None

    def set(self, summary: str) -> None:
        """Set the current summary."""
        validated = SummaryInputModel(summary=summary)
        self._summary = validated.summary

    def get(self) -> str | None:
        """Get the current summary."""
        return self._summary

    def update(self, new_lines: str, llm: BaseLLM | None) -> None:
        """Update summary with new conversation lines using LLM."""
        if llm is None:
            raise ValueError("LLM is required for summary update")

        prompt = textwrap.dedent(f"""
            Progressively summarize the conversation based on the previous summary 
            and the new lines of dialogue.

            Previous summary:
            {self._summary or "This is the beginning of the conversation."}

            New lines of dialogue:
            {new_lines}

            New summary:
        """)
        
        summary = llm.generate(prompt)
        validated = SummaryInputModel(summary=summary)
        self._summary = validated.summary

    def clear(self) -> None:
        """Clear the summary."""
        self._summary = None

    def is_ready(self) -> bool:
        """Check if summary memory is ready."""
        return True


class EntityMemory:
    """Extract and track entities from conversation using LLM."""
    
    def __init__(self) -> None:
        self._entities: dict[str, Any] = {}

    def set(self, entity: str, value: Any) -> None:
        """Store an entity with its value."""
        validated = EntityInputModel(entity=entity, value=value)
        self._entities[validated.entity] = validated.value

    def get(self, entity: str) -> Any | None:
        """Retrieve value for specific entity."""
        return self._entities.get(entity)

    def all(self) -> dict[str, Any]:
        """Get all stored entities."""
        return dict(self._entities)

    def update(self, new_lines: str, llm: BaseLLM | None) -> None:
        """Extract and update entities from new text using LLM."""
        if llm is None:
            raise ValueError("LLM is required for entity update")

        prompt = textwrap.dedent(f"""
            Extract key entities (like names, locations, topics) from the following text.
            Return ONLY a valid JSON object, and nothing else. 
            For example: {{"person": "Aditya", "location": "Pune"}}

            Text:
            {new_lines}

            JSON Output:
        """)
        
        result = llm.generate(prompt)
        print(f"[DEBUG] LLM raw output: {result}")
        
        # Extract JSON from response
        import re
        json_match = re.search(r'\{.*\}', result, re.DOTALL)
        
        if json_match:
            json_str = json_match.group(0)
            with suppress(json.JSONDecodeError, TypeError):
                extracted_entities = json.loads(json_str)
                for key, value in extracted_entities.items():
                    validated = EntityInputModel(entity=key, value=value)
                    self._entities[validated.entity] = validated.value

    def clear(self) -> None:
        """Clear all entities."""
        self._entities.clear()

    def delete(self, entity: str) -> None:
        """Delete specific entity."""
        self._entities.pop(entity, None)

    def is_ready(self) -> bool:
        """Check if entity memory is ready."""
        return True


# Vector Memory Protocol
class VectorMemoryProtocol(Protocol):
    """Protocol for vector memory backends."""
    
    def add_vector(self, key: str, vector: list[float], metadata: dict[str, Any]) -> None:
        """Add a vector with metadata."""
        ...
    
    def query_vector(
        self,
        vector: list[float],
        top_k: int = 5,
        type_filter: str | None = None
    ) -> list[dict[str, Any]]:
        """Query similar vectors."""
        ...
    
    def clear(self) -> None:
        """Clear all vectors."""
        ...
    
    def is_ready(self) -> bool:
        """Check if backend is ready."""
        ...


# Long-Term Memory Factory
class LongTermMemory:
    """Factory for creating long-term memory backends."""
    
    def __new__(
        cls,
        backend: LongTermBackend = "redis",
        **kwargs: Any
    ) -> Any:
        """Create appropriate long-term memory backend."""
        match backend:
            case "redis":
                return RedisLongTermMemory(**kwargs)
            case "mongodb":
                return MongoDBLongTermMemory(**kwargs)
            case "chroma":
                return ChromaLongTermMemory(**kwargs)
            case "snowflake":
                return SnowflakeLongTermMemory(**kwargs)
            case _:
                raise ValueError(f"Unknown backend: {backend}")


@dataclass
class UnifiedVectorMemory:
    """Unified interface for vector memory across multiple backends."""
    
    backend: VectorBackend = "faiss"
    embedder: Any | None = None
    chunk_size: int = 512
    chunk_overlap: int = 50
    backend_kwargs: dict[str, Any] = field(default_factory=dict)
    vector_store: VectorMemoryProtocol = field(init=False)
    
    def __post_init__(self) -> None:
        """Initialize vector store after dataclass creation."""
        self.vector_store = get_vector_memory(self.backend, **self.backend_kwargs)

    def add_document(
        self,
        path: str | Path,
        embedder: Any | None = None,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
        metadata: dict[str, Any] | None = None
    ) -> None:
        """Add document to vector memory with chunking."""
        embedder = embedder or self.embedder
        if embedder is None:
            raise ValueError("An embedder must be provided")
        
        chunk_size = chunk_size or self.chunk_size
        chunk_overlap = chunk_overlap or self.chunk_overlap
        
        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        text = file_path.read_text(encoding="utf-8")
        chunks = self._chunk_text(text, chunk_size, chunk_overlap)
        
        for i, chunk in enumerate(chunks):
            vector = embedder.embed(chunk)
            meta = {
                "type": "document",
                "source": str(file_path),
                "text": chunk,
                "chunk_id": i
            }
            if metadata:
                meta.update(metadata)
            
            key = f"{file_path.name}_chunk_{i}"
            self.vector_store.add_vector(key, vector, meta)

    def add_conversation_turn(
        self,
        user_input: str,
        ai_output: str,
        embedder: Any | None = None,
        timestamp: str | None = None,
        metadata: dict[str, Any] | None = None
    ) -> None:
        """Add conversation turn to vector memory."""
        embedder = embedder or self.embedder
        if embedder is None:
            raise ValueError("An embedder must be provided")
        
        text = f"User: {user_input}\nAI: {ai_output}"
        vector = embedder.embed(text)
        
        meta: dict[str, Any] = {
            "type": "conversation",
            "user_input": user_input,
            "ai_output": ai_output
        }
        
        if timestamp:
            meta["timestamp"] = timestamp
        if metadata:
            meta.update(metadata)
        
        key = f"conv_{hash(text)}"
        self.vector_store.add_vector(key, vector, meta)

    def query(
        self,
        query_text: str,
        embedder: Any | None = None,
        top_k: int = 5,
        type_filter: str | None = None
    ) -> list[dict[str, Any]]:
        """Query vector memory for similar content."""
        embedder = embedder or self.embedder
        if embedder is None:
            raise ValueError("An embedder must be provided")
        
        vector = embedder.embed(query_text)
        return self.vector_store.query_vector(vector, top_k=top_k, type_filter=type_filter)

    @staticmethod
    def _chunk_text(text: str, chunk_size: int, chunk_overlap: int) -> list[str]:
        """Split text into overlapping chunks."""
        chunks: list[str] = []
        start = 0
        
        while start < len(text):
            end = min(start + chunk_size, len(text))
            chunks.append(text[start:end])
            
            if end == len(text):
                break
            
            start += chunk_size - chunk_overlap
        
        return chunks

    def is_ready(self) -> bool:
        """Check if vector store is ready."""
        return self.vector_store.is_ready()


class MemoryManager:
    """Orchestrate multiple memory types for AI applications."""
    
    def __init__(
        self,
        llm: BaseLLM | None = None,
        buffer_size: int = 5,
        long_term_backend: LongTermBackend | None = None,
        vector_backend: VectorBackend | None = None,
        vector_embedder: Any | None = None,
        vector_backend_kwargs: dict[str, Any] | None = None,
        **long_term_kwargs: Any
    ) -> None:
        self.llm = llm
        self.short_term = ShortTermMemory()
        self.buffer = BufferMemory(buffer_size=buffer_size)
        self.summary = SummaryMemory()
        self.entity = EntityMemory()
        
        # Initialize long-term memory if backend specified
        self.long_term: Any | None = None
        if long_term_backend is not None:
            self.long_term = LongTermMemory(backend=long_term_backend, **long_term_kwargs)
        
        # Initialize vector memory if backend specified
        self.vector_memory: UnifiedVectorMemory | None = None
        if vector_backend is not None:
            self.vector_memory = UnifiedVectorMemory(
                backend=vector_backend,
                embedder=vector_embedder,
                backend_kwargs=vector_backend_kwargs or {}
            )

    def save_context(
        self,
        inputs: dict[str, str],
        outputs: dict[str, str]
    ) -> None:
        """Save conversation context across memory types."""
        self.buffer.save_context(inputs, outputs)

        # Update summary and entities if LLM is available
        if self.llm:
            new_lines = "\n".join(
                [f"Human: {v}" for v in inputs.values()] +
                [f"AI: {v}" for v in outputs.values()]
            )
            self.summary.update(new_lines, self.llm)
            self.entity.update(new_lines, self.llm)

    def load_memory(self) -> dict[str, Any]:
        """Load all memory types into single dict."""
        return {
            "history": self.buffer.get(),
            "summary": self.summary.get(),
            "entities": self.entity.all(),
        }

    def clear_all(self) -> None:
        """Clear all memory types."""
        self.buffer.clear()
        self.summary.clear()
        self.entity.clear()
        
        if self.long_term and hasattr(self.long_term, 'clear'):
            self.long_term.clear()

    def is_ready(self) -> bool:
        """Check if all memory components are ready."""
        if self.llm and not self.llm.is_ready():
            return False
        
        if self.vector_memory and not self.vector_memory.is_ready():
            return False
        
        return True


# Note: Vector backend implementations (Faiss, Chroma, Redis, MongoDB, Snowflake)
# and LongTermMemory backend implementations are omitted for brevity.
# They follow the same modernization patterns shown above.

def get_vector_memory(backend: VectorBackend, **kwargs: Any) -> VectorMemoryProtocol:
    """Factory function to create vector memory backend."""
    # Implementation would import and instantiate appropriate backend
    raise NotImplementedError("Vector backend implementations not included in this excerpt")
