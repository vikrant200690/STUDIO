"""
DocChain: Comprehensive document processing and AI memory management toolkit.

This package provides utilities for:
- File handling (local and multi-cloud storage)
- Text cleaning and preprocessing
- Embedding generation with multiple providers
- Vector storage across multiple backends
- Memory management for AI applications
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__license__ = "MIT"


# ================= File Utils =================
from .file_utils.file_handler import (
    AWSConnectionDetails,
    AzureConnectionDetails,
    CloudConnectionValidator,
    CloudUploadError,
    FileValidationError,
    GCPConnectionDetails,
    UniversalFileHandler,
)

# ================= Text Cleaning =================
from .TextCleaning.cleaner import (
    Cleaner,
    TextCleaner,
    TextCleaningError,
    UnsupportedFileTypeError,
    EncodingDetectionError,
    clean_file,
    clean_text,
)

# ================= Embedding Utilities =================
from .Embedding_utils.embedding import (
    Embedder,
    UserConfig,
    EmbeddingError,
    InvalidConfigurationError,
    FileProcessingError,
    ProviderNotAvailableError,
    create_embedder_from_config,
    process_file_with_embeddings,
    sentence_chunk,
    embed_texts,
    create_embedder,
)

# ================= Vector Utilities =================
from .vectorutils.vector import (
    VectorStore,
    VectorStoreConfig,
    VectorStoreError,
    DatabaseConnectionError,
    EmbeddingGenerationError,
    index_path,
    vector_store_demo,
)

# ================= Memory Utilities =================
from .memory_utils.memory import (
    # Memory Classes
    ShortTermMemory,
    BufferMemory,
    SummaryMemory,
    EntityMemory,
    LongTermMemory,
    UnifiedVectorMemory,
    MemoryManager,
    
    # LLM Classes
    BaseLLM,
    OpenAILLM,
    GroqLLM,
    CohereLLM,
    GeminiLLM,
    AnthropicLLM,
    
    # Vector Memory Backends
    FaissVectorMemory,
    ChromaVectorMemory,
    RedisVectorMemory,
    MongoDBVectorMemory,
    SnowflakeVectorMemory,
    
    # Utility Functions
    get_vector_memory,
    
    # Constants
    METADATA_USER_ID,
    METADATA_SESSION_ID,
    METADATA_DOCUMENT_ID,
    METADATA_TYPE,
    METADATA_TEXT,
    METADATA_CHUNK_ID,
    METADATA_TIMESTAMP,
)


# ================= Public API =================
__all__ = [
    # File Utils
    "UniversalFileHandler",
    "CloudUploadError",
    "FileValidationError",
    "AWSConnectionDetails",
    "GCPConnectionDetails",
    "AzureConnectionDetails",
    "CloudConnectionValidator",
    
    # Text Cleaning
    "Cleaner",
    "TextCleaner",
    "TextCleaningError",
    "UnsupportedFileTypeError",
    "EncodingDetectionError",
    "clean_file",
    "clean_text",
    
    # Embedding Utilities
    "Embedder",
    "UserConfig",
    "EmbeddingError",
    "InvalidConfigurationError",
    "FileProcessingError",
    "ProviderNotAvailableError",
    "create_embedder_from_config",
    "process_file_with_embeddings",
    "sentence_chunk",
    "embed_texts",
    "create_embedder",
    
    # Vector Utilities
    "VectorStore",
    "VectorStoreConfig",
    "VectorStoreError",
    "DatabaseConnectionError",
    "EmbeddingGenerationError",
    "index_path",
    "vector_store_demo",
    
    # Memory Utilities - Core Classes
    "ShortTermMemory",
    "BufferMemory",
    "SummaryMemory",
    "EntityMemory",
    "LongTermMemory",
    "UnifiedVectorMemory",
    "MemoryManager",
    
    # Memory Utilities - LLM Classes
    "BaseLLM",
    "OpenAILLM",
    "GroqLLM",
    "CohereLLM",
    "GeminiLLM",
    "AnthropicLLM",
    
    # Memory Utilities - Vector Backends
    "FaissVectorMemory",
    "ChromaVectorMemory",
    "RedisVectorMemory",
    "MongoDBVectorMemory",
    "SnowflakeVectorMemory",
    
    # Memory Utilities - Functions
    "get_vector_memory",
    
    # Memory Utilities - Constants
    "METADATA_USER_ID",
    "METADATA_SESSION_ID",
    "METADATA_DOCUMENT_ID",
    "METADATA_TYPE",
    "METADATA_TEXT",
    "METADATA_CHUNK_ID",
    "METADATA_TIMESTAMP",
]


# ================= Convenience Imports =================
def get_version() -> str:
    """Get the package version."""
    return __version__


def list_llm_providers() -> list[str]:
    """List available LLM providers."""
    return ["openai", "groq", "cohere", "gemini", "anthropic"]


def list_vector_backends() -> list[str]:
    """List available vector store backends."""
    return ["faiss", "chroma", "redis", "mongodb", "snowflake"]


def list_cloud_providers() -> list[str]:
    """List supported cloud storage providers."""
    return ["aws", "gcp", "azure"]


# ================= Module-level Functions =================
def quick_embed(
    text: str | list[str],
    provider: str = "openai",
    **kwargs
) -> list[list[float]]:
    """
    Quick embedding generation without configuration.
    
    Args:
        text: Text or list of texts to embed
        provider: Embedding provider (openai, cohere, gemini)
        **kwargs: Additional provider-specific arguments
    
    Returns:
        List of embedding vectors
    
    Example:
        >>> embeddings = quick_embed("Hello world", provider="openai")
    """
    return embed_texts(text, provider=provider, **kwargs)


def quick_clean(
    text: str,
    remove_html: bool = True,
    remove_special_chars: bool = True,
    normalize_whitespace: bool = True
) -> str:
    """
    Quick text cleaning without configuration.
    
    Args:
        text: Text to clean
        remove_html: Remove HTML tags
        remove_special_chars: Remove special characters
        normalize_whitespace: Normalize whitespace
    
    Returns:
        Cleaned text
    
    Example:
        >>> clean = quick_clean("<p>Hello   world!</p>")
    """
    cleaner = Cleaner()
    
    if remove_html:
        text = cleaner.remove_html_tags(text)
    if remove_special_chars:
        text = cleaner.remove_special_chars(text)
    if normalize_whitespace:
        text = cleaner.normalize_whitespace(text)
    
    return text


def quick_memory(llm_provider: str = "openai", **kwargs) -> MemoryManager:
    """
    Quick memory manager initialization.
    
    Args:
        llm_provider: LLM provider to use
        **kwargs: Additional LLM arguments (api_key, model, etc.)
    
    Returns:
        Configured MemoryManager instance
    
    Example:
        >>> memory = quick_memory("openai", api_key="sk-...")
        >>> memory.save_context({"user": "hi"}, {"ai": "hello"})
    """
    llm_map = {
        "openai": OpenAILLM,
        "groq": GroqLLM,
        "cohere": CohereLLM,
        "gemini": GeminiLLM,
        "anthropic": AnthropicLLM,
    }
    
    llm_class = llm_map.get(llm_provider.lower())
    if not llm_class:
        raise ValueError(
            f"Unknown LLM provider: {llm_provider}. "
            f"Choose from: {list(llm_map.keys())}"
        )
    
    llm = llm_class(**kwargs)
    return MemoryManager(llm=llm)


# ================= Package Info =================
__package_info__ = {
    "name": "docchain",
    "version": __version__,
    "description": "Comprehensive document processing and AI memory toolkit",
    "features": [
        "Multi-cloud file handling (AWS S3, GCP, Azure)",
        "Advanced text cleaning and preprocessing",
        "Multi-provider embedding generation (OpenAI, Cohere, Gemini)",
        "Vector storage (FAISS, Chroma, Redis, MongoDB, Snowflake)",
        "AI memory management (short-term, long-term, vector)",
        "Multiple LLM integrations (OpenAI, Groq, Anthropic, Cohere, Gemini)"
    ],
    "llm_providers": list_llm_providers(),
    "vector_backends": list_vector_backends(),
    "cloud_providers": list_cloud_providers(),
}


def print_info() -> None:
    """Print package information."""
    info = __package_info__
    
    print(f"\n{'='*60}")
    print(f"{info['name'].upper()} v{info['version']}")
    print(f"{'='*60}")
    print(f"\n{info['description']}\n")
    
    print("Features:")
    for feature in info['features']:
        print(f"  • {feature}")
    
    print(f"\nSupported LLM Providers: {', '.join(info['llm_providers'])}")
    print(f"Vector Store Backends: {', '.join(info['vector_backends'])}")
    print(f"Cloud Storage Providers: {', '.join(info['cloud_providers'])}")
    print(f"\n{'='*60}\n")


# ================= Lazy Imports (Optional) =================
def __getattr__(name: str):
    """
    Lazy import for heavy dependencies.
    
    This allows deferring imports of large modules until they're actually used.
    """
    # This is a placeholder for future lazy loading implementation
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


# ================= Module Initialization =================
def _check_dependencies() -> dict[str, bool]:
    """Check availability of optional dependencies."""
    dependencies = {
        "openai": False,
        "cohere": False,
        "anthropic": False,
        "groq": False,
        "google-generativeai": False,
        "redis": False,
        "pymongo": False,
        "chromadb": False,
        "faiss": False,
        "snowflake-connector-python": False,
        "neo4j": False,
    }
    
    for package in dependencies:
        try:
            __import__(package.replace("-", "_"))
            dependencies[package] = True
        except ImportError:
            pass
    
    return dependencies


# Store dependency information
_DEPENDENCIES = _check_dependencies()


def get_available_features() -> dict[str, list[str]]:
    """
    Get list of available features based on installed dependencies.
    
    Returns:
        Dictionary mapping feature categories to available options
    """
    features = {
        "llm_providers": [],
        "vector_backends": [],
        "cloud_providers": ["local"],  # Always available
    }
    
    # Check LLM providers
    if _DEPENDENCIES.get("openai"):
        features["llm_providers"].append("openai")
    if _DEPENDENCIES.get("groq"):
        features["llm_providers"].append("groq")
    if _DEPENDENCIES.get("cohere"):
        features["llm_providers"].append("cohere")
    if _DEPENDENCIES.get("google-generativeai"):
        features["llm_providers"].append("gemini")
    if _DEPENDENCIES.get("anthropic"):
        features["llm_providers"].append("anthropic")
    
    # Check vector backends
    if _DEPENDENCIES.get("faiss"):
        features["vector_backends"].append("faiss")
    if _DEPENDENCIES.get("chromadb"):
        features["vector_backends"].append("chroma")
    if _DEPENDENCIES.get("redis"):
        features["vector_backends"].append("redis")
    if _DEPENDENCIES.get("pymongo"):
        features["vector_backends"].append("mongodb")
    if _DEPENDENCIES.get("snowflake-connector-python"):
        features["vector_backends"].append("snowflake")
    
    # Cloud providers (assume boto3, google-cloud-storage, azure-storage-blob)
    features["cloud_providers"].extend(["aws", "gcp", "azure"])
    
    return features
