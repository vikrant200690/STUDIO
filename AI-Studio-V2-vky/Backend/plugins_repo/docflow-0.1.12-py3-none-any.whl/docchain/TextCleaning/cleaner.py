"""Text cleaning utilities with rule-based and LLM-based cleaning options."""

import re
from pathlib import Path
from typing import Any, Literal

import chardet
from bs4 import BeautifulSoup


# Type aliases
FileExtension = Literal[".pdf", ".docx", ".txt", ".csv", ".log"]
CleaningMode = Literal["rule", "llm", "both"]


class TextCleaningError(Exception):
    """Base exception for text cleaning operations."""
    pass


class UnsupportedFileTypeError(TextCleaningError):
    """Raised when file type is not supported."""
    pass


class EncodingDetectionError(TextCleaningError):
    """Raised when file encoding cannot be detected."""
    pass


class Cleaner:
    """Text cleaning utility with multiple file format support."""
    
    # Supported file extensions
    SUPPORTED_EXTENSIONS: set[str] = {".pdf", ".docx", ".txt", ".csv", ".log"}
    
    def __init__(self, model: Any | None = None) -> None:
        """
        Initialize the Cleaner with an optional LLM model.
        
        Args:
            model: Optional LLM model for advanced cleaning
        """
        self.model = model

    def read_text_file(self, file_path: str | Path) -> str:
        """
        Read and extract text from various file formats.
        
        Args:
            file_path: Path to the file to read
        
        Returns:
            Extracted text content
        
        Raises:
            UnsupportedFileTypeError: If file extension is not supported
            FileNotFoundError: If file does not exist
        """
        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        ext = path.suffix.lower()
        
        match ext:
            case ".pdf":
                return self._read_pdf(path)
            case ".docx":
                return self._read_docx(path)
            case ".txt" | ".csv" | ".log":
                return self._read_text_with_encoding(path)
            case _:
                raise UnsupportedFileTypeError(
                    f"Unsupported file extension: {ext}. "
                    f"Supported: {', '.join(self.SUPPORTED_EXTENSIONS)}"
                )

    def _read_pdf(self, path: Path) -> str:
        """Extract text from PDF file using PyMuPDF."""
        try:
            import fitz  # PyMuPDF
        except ImportError:
            raise ImportError(
                "PyMuPDF required for PDF processing. "
                "Install with: pip install pymupdf"
            )
        
        with fitz.open(path) as doc:
            return "\n".join(page.get_text() for page in doc)

    def _read_docx(self, path: Path) -> str:
        """Extract text from DOCX file."""
        try:
            from docx import Document
        except ImportError:
            raise ImportError(
                "python-docx required for DOCX processing. "
                "Install with: pip install python-docx"
            )
        
        doc = Document(path)
        return "\n".join(para.text for para in doc.paragraphs)

    def _read_text_with_encoding(self, path: Path) -> str:
        """
        Read text file with automatic encoding detection.
        
        Args:
            path: Path to text file
        
        Returns:
            Decoded text content
        
        Raises:
            EncodingDetectionError: If encoding cannot be detected
        """
        raw_bytes = path.read_bytes()
        
        # Detect encoding
        detected = chardet.detect(raw_bytes)
        encoding = detected.get("encoding")
        
        if not encoding:
            raise EncodingDetectionError(
                f"Unable to detect encoding for: {path}. "
                f"Try specifying encoding manually."
            )
        
        try:
            return raw_bytes.decode(encoding)
        except (UnicodeDecodeError, LookupError) as e:
            raise EncodingDetectionError(
                f"Failed to decode file with detected encoding '{encoding}': {e}"
            ) from e

    def write_cleaned_text(
        self,
        output_path: str | Path,
        content: str | Any
    ) -> Path:
        """
        Write cleaned text to file.
        
        Args:
            output_path: Path where cleaned text should be saved
            content: Text content to write (converted to string if needed)
        
        Returns:
            Path to written file
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        # Convert content to string if needed
        if not isinstance(content, str):
            content = str(content.content if hasattr(content, "content") else content)
        
        path.write_text(content, encoding="utf-8")
        return path

    def remove_html_tags(self, text: str) -> str:
        """
        Remove HTML tags from text using BeautifulSoup.
        
        Args:
            text: Text potentially containing HTML
        
        Returns:
            Text with HTML tags removed
        """
        soup = BeautifulSoup(text, "html.parser")
        return soup.get_text(separator=" ", strip=True)

    def remove_special_chars(self, text: str, keep_chars: str = "") -> str:
        """
        Remove special characters, keeping only alphanumerics and whitespace.
        
        Args:
            text: Input text
            keep_chars: Additional characters to preserve
        
        Returns:
            Text with special characters removed
        """
        pattern = rf"[^\w\s{re.escape(keep_chars)}]"
        return re.sub(pattern, " ", text)

    def normalize_whitespace(self, text: str) -> str:
        """
        Normalize whitespace by replacing multiple spaces with single space.
        
        Args:
            text: Input text with irregular whitespace
        
        Returns:
            Text with normalized whitespace
        """
        # Replace non-breaking spaces
        text = text.replace("\u00a0", " ")
        # Collapse multiple whitespace
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def rule_based_cleaning(self, text: str) -> str:
        """
        Apply rule-based cleaning pipeline.
        
        Args:
            text: Raw text to clean
        
        Returns:
            Cleaned text
        """
        text = self.remove_html_tags(text)
        text = self.remove_special_chars(text)
        text = self.normalize_whitespace(text)
        return text

    def llm_based_cleaning(self, text: str, max_length: int = 10000) -> str:
        """
        Apply LLM-based cleaning for advanced text improvement.
        
        Args:
            text: Text to clean
            max_length: Maximum text length to send to LLM
        
        Returns:
            LLM-cleaned text
        
        Raises:
            ValueError: If no LLM model is configured
        """
        if not self.model:
            raise ValueError(
                "LLM model must be provided for LLM-based cleaning. "
                "Initialize Cleaner with a model parameter."
            )
        
        # Truncate if too long
        if len(text) > max_length:
            text = text[:max_length]
            print(f"[INFO] Text truncated to {max_length} characters for LLM processing")
        
        prompt = (
            f"Clean this text and improve formatting and clarity:\n\n{text}"
        )
        
        return self.model.invoke(prompt)

    def clean_text_pipeline(
        self,
        input_path: str | Path | dict[str, Any],
        output_path: str | Path | None = None,
        llm_cleaning: bool = False
    ) -> Path:
        """
        Complete text cleaning pipeline from file/dict to cleaned output.
        
        Args:
            input_path: File path or dict with 'content' key
            output_path: Where to save cleaned text (auto-generated if None)
            llm_cleaning: Whether to apply LLM-based cleaning
        
        Returns:
            Path to cleaned output file
        
        Raises:
            TypeError: If input_path is neither string nor dict
            ValueError: If dict doesn't contain required 'content' field
        """
        # Handle different input types
        match input_path:
            case dict():
                raw_text = input_path.get("content", "")
                if not raw_text:
                    raise ValueError(
                        "Input dict must contain a non-empty 'content' field"
                    )
                file_name = (
                    input_path.get("metadata", {})
                    .get("file_name", "cleaned_output")
                )
            case str() | Path():
                path = Path(input_path)
                if not path.exists():
                    raise FileNotFoundError(f"File not found: {path}")
                raw_text = self.read_text_file(path)
                file_name = path.stem
            case _:
                raise TypeError(
                    "input_path must be a file path (str/Path) or dict with 'content'"
                )
        
        # Apply rule-based cleaning
        cleaned_text = self.rule_based_cleaning(raw_text)
        
        # Optional LLM-based enhancement
        if llm_cleaning:
            cleaned_text = self.llm_based_cleaning(cleaned_text)
        
        # Determine output path
        if output_path is None:
            output_dir = Path("data")
            output_dir.mkdir(exist_ok=True)
            output_path = output_dir / f"{file_name}_cleaned.txt"
        else:
            output_path = Path(output_path)
        
        # Write cleaned output
        return self.write_cleaned_text(output_path, cleaned_text)

    def clean_text_content(
        self,
        text: str,
        llm_cleaning: bool = False
    ) -> str:
        """
        Clean raw text content without file I/O.
        
        Args:
            text: Raw text to clean
            llm_cleaning: Whether to apply LLM-based cleaning
        
        Returns:
            Cleaned text
        """
        cleaned_text = self.rule_based_cleaning(text)
        
        if llm_cleaning:
            cleaned_text = self.llm_based_cleaning(cleaned_text)
        
        return cleaned_text

    def batch_clean_files(
        self,
        file_paths: list[str | Path],
        output_dir: str | Path | None = None,
        llm_cleaning: bool = False
    ) -> list[dict[str, Any]]:
        """
        Clean multiple files in batch.
        
        Args:
            file_paths: List of file paths to clean
            output_dir: Directory for output files
            llm_cleaning: Whether to apply LLM cleaning
        
        Returns:
            List of results with status for each file
        """
        results: list[dict[str, Any]] = []
        
        for file_path in file_paths:
            try:
                output_path = self.clean_text_pipeline(
                    file_path,
                    output_path=None if output_dir is None else Path(output_dir) / f"{Path(file_path).stem}_cleaned.txt",
                    llm_cleaning=llm_cleaning
                )
                results.append({
                    "file": str(file_path),
                    "status": "success",
                    "output": str(output_path)
                })
            except Exception as e:
                results.append({
                    "file": str(file_path),
                    "status": "failed",
                    "error": str(e)
                })
        
        return results


# Convenience functions
def clean_file(
    input_path: str | Path,
    output_path: str | Path | None = None,
    model: Any | None = None,
    llm_cleaning: bool = False
) -> Path:
    """
    Convenience function to clean a single file.
    
    Args:
        input_path: Path to input file
        output_path: Path to output file (auto-generated if None)
        model: Optional LLM model for advanced cleaning
        llm_cleaning: Whether to use LLM cleaning
    
    Returns:
        Path to cleaned output file
    """
    cleaner = Cleaner(model=model)
    return cleaner.clean_text_pipeline(input_path, output_path, llm_cleaning)


def clean_text(
    text: str,
    model: Any | None = None,
    llm_cleaning: bool = False
) -> str:
    """
    Convenience function to clean text content.
    
    Args:
        text: Raw text to clean
        model: Optional LLM model for advanced cleaning
        llm_cleaning: Whether to use LLM cleaning
    
    Returns:
        Cleaned text
    """
    cleaner = Cleaner(model=model)
    return cleaner.clean_text_content(text, llm_cleaning)
