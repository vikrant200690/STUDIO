"""Advanced text cleaning with configurable pipeline steps."""

import re
import unicodedata
from pathlib import Path
from typing import Any, Literal

from bs4 import BeautifulSoup


CleaningStep = Literal[
    "remove_html_tags",
    "remove_emojis", 
    "remove_accents",
    "to_lower",
    "to_upper",
    "normalize_whitespace",
    "remove_punctuation",
    "remove_special_chars",
    "remove_stopwords",
    "remove_urls",
    "remove_emails"
]


class TextCleaner:
    """
    Configurable text cleaning with multi-step pipeline support.
    """
    
    # Common English stopwords
    ENGLISH_STOPWORDS = {
        'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're",
        "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he',
        'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's",
        'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which',
        'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are',
        'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do',
        'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because',
        'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against',
        'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below',
        'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again',
        'further', 'then', 'once'
    }
    
    def __init__(self, config: dict[str, Any] | None = None) -> None:
        """
        Initialize TextCleaner with configuration.
        
        Args:
            config: Configuration dict with 'language' and 'steps_to_apply'
        """
        self.config = config or {}
        self.language = self.config.get("language", "english")
        self.steps = self.config.get("steps_to_apply", [])
        
        # Load stopwords based on language
        self.stopwords = self._load_stopwords()

    def _load_stopwords(self) -> set[str]:
        """Load stopwords for configured language."""
        if self.language.lower() == "english":
            return self.ENGLISH_STOPWORDS
        
        # Try to load from nltk if available
        try:
            import nltk
            with suppress(Exception):
                return set(nltk.corpus.stopwords.words(self.language.lower()))
        except ImportError:
            pass
        
        return set()

    def remove_html_tags(self, text: str) -> str:
        """Remove HTML tags using BeautifulSoup."""
        soup = BeautifulSoup(text, "html.parser")
        return soup.get_text(separator=" ", strip=True)

    def remove_emojis(self, text: str) -> str:
        """Remove emojis and emoticons from text."""
        emoji_pattern = re.compile(
            "["
            "\U0001F600-\U0001F64F"  # emoticons
            "\U0001F300-\U0001F5FF"  # symbols & pictographs
            "\U0001F680-\U0001F6FF"  # transport & map symbols
            "\U0001F1E0-\U0001F1FF"  # flags (iOS)
            "\U00002702-\U000027B0"
            "\U000024C2-\U0001F251"
            "]+",
            flags=re.UNICODE
        )
        return emoji_pattern.sub(r'', text)

    def remove_accents(self, text: str) -> str:
        """Remove accents from characters (e.g., é -> e)."""
        nfkd_form = unicodedata.normalize('NFKD', text)
        return ''.join([c for c in nfkd_form if not unicodedata.combining(c)])

    def to_lower(self, text: str) -> str:
        """Convert text to lowercase."""
        return text.lower()

    def to_upper(self, text: str) -> str:
        """Convert text to uppercase."""
        return text.upper()

    def normalize_whitespace(self, text: str) -> str:
        """Normalize whitespace to single spaces."""
        # Replace non-breaking spaces and other special whitespace
        text = text.replace("\u00a0", " ")
        text = text.replace("\t", " ")
        text = text.replace("\r", " ")
        text = text.replace("\n", " ")
        # Collapse multiple spaces
        return re.sub(r'\s+', ' ', text).strip()

    def remove_punctuation(self, text: str) -> str:
        """Remove all punctuation marks."""
        return re.sub(r'[^\w\s]', '', text)

    def remove_special_chars(self, text: str) -> str:
        """Remove special characters, keeping only alphanumerics and spaces."""
        return re.sub(r'[^a-zA-Z0-9\s]', '', text)

    def remove_stopwords(self, text: str) -> str:
        """Remove stopwords based on configured language."""
        if not self.stopwords:
            return text
        
        words = text.split()
        filtered_words = [word for word in words if word.lower() not in self.stopwords]
        return ' '.join(filtered_words)

    def remove_urls(self, text: str) -> str:
        """Remove URLs from text."""
        url_pattern = re.compile(
            r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        )
        return url_pattern.sub('', text)

    def remove_emails(self, text: str) -> str:
        """Remove email addresses from text."""
        email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
        return email_pattern.sub('', text)

    def clean_single(self, text: str) -> str:
        """
        Apply configured cleaning steps to text.
        
        Args:
            text: Raw text to clean
        
        Returns:
            Cleaned text after applying all configured steps
        """
        cleaned = text
        
        # Apply each step in order
        for step in self.steps:
            method_name = step
            if hasattr(self, method_name):
                method = getattr(self, method_name)
                cleaned = method(cleaned)
            else:
                print(f"[WARNING] Unknown cleaning step: {step}")
        
        return cleaned

    def clean_batch(self, texts: list[str]) -> list[str]:
        """
        Clean multiple texts with same configuration.
        
        Args:
            texts: List of raw texts to clean
        
        Returns:
            List of cleaned texts
        """
        return [self.clean_single(text) for text in texts]

    def clean_file(
        self,
        input_path: str | Path,
        output_path: str | Path | None = None
    ) -> Path:
        """
        Clean text from file and save to output.
        
        Args:
            input_path: Path to input file
            output_path: Path to output file (auto-generated if None)
        
        Returns:
            Path to output file
        """
        path = Path(input_path)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        # Read input
        raw_text = path.read_text(encoding="utf-8")
        
        # Clean text
        cleaned_text = self.clean_single(raw_text)
        
        # Determine output path
        if output_path is None:
            output_path = path.with_stem(f"{path.stem}_cleaned")
        else:
            output_path = Path(output_path)
        
        # Write output
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(cleaned_text, encoding="utf-8")
        
        return output_path


def main() -> None:
    """Main entry point for text cleaning demonstration."""
    
    # Configuration
    sample_file = Path("sample.txt")
    
    # Verify file exists
    if not sample_file.exists():
        print(f"Error: {sample_file} not found")
        return
    
    # Read input file
    print(f"Reading file: {sample_file}")
    sample_text = sample_file.read_text(encoding="utf-8")
    print(f"Original text length: {len(sample_text)} characters\n")
    
    # Configure cleaning pipeline
    config: dict[str, Any] = {
        "language": "english",
        "steps_to_apply": [
            "remove_html_tags",
            "remove_emojis",
            "remove_accents",
            "to_lower",
            "normalize_whitespace",
            "remove_punctuation",
            "remove_special_chars",
            "remove_stopwords"
        ]
    }
    
    # Initialize cleaner with config
    cleaner = TextCleaner(config=config)
    
    # Apply cleaning
    print("Applying cleaning pipeline...")
    print(f"Steps: {', '.join(config['steps_to_apply'])}\n")
    
    cleaned_text = cleaner.clean_single(sample_text)
    
    # Display results
    print("=" * 60)
    print("CLEANED TEXT OUTPUT")
    print("=" * 60)
    print(cleaned_text)
    print("\n" + "=" * 60)
    print(f"Original length: {len(sample_text)} characters")
    print(f"Cleaned length: {len(cleaned_text)} characters")
    print(f"Reduction: {len(sample_text) - len(cleaned_text)} characters "
          f"({100 * (len(sample_text) - len(cleaned_text)) / len(sample_text):.1f}%)")
    
    # Save cleaned output
    output_file = sample_file.with_stem(f"{sample_file.stem}_cleaned")
    output_file.write_text(cleaned_text, encoding="utf-8")
    print(f"\nCleaned text saved to: {output_file}")


if __name__ == "__main__":
    main()
