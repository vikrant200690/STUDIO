"""Demo script for vector store operations with multiple backend support."""

from pathlib import Path
from typing import Any, Literal

from vector import vector_store_demo


# Type alias for supported databases
VectorDB = Literal["snowflake", "redis", "mongodb", "chroma", "faiss", "pinecone"]


def main() -> None:
    """Main entry point for vector store demonstration."""
    
    # Configuration parameters
    input_file = Path("sample_input.txt")
    
    # Verify input file exists
    if not input_file.exists():
        print(f"Error: Input file not found: {input_file}")
        print("Please create sample_input.txt with some text content.")
        return
    
    params: dict[str, Any] = {
        "db": "snowflake",                    # Vector database backend
        "path": input_file,                   # Input document path
        "query": "hello",                     # Search query
        "top_k": 2,                           # Number of results to return
        "delete_after": False                 # Keep data after demo
    }
    
    # Display configuration
    print("=" * 60)
    print("Vector Store Demo Configuration")
    print("=" * 60)
    print(f"Database Backend: {params['db']}")
    print(f"Input File: {params['path']}")
    print(f"Search Query: '{params['query']}'")
    print(f"Top-K Results: {params['top_k']}")
    print(f"Delete After: {params['delete_after']}")
    print("=" * 60)
    print()
    
    try:
        # Run demo
        print("Starting vector store demo...\n")
        vector_store_demo(**params)
        print("\n" + "=" * 60)
        print("Demo completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Demo failed: {e}")
        print(f"Error type: {type(e).__name__}")
        raise


def run_multi_backend_demo() -> None:
    """Run demo across multiple vector store backends."""
    
    input_file = Path("sample_input.txt")
    
    if not input_file.exists():
        print(f"Error: {input_file} not found")
        return
    
    # Test multiple backends
    backends: list[VectorDB] = ["faiss", "chroma", "redis"]
    query = "sample search query"
    
    print("=" * 60)
    print("Multi-Backend Vector Store Demo")
    print("=" * 60)
    
    for backend in backends:
        print(f"\n--- Testing {backend.upper()} Backend ---")
        
        params: dict[str, Any] = {
            "db": backend,
            "path": input_file,
            "query": query,
            "top_k": 3,
            "delete_after": True  # Clean up after each test
        }
        
        try:
            vector_store_demo(**params)
            print(f"✓ {backend.upper()} test passed")
        except Exception as e:
            print(f"✗ {backend.upper()} test failed: {e}")
    
    print("\n" + "=" * 60)
    print("Multi-backend testing complete")
    print("=" * 60)


def run_benchmark_demo() -> None:
    """Benchmark different vector store backends."""
    import time
    
    input_file = Path("sample_input.txt")
    
    if not input_file.exists():
        print(f"Error: {input_file} not found")
        return
    
    backends: list[VectorDB] = ["faiss", "chroma"]
    query = "benchmark query"
    results: dict[str, float] = {}
    
    print("=" * 60)
    print("Vector Store Benchmark")
    print("=" * 60)
    
    for backend in backends:
        print(f"\nBenchmarking {backend.upper()}...")
        
        params: dict[str, Any] = {
            "db": backend,
            "path": input_file,
            "query": query,
            "top_k": 5,
            "delete_after": True
        }
        
        start_time = time.perf_counter()
        
        try:
            vector_store_demo(**params)
            elapsed = time.perf_counter() - start_time
            results[backend] = elapsed
            print(f"✓ {backend.upper()}: {elapsed:.3f} seconds")
        except Exception as e:
            print(f"✗ {backend.upper()} failed: {e}")
            results[backend] = -1
    
    # Display results
    print("\n" + "=" * 60)
    print("Benchmark Results")
    print("=" * 60)
    
    valid_results = {k: v for k, v in results.items() if v > 0}
    
    if valid_results:
        fastest = min(valid_results, key=valid_results.get)
        print(f"\nFastest: {fastest.upper()} ({valid_results[fastest]:.3f}s)")
        
        print("\nAll Results:")
        for backend, time_taken in sorted(valid_results.items(), key=lambda x: x[1]):
            print(f"  {backend.upper():.<20} {time_taken:.3f}s")
    else:
        print("No successful benchmarks to compare")


if __name__ == "__main__":
    # Choose which demo to run
    import sys
    
    if len(sys.argv) > 1:
        match sys.argv[1]:
            case "multi":
                run_multi_backend_demo()
            case "benchmark":
                run_benchmark_demo()
            case _:
                print(f"Unknown demo mode: {sys.argv[1]}")
                print("Available modes: multi, benchmark")
                print("Running default demo...")
                main()
    else:
        # Run default single-backend demo
        main()
