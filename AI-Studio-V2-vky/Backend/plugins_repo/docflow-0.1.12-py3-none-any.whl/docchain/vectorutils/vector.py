"""Multi-backend vector store with embedding generation and document indexing."""

import json
import os
import uuid
from contextlib import closing
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Protocol

import chromadb
import psycopg2
import pymongo
import snowflake.connector
from dotenv import load_dotenv
from neo4j import GraphDatabase
from openai import OpenAI


load_dotenv()


# Type aliases
VectorDB = Literal["chroma", "postgres", "mongo_atlas", "snowflake", "neo4j"]


# Exceptions
class VectorStoreError(Exception):
    """Base exception for vector store operations."""
    pass


class DatabaseConnectionError(VectorStoreError):
    """Raised when database connection fails."""
    pass


class EmbeddingGenerationError(VectorStoreError):
    """Raised when embedding generation fails."""
    pass


# Protocol for database operations
class VectorDBProtocol(Protocol):
    """Protocol defining vector database interface."""
    
    def index(self, ids: list[str], texts: list[str], embeddings: list[list[float]]) -> None:
        """Index documents with embeddings."""
        ...
    
    def query(self, query_embedding: list[float], top_k: int) -> list[dict[str, Any]]:
        """Query for similar documents."""
        ...
    
    def delete(self, doc_id: str) -> None:
        """Delete document by ID."""
        ...


def get_openai_client() -> OpenAI:
    """
    Get OpenAI client with API key from environment.
    
    Returns:
        Initialized OpenAI client
    
    Raises:
        ValueError: If OPENAI_API_KEY not set
    """
    api_key = os.getenv("OPENAI_API_KEY")
    
    if not api_key:
        raise ValueError(
            "OPENAI_API_KEY is not set in environment. "
            "Please add it to your .env file."
        )
    
    return OpenAI(api_key=api_key)


@dataclass
class VectorStoreConfig:
    """Configuration for vector store backends."""
    
    database: VectorDB
    namespace: str = "main_namespace"
    embedding_model: str = "text-embedding-3-small"
    embedding_dim: int = 1536
    
    # Database-specific configs
    postgres_table: str = "vectors"
    mongo_collection: str | None = None
    
    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        if self.database not in VectorStore.SUPPORTED_DBS:
            raise ValueError(
                f"Unsupported database: {self.database}. "
                f"Choose from: {', '.join(VectorStore.SUPPORTED_DBS)}"
            )


class VectorStore:
    """Universal vector store supporting multiple backends."""
    
    SUPPORTED_DBS: set[str] = {"chroma", "postgres", "mongo_atlas", "snowflake", "neo4j"}
    
    def __init__(
        self,
        database: VectorDB,
        namespace: str = "main_namespace",
        config: VectorStoreConfig | None = None
    ) -> None:
        """
        Initialize vector store with specified backend.
        
        Args:
            database: Database backend to use
            namespace: Namespace/collection name
            config: Optional configuration object
        
        Raises:
            DatabaseConnectionError: If connection fails
            ValueError: If database type unsupported
        """
        self.config = config or VectorStoreConfig(database=database, namespace=namespace)
        self.database = database
        self.namespace = namespace
        
        # Initialize backend
        self._initialize_backend()

    def _initialize_backend(self) -> None:
        """Initialize the appropriate database backend."""
        try:
            match self.database:
                case "chroma":
                    self._init_chroma()
                case "postgres":
                    self._init_postgres()
                case "mongo_atlas":
                    self._init_mongo()
                case "snowflake":
                    self._init_snowflake()
                case "neo4j":
                    self._init_neo4j()
                case _:
                    raise ValueError(
                        f"Unsupported database: {self.database}. "
                        f"Choose from: {', '.join(self.SUPPORTED_DBS)}"
                    )
        except Exception as e:
            raise DatabaseConnectionError(
                f"Failed to initialize {self.database}: {e}"
            ) from e

    def _init_chroma(self) -> None:
        """Initialize ChromaDB backend."""
        self.client = chromadb.Client()
        self.collection = self.client.get_or_create_collection(name=self.namespace)

    def _init_postgres(self) -> None:
        """Initialize PostgreSQL backend with pgvector."""
        self.conn = psycopg2.connect(
            dbname=os.getenv("PG_DB"),
            user=os.getenv("PG_USER"),
            password=os.getenv("PG_PASSWORD"),
            host=os.getenv("PG_HOST", "localhost"),
            port=os.getenv("PG_PORT", "5432")
        )
        self._create_postgres_table()

    def _create_postgres_table(self) -> None:
        """Create vectors table in PostgreSQL if it doesn't exist."""
        table_name = self.config.postgres_table
        
        with closing(self.conn.cursor()) as cur:
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {table_name} (
                    id TEXT PRIMARY KEY,
                    namespace TEXT NOT NULL,
                    content TEXT NOT NULL,
                    embedding vector({self.config.embedding_dim}),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    metadata JSONB
                );
                
                CREATE INDEX IF NOT EXISTS idx_{table_name}_namespace 
                ON {table_name}(namespace);
            """)
        self.conn.commit()

    def _init_mongo(self) -> None:
        """Initialize MongoDB Atlas backend."""
        uri = os.getenv("MONGO_ATLAS_URI")
        if not uri:
            raise ValueError("MONGO_ATLAS_URI not set in environment")
        
        self.mongo_client = pymongo.MongoClient(uri)
        db_name = os.getenv("MONGO_DB", "vector_db")
        self.mongo_db = self.mongo_client[db_name]
        
        collection_name = self.config.mongo_collection or self.namespace
        self.mongo_col = self.mongo_db[collection_name]
        
        # Create index for vector search
        self.mongo_col.create_index([("namespace", pymongo.ASCENDING)])

    def _init_snowflake(self) -> None:
        """Initialize Snowflake backend."""
        self.snowflake_conn = snowflake.connector.connect(
            user=os.getenv("SNOWFLAKE_USER"),
            password=os.getenv("SNOWFLAKE_PASSWORD"),
            account=os.getenv("SNOWFLAKE_ACCOUNT"),
            warehouse=os.getenv("SNOWFLAKE_WAREHOUSE"),
            database=os.getenv("SNOWFLAKE_DATABASE"),
            schema=os.getenv("SNOWFLAKE_SCHEMA")
        )

    def _init_neo4j(self) -> None:
        """Initialize Neo4j graph database backend."""
        uri = os.getenv("NEO4J_URI")
        user = os.getenv("NEO4J_USER")
        password = os.getenv("NEO4J_PASSWORD")
        
        if not all([uri, user, password]):
            raise ValueError("NEO4J_URI, NEO4J_USER, and NEO4J_PASSWORD must be set")
        
        self.neo4j_driver = GraphDatabase.driver(uri, auth=(user, password))

    def generate_embedding(self, text: str) -> list[float]:
        """
        Generate embedding vector for text using OpenAI.
        
        Args:
            text: Text to embed
        
        Returns:
            Embedding vector
        
        Raises:
            EmbeddingGenerationError: If embedding generation fails
        """
        try:
            client = get_openai_client()
            response = client.embeddings.create(
                input=[text],
                model=self.config.embedding_model
            )
            return response.data[0].embedding
        except Exception as e:
            raise EmbeddingGenerationError(
                f"Failed to generate embedding: {e}"
            ) from e

    def index_document(
        self,
        doc_id: str,
        text: str,
        metadata: dict[str, Any] | None = None
    ) -> None:
        """
        Index a single document with its embedding.
        
        Args:
            doc_id: Unique document identifier
            text: Document text content
            metadata: Optional metadata to store with document
        """
        embedding = self.generate_embedding(text)
        self._index([doc_id], [text], [embedding], [metadata or {}])

    def index_file(self, file_path: str | Path) -> str:
        """
        Index a file by reading its contents.
        
        Args:
            file_path: Path to file to index
        
        Returns:
            Generated document ID
        """
        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        content = path.read_text(encoding="utf-8")
        doc_id = f"{path.stem}_{uuid.uuid4().hex[:6]}"
        
        self.index_document(doc_id, content, metadata={"filename": path.name})
        print(f"✓ Indexed: {path.name} (ID: {doc_id})")
        
        return doc_id

    def _index(
        self,
        ids: list[str],
        texts: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict[str, Any]] | None = None
    ) -> None:
        """
        Internal method to index documents across different backends.
        
        Args:
            ids: List of document IDs
            texts: List of document texts
            embeddings: List of embedding vectors
            metadatas: Optional list of metadata dicts
        """
        if metadatas is None:
            metadatas = [{} for _ in ids]
        
        match self.database:
            case "chroma":
                self._index_chroma(ids, texts, embeddings, metadatas)
            case "postgres":
                self._index_postgres(ids, texts, embeddings, metadatas)
            case "mongo_atlas":
                self._index_mongo(ids, texts, embeddings, metadatas)
            case "snowflake":
                self._index_snowflake(ids, texts, embeddings, metadatas)
            case "neo4j":
                self._index_neo4j(ids, texts, embeddings, metadatas)

    def _index_chroma(
        self,
        ids: list[str],
        texts: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict[str, Any]]
    ) -> None:
        """Index documents in ChromaDB."""
        self.collection.add(
            documents=texts,
            ids=ids,
            embeddings=embeddings,
            metadatas=metadatas
        )

    def _index_postgres(
        self,
        ids: list[str],
        texts: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict[str, Any]]
    ) -> None:
        """Index documents in PostgreSQL with pgvector."""
        table_name = self.config.postgres_table
        
        with closing(self.conn.cursor()) as cur:
            for id_, text, vec, meta in zip(ids, texts, embeddings, metadatas):
                cur.execute(f"""
                    INSERT INTO {table_name} (id, namespace, content, embedding, metadata)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (id) DO UPDATE
                    SET content = EXCLUDED.content,
                        embedding = EXCLUDED.embedding,
                        metadata = EXCLUDED.metadata;
                """, (id_, self.namespace, text, vec, json.dumps(meta)))
        self.conn.commit()

    def _index_mongo(
        self,
        ids: list[str],
        texts: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict[str, Any]]
    ) -> None:
        """Index documents in MongoDB Atlas."""
        for id_, text, vec, meta in zip(ids, texts, embeddings, metadatas):
            self.mongo_col.update_one(
                {"_id": id_},
                {
                    "$set": {
                        "namespace": self.namespace,
                        "content": text,
                        "embedding": vec,
                        "metadata": meta
                    }
                },
                upsert=True
            )

    def _index_snowflake(
        self,
        ids: list[str],
        texts: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict[str, Any]]
    ) -> None:
        """Index documents in Snowflake."""
        with closing(self.snowflake_conn.cursor()) as cur:
            # Create table if not exists
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {self.namespace} (
                    id STRING PRIMARY KEY,
                    content STRING,
                    embedding STRING,
                    metadata VARIANT
                )
            """)
            
            # Insert/update documents
            for id_, text, vec, meta in zip(ids, texts, embeddings, metadatas):
                vec_str = json.dumps(vec)
                meta_str = json.dumps(meta)
                
                cur.execute(f"""
                    MERGE INTO {self.namespace} t
                    USING (SELECT %s AS id, %s AS content, %s AS embedding, PARSE_JSON(%s) AS metadata) s
                    ON t.id = s.id
                    WHEN MATCHED THEN 
                        UPDATE SET content = s.content, embedding = s.embedding, metadata = s.metadata
                    WHEN NOT MATCHED THEN 
                        INSERT (id, content, embedding, metadata)
                        VALUES (s.id, s.content, s.embedding, s.metadata)
                """, (id_, text, vec_str, meta_str))

    def _index_neo4j(
        self,
        ids: list[str],
        texts: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict[str, Any]]
    ) -> None:
        """Index documents in Neo4j graph database."""
        with self.neo4j_driver.session() as session:
            for id_, text, vec, meta in zip(ids, texts, embeddings, metadatas):
                session.run("""
                    MERGE (d:Document {id: $id})
                    SET d.content = $content,
                        d.namespace = $namespace,
                        d.embedding = $embedding,
                        d.metadata = $metadata
                """, {
                    "id": id_,
                    "content": text,
                    "namespace": self.namespace,
                    "embedding": json.dumps(vec),
                    "metadata": json.dumps(meta)
                })

    def delete_document(self, doc_id: str) -> None:
        """
        Delete document by ID from vector store.
        
        Args:
            doc_id: Document ID to delete
        """
        if not doc_id:
            return
        
        print(f"🗑️  Deleting document: {doc_id}")
        
        match self.database:
            case "chroma":
                self.collection.delete(ids=[doc_id])
            case "postgres":
                with closing(self.conn.cursor()) as cur:
                    cur.execute(
                        f"DELETE FROM {self.config.postgres_table} WHERE id = %s",
                        (doc_id,)
                    )
                self.conn.commit()
            case "mongo_atlas":
                self.mongo_col.delete_one({"_id": doc_id})
            case "snowflake":
                with closing(self.snowflake_conn.cursor()) as cur:
                    cur.execute(
                        f"DELETE FROM {self.namespace} WHERE id = %s",
                        (doc_id,)
                    )
            case "neo4j":
                with self.neo4j_driver.session() as session:
                    session.run(
                        "MATCH (d:Document {id: $id}) DETACH DELETE d",
                        {"id": doc_id}
                    )

    def query(self, query_text: str, top_k: int = 3) -> list[dict[str, Any]]:
        """
        Query vector store for similar documents.
        
        Args:
            query_text: Query text
            top_k: Number of results to return
        
        Returns:
            List of similar documents with metadata
        """
        # Generate query embedding
        query_embedding = self.generate_embedding(query_text)
        
        match self.database:
            case "chroma":
                results = self.collection.query(
                    query_embeddings=[query_embedding],
                    n_results=top_k
                )
                return [
                    {
                        "id": results["ids"][0][i],
                        "content": results["documents"][0][i],
                        "metadata": results["metadatas"][0][i] if results.get("metadatas") else {}
                    }
                    for i in range(len(results["ids"][0]))
                ]
            case "mongo_atlas":
                # Simple MongoDB query (without vector search)
                docs = list(self.mongo_col.find(
                    {"namespace": self.namespace},
                    {"_id": 1, "content": 1, "metadata": 1}
                ).limit(top_k))
                
                return [
                    {
                        "id": str(doc["_id"]),
                        "content": doc.get("content", ""),
                        "metadata": doc.get("metadata", {})
                    }
                    for doc in docs
                ]
            case _:
                # Placeholder for other backends
                return [{"info": f"{self.database} query (top_k={top_k})"}]

    def __del__(self) -> None:
        """Cleanup database connections."""
        if hasattr(self, 'conn') and self.conn:
            self.conn.close()
        if hasattr(self, 'snowflake_conn') and self.snowflake_conn:
            self.snowflake_conn.close()
        if hasattr(self, 'neo4j_driver') and self.neo4j_driver:
            self.neo4j_driver.close()
        if hasattr(self, 'mongo_client') and self.mongo_client:
            self.mongo_client.close()


# Utility Functions
def index_path(
    path: str | Path,
    database: VectorDB,
    namespace: str = "main_namespace"
) -> str | None:
    """
    Index file or directory at given path.
    
    Args:
        path: File or directory path to index
        database: Vector database backend
        namespace: Namespace for indexed documents
    
    Returns:
        Document ID if single file, None if directory
    """
    store = VectorStore(database, namespace)
    file_path = Path(path)
    
    if file_path.is_dir():
        print(f"📁 Indexing directory: {file_path}")
        for file in file_path.iterdir():
            if file.is_file():
                try:
                    store.index_file(file)
                except Exception as e:
                    print(f"⚠️  Skipping {file.name}: {e}")
        print("✅ Directory indexing complete")
        return None
    
    elif file_path.is_file():
        return store.index_file(file_path)
    
    else:
        raise FileNotFoundError(f"Invalid path: {file_path}")


def vector_store_demo(
    db: VectorDB,
    path: str | Path,
    query: str = "hello",
    top_k: int = 3,
    namespace: str = "main_namespace",
    delete_after: bool = False
) -> None:
    """
    Demonstration of vector store functionality.
    
    Args:
        db: Database backend to use
        path: Path to file/directory to index
        query: Query text for similarity search
        top_k: Number of results to return
        namespace: Namespace for documents
        delete_after: Whether to delete indexed documents after demo
    """
    if db not in VectorStore.SUPPORTED_DBS:
        raise ValueError(
            f"Invalid database '{db}'. "
            f"Choose from: {', '.join(VectorStore.SUPPORTED_DBS)}"
        )
    
    print(f"\n{'='*60}")
    print(f"Vector Store Demo: {db.upper()}")
    print(f"{'='*60}\n")
    
    # Index documents
    store = VectorStore(db, namespace)
    doc_id = index_path(path, db, namespace)
    
    if doc_id:
        print(f"\n📝 Indexed document ID: {doc_id}")
    
    # Query for similar documents
    print(f"\n🔍 Searching for: '{query}' (top-{top_k} results)")
    results = store.query(query, top_k)
    
    print(f"\n{'='*60}")
    print("Search Results")
    print(f"{'='*60}")
    
    for i, result in enumerate(results, 1):
        print(f"\n{i}. {result}")
    
    # Optional cleanup
    if delete_after and doc_id:
        print(f"\n{'='*60}")
        store.delete_document(doc_id)
        print(f"✅ Cleanup complete")
    
    print(f"\n{'='*60}")
    print("Demo Complete!")
    print(f"{'='*60}\n")
