"""
Frontend Utilities API Package

A comprehensive FastAPI-based API framework with integrated routers for:
- LLM operations and model management
- Document management and storage
- Analytics and health monitoring
- Static file serving and frontend integration

This package provides a production-ready API with CORS support, middleware,
exception handling, and configurable handlers.
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__license__ = "MIT"
__all__ = [
    # Main API Class
    "FrontendUtilsAPI",
    
    # Configuration
    "APIConfig",
    "ErrorResponse",
    
    # Factory Functions
    "create_api",
    "create_api_with_config",
    
    # Router Modules
    "llm",
    "documents",
    "analytics",
    
    # Handlers
    "set_llm_handler",
    "set_async_llm_handler",
    "get_llm_handler",
]


# ================= Core Imports =================

from .frontend_api import (
    APIConfig,
    ErrorResponse,
    FrontendUtilsAPI,
    create_api,
    create_api_with_config,
)

# ================= Router Imports =================

from .routers import analytics, documents, llm

# ================= Handler Functions =================

# Re-export handler registration functions for convenience
from .routers.llm import (
    get_llm_handler,
    set_async_llm_handler,
    set_llm_handler,
)


# ================= Package Information =================

__package_info__ = {
    "name": "frontend_utils",
    "version": __version__,
    "description": "FastAPI framework with LLM, document management, and analytics",
    "author": __author__,
    "license": __license__,
    "features": [
        "Multi-router architecture (LLM, Documents, Analytics)",
        "CORS and security middleware",
        "Static file serving",
        "Comprehensive exception handling",
        "Health monitoring and status endpoints",
        "Async and sync handler support",
        "Configurable API factory",
    ],
    "routers": {
        "llm": {
            "prefix": "/llm",
            "endpoints": ["ask", "ask/batch", "models", "models/{model_id}", "status", "validate"],
            "description": "LLM operations and model management",
        },
        "documents": {
            "prefix": "/documents",
            "endpoints": ["upload", "upload/batch", "list", "{document_id}", "delete/batch", "{document_id}/download"],
            "description": "Document upload, retrieval, and management",
        },
        "analytics": {
            "prefix": "/analytics",
            "endpoints": ["stats", "stats/detailed", "stats/topics/{topic}", "health", "health/live", "health/ready", "events"],
            "description": "Analytics metrics and health monitoring",
        },
    },
}


# ================= Quick Start Functions =================

def get_version() -> str:
    """
    Get the package version.
    
    Returns:
        Version string
    """
    return __version__


def print_package_info() -> None:
    """Print detailed package information."""
    info = __package_info__
    
    print(f"\n{'='*70}")
    print(f"{info['name'].upper()} v{info['version']}")
    print(f"{'='*70}")
    print(f"\n{info['description']}\n")
    
    print("Features:")
    for feature in info['features']:
        print(f"  • {feature}")
    
    print("\nAvailable Routers:")
    for router_name, router_info in info['routers'].items():
        print(f"\n  {router_name.upper()} ({router_info['prefix']})")
        print(f"  {router_info['description']}")
        print(f"  Endpoints: {', '.join(router_info['endpoints'][:3])}...")
    
    print(f"\n{'='*70}\n")


def quick_start_example() -> str:
    """
    Get a quick start code example.
    
    Returns:
        Example code as string
    """
    return '''
# Quick Start Example

from frontend_utils import create_api

# Define your LLM handler
def my_llm_handler(query: str, metadata: dict) -> str:
    # Your LLM logic here
    return f"Response to: {query}"

# Create the API
app = create_api(
    llm_handler=my_llm_handler,
    title="My API",
    version="1.0.0",
    allow_origins=["http://localhost:3000"]
)

# Run with: uvicorn main:app --reload

# Access documentation at: http://localhost:8000/docs
'''


def create_default_api() -> "FrontendUtilsAPI":
    """
    Create an API with default example handlers (for testing).
    
    Returns:
        FrontendUtilsAPI instance with example handlers
    
    Example:
        >>> from frontend_utils import create_default_api
        >>> api = create_default_api()
        >>> app = api.get_app()
    """
    def example_llm_handler(query: str, metadata: dict) -> str:
        """Example LLM handler."""
        return f"Example response to: {query}"
    
    config = APIConfig(
        title="Example API",
        description="API with example handlers for testing",
        version=__version__,
        allow_origins=["*"],
        debug=True,
    )
    
    return FrontendUtilsAPI(
        llm_handler=example_llm_handler,
        config=config
    )


# ================= Validation Functions =================

def validate_installation() -> dict[str, bool]:
    """
    Validate that all dependencies are properly installed.
    
    Returns:
        Dictionary of component availability
    """
    components = {
        "fastapi": False,
        "pydantic": False,
        "uvicorn": False,
        "llm_router": False,
        "documents_router": False,
        "analytics_router": False,
    }
    
    # Check FastAPI
    try:
        import fastapi
        components["fastapi"] = True
    except ImportError:
        pass
    
    # Check Pydantic
    try:
        import pydantic
        components["pydantic"] = True
    except ImportError:
        pass
    
    # Check Uvicorn
    try:
        import uvicorn
        components["uvicorn"] = True
    except ImportError:
        pass
    
    # Check routers
    try:
        from .routers import llm, documents, analytics
        components["llm_router"] = True
        components["documents_router"] = True
        components["analytics_router"] = True
    except ImportError:
        pass
    
    return components


def check_setup() -> bool:
    """
    Check if the package is properly set up.
    
    Returns:
        True if all components are available, False otherwise
    """
    components = validate_installation()
    all_available = all(components.values())
    
    if not all_available:
        print("⚠️  Some components are missing:")
        for component, available in components.items():
            status = "✓" if available else "✗"
            print(f"  {status} {component}")
        print("\nInstall missing dependencies with: pip install -r requirements.txt")
    else:
        print("✓ All components are properly installed!")
    
    return all_available


# ================= Router Access =================

def get_routers() -> dict[str, Any]:
    """
    Get all available routers.
    
    Returns:
        Dictionary mapping router names to router objects
    """
    return {
        "llm": llm.router,
        "documents": documents.router,
        "analytics": analytics.router,
    }


def list_endpoints() -> dict[str, list[str]]:
    """
    List all available endpoints by router.
    
    Returns:
        Dictionary mapping router names to endpoint lists
    """
    endpoints = {}
    
    for router_name, router_info in __package_info__["routers"].items():
        endpoints[router_name] = [
            f"{router_info['prefix']}/{endpoint}"
            for endpoint in router_info["endpoints"]
        ]
    
    return endpoints


# ================= Lazy Imports =================

def __getattr__(name: str):
    """
    Lazy import for optional modules.
    
    Args:
        name: Attribute name to import
    
    Raises:
        AttributeError: If attribute doesn't exist
    """
    # Add lazy loading for heavy modules if needed
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


# ================= Development Helpers =================

def create_test_app() -> "FrontendUtilsAPI":
    """
    Create a test API instance with mock handlers.
    
    Returns:
        FrontendUtilsAPI instance configured for testing
    """
    def test_llm_handler(query: str, metadata: dict) -> str:
        return f"Test response: {query}"
    
    config = APIConfig(
        title="Test API",
        description="API configured for testing",
        version=f"{__version__}-test",
        allow_origins=["*"],
        debug=True,
        enable_docs=True,
    )
    
    return FrontendUtilsAPI(
        llm_handler=test_llm_handler,
        config=config
    )


def get_openapi_schema(app: "FrontendUtilsAPI" | None = None) -> dict:
    """
    Get the OpenAPI schema for the API.
    
    Args:
        app: FrontendUtilsAPI instance (creates test app if None)
    
    Returns:
        OpenAPI schema dictionary
    """
    if app is None:
        app = create_test_app()
    
    fastapi_app = app.get_app()
    return fastapi_app.openapi()


# ================= Module Initialization =================

def _initialize_module() -> None:
    """Initialize module (called on import)."""
    import logging
    
    logger = logging.getLogger(__name__)
    logger.info(f"Frontend Utils API v{__version__} loaded")
    
    # Check if running in development mode
    import sys
    if any(arg in sys.argv for arg in ['--dev', '--debug']):
        logger.setLevel(logging.DEBUG)
        logger.debug("Debug mode enabled")


# Run initialization
_initialize_module()


# ================= Deprecation Warnings =================

def _deprecated_import(old_name: str, new_name: str):
    """Helper for deprecated imports."""
    import warnings
    warnings.warn(
        f"'{old_name}' is deprecated, use '{new_name}' instead",
        DeprecationWarning,
        stacklevel=2
    )


# ================= Export Verification =================

if __name__ == "__main__":
    # When run as a script, show package info
    print_package_info()
    print("\nQuick Start:")
    print(quick_start_example())
    print("\nValidating installation...")
    check_setup()
