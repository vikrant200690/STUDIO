"""Document management API router for upload, retrieval, and deletion operations."""

import mimetypes
import uuid
from datetime import datetime
from pathlib import Path
from typing import Annotated, Literal

from fastapi import (
    APIRouter,
    BackgroundTasks,
    File,
    HTTPException,
    Query,
    UploadFile,
    status,
)
from pydantic import BaseModel, ConfigDict, Field, field_validator


# Create router with configuration
router = APIRouter(
    prefix="/documents",
    tags=["Document Management"],
    responses={
        404: {"description": "Document not found"},
        500: {"description": "Internal server error"},
    },
)


# ================= Configuration =================

class DocumentConfig:
    """Configuration for document handling."""
    
    UPLOAD_DIR = Path("uploads")
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB
    ALLOWED_EXTENSIONS = {".pdf", ".txt", ".docx", ".doc", ".xlsx", ".csv", ".json"}
    ALLOWED_MIME_TYPES = {
        "application/pdf",
        "text/plain",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "text/csv",
        "application/json",
    }


# ================= Models =================

class DocumentMetadata(BaseModel):
    """Metadata for a document."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "filename": "report.pdf",
                "size": 1024576,
                "mime_type": "application/pdf",
                "uploaded_at": "2025-12-09T16:47:00Z"
            }
        }
    )
    
    filename: str = Field(..., min_length=1, max_length=255)
    size: int = Field(..., ge=0, description="File size in bytes")
    mime_type: str = Field(..., description="MIME type of the document")
    uploaded_at: datetime = Field(default_factory=datetime.utcnow)
    tags: list[str] = Field(default_factory=list, max_length=20)
    
    @field_validator("filename")
    @classmethod
    def validate_filename(cls, v: str) -> str:
        """Validate filename doesn't contain path traversal characters."""
        if ".." in v or "/" in v or "\\" in v:
            raise ValueError("Invalid filename: contains path traversal characters")
        return v


class DocumentResponse(BaseModel):
    """Response model for document operations."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "message": "Document uploaded successfully",
                "document_id": "doc_a1b2c3d4",
                "metadata": {
                    "filename": "report.pdf",
                    "size": 1024576,
                    "mime_type": "application/pdf",
                    "uploaded_at": "2025-12-09T16:47:00Z"
                }
            }
        }
    )
    
    message: str = Field(..., description="Operation result message")
    document_id: str | None = Field(None, description="Unique document identifier")
    metadata: DocumentMetadata | None = Field(None, description="Document metadata")


class DocumentListResponse(BaseModel):
    """Response model for document listing."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "documents": [
                    {
                        "id": "doc_123",
                        "filename": "report.pdf",
                        "size": 1024576,
                        "uploaded_at": "2025-12-09T16:47:00Z"
                    }
                ],
                "total": 1,
                "page": 1,
                "page_size": 10
            }
        }
    )
    
    documents: list[dict[str, Any]] = Field(
        ...,
        description="List of documents with metadata"
    )
    total: int = Field(..., ge=0, description="Total number of documents")
    page: int = Field(default=1, ge=1, description="Current page number")
    page_size: int = Field(default=10, ge=1, le=100, description="Items per page")


class DocumentUpdateRequest(BaseModel):
    """Request model for updating document metadata."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "tags": ["report", "quarterly", "2025"],
                "metadata": {"department": "sales"}
            }
        }
    )
    
    tags: list[str] | None = Field(None, max_length=20)
    metadata: dict[str, Any] | None = Field(None)


class BulkDeleteRequest(BaseModel):
    """Request model for bulk document deletion."""
    
    document_ids: list[str] = Field(
        ...,
        min_length=1,
        max_length=100,
        description="List of document IDs to delete"
    )


# ================= Helper Functions =================

def validate_file_size(file: UploadFile) -> None:
    """
    Validate file size doesn't exceed limit.
    
    Args:
        file: Uploaded file
    
    Raises:
        HTTPException: If file is too large
    """
    if hasattr(file, 'size') and file.size > DocumentConfig.MAX_FILE_SIZE:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File too large. Maximum size: {DocumentConfig.MAX_FILE_SIZE / (1024*1024):.1f}MB"
        )


def validate_file_type(file: UploadFile) -> None:
    """
    Validate file type is allowed.
    
    Args:
        file: Uploaded file
    
    Raises:
        HTTPException: If file type not allowed
    """
    # Check extension
    file_ext = Path(file.filename).suffix.lower()
    if file_ext not in DocumentConfig.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"File type {file_ext} not allowed. Allowed types: {', '.join(DocumentConfig.ALLOWED_EXTENSIONS)}"
        )
    
    # Check MIME type
    if file.content_type not in DocumentConfig.ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"MIME type {file.content_type} not allowed"
        )


def generate_document_id() -> str:
    """Generate unique document ID."""
    return f"doc_{uuid.uuid4().hex[:12]}"


async def save_file(file: UploadFile, doc_id: str) -> Path:
    """
    Save uploaded file to disk.
    
    Args:
        file: Uploaded file
        doc_id: Document ID for naming
    
    Returns:
        Path to saved file
    """
    # Ensure upload directory exists
    DocumentConfig.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    
    # Generate safe filename
    file_ext = Path(file.filename).suffix
    safe_filename = f"{doc_id}{file_ext}"
    file_path = DocumentConfig.UPLOAD_DIR / safe_filename
    
    # Save file
    content = await file.read()
    file_path.write_bytes(content)
    
    return file_path


def process_document_background(file_path: Path, doc_id: str) -> None:
    """
    Background task to process document (e.g., extract text, generate thumbnail).
    
    Args:
        file_path: Path to document file
        doc_id: Document ID
    """
    # Add processing logic here (e.g., text extraction, indexing)
    print(f"Processing document {doc_id} at {file_path}")


# ================= API Endpoints =================

@router.post(
    "/upload",
    response_model=DocumentResponse,
    summary="Upload a document",
    description="Upload a document file with validation and metadata extraction",
    status_code=status.HTTP_201_CREATED,
)
async def upload_document(
    background_tasks: BackgroundTasks,
    file: Annotated[UploadFile, File(description="Document file to upload")],
    tags: Annotated[
        list[str] | None,
        Query(description="Optional tags for the document")
    ] = None,
) -> DocumentResponse:
    """
    Upload a document with validation and processing.
    
    Args:
        background_tasks: FastAPI background tasks
        file: Document file to upload
        tags: Optional tags for categorization
    
    Returns:
        DocumentResponse: Upload confirmation with document ID and metadata
    
    Raises:
        HTTPException: If validation fails or upload errors occur
    """
    try:
        # Validate file
        validate_file_size(file)
        validate_file_type(file)
        
        # Generate document ID
        doc_id = generate_document_id()
        
        # Save file
        file_path = await save_file(file, doc_id)
        
        # Create metadata
        metadata = DocumentMetadata(
            filename=file.filename,
            size=file_path.stat().st_size,
            mime_type=file.content_type or "application/octet-stream",
            uploaded_at=datetime.utcnow(),
            tags=tags or [],
        )
        
        # Schedule background processing
        background_tasks.add_task(process_document_background, file_path, doc_id)
        
        return DocumentResponse(
            message=f"Document '{file.filename}' uploaded successfully",
            document_id=doc_id,
            metadata=metadata,
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Document upload failed: {str(e)}",
        ) from e


@router.post(
    "/upload/batch",
    response_model=list[DocumentResponse],
    summary="Upload multiple documents",
    description="Batch upload multiple document files",
    status_code=status.HTTP_201_CREATED,
)
async def upload_documents_batch(
    background_tasks: BackgroundTasks,
    files: Annotated[
        list[UploadFile],
        File(description="Multiple document files to upload")
    ],
) -> list[DocumentResponse]:
    """
    Upload multiple documents in batch.
    
    Args:
        background_tasks: FastAPI background tasks
        files: List of document files to upload
    
    Returns:
        List of DocumentResponse: Upload results for each file
    """
    if len(files) > 10:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Maximum 10 files allowed per batch upload"
        )
    
    responses: list[DocumentResponse] = []
    
    for file in files:
        try:
            result = await upload_document(background_tasks, file)
            responses.append(result)
        except HTTPException as e:
            responses.append(
                DocumentResponse(
                    message=f"Failed to upload {file.filename}: {e.detail}",
                    document_id=None,
                    metadata=None,
                )
            )
    
    return responses


@router.get(
    "/list",
    response_model=DocumentListResponse,
    summary="List documents",
    description="Retrieve paginated list of documents with filtering options",
    status_code=status.HTTP_200_OK,
)
async def list_documents(
    page: Annotated[int, Query(ge=1, description="Page number")] = 1,
    page_size: Annotated[int, Query(ge=1, le=100, description="Items per page")] = 10,
    sort_by: Annotated[
        Literal["filename", "size", "uploaded_at"],
        Query(description="Field to sort by")
    ] = "uploaded_at",
    order: Annotated[
        Literal["asc", "desc"],
        Query(description="Sort order")
    ] = "desc",
    search: Annotated[
        str | None,
        Query(min_length=1, max_length=100, description="Search query")
    ] = None,
) -> DocumentListResponse:
    """
    List documents with pagination and filtering.
    
    Args:
        page: Page number (1-indexed)
        page_size: Number of items per page
        sort_by: Field to sort results by
        order: Sort order (ascending or descending)
        search: Optional search query
    
    Returns:
        DocumentListResponse: Paginated list of documents
    """
    # Mock data - replace with actual database query
    all_documents = [
        {
            "id": "doc_123",
            "filename": "report.pdf",
            "size": 1024576,
            "mime_type": "application/pdf",
            "uploaded_at": "2025-12-09T16:00:00Z",
            "tags": ["report", "quarterly"],
        },
        {
            "id": "doc_456",
            "filename": "data.csv",
            "size": 51200,
            "mime_type": "text/csv",
            "uploaded_at": "2025-12-09T15:30:00Z",
            "tags": ["data"],
        },
        {
            "id": "doc_789",
            "filename": "presentation.docx",
            "size": 2048000,
            "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "uploaded_at": "2025-12-09T14:00:00Z",
            "tags": ["presentation"],
        },
    ]
    
    # Apply search filter
    if search:
        all_documents = [
            doc for doc in all_documents
            if search.lower() in doc["filename"].lower()
        ]
    
    # Calculate pagination
    total = len(all_documents)
    start_idx = (page - 1) * page_size
    end_idx = start_idx + page_size
    paginated_docs = all_documents[start_idx:end_idx]
    
    return DocumentListResponse(
        documents=paginated_docs,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get(
    "/{document_id}",
    response_model=DocumentResponse,
    summary="Get document details",
    description="Retrieve detailed information about a specific document",
    status_code=status.HTTP_200_OK,
)
async def get_document(
    document_id: Annotated[str, Field(min_length=1, max_length=100)]
) -> DocumentResponse:
    """
    Get document metadata by ID.
    
    Args:
        document_id: Unique document identifier
    
    Returns:
        DocumentResponse: Document details and metadata
    
    Raises:
        HTTPException: If document not found
    """
    # Mock data - replace with actual database query
    if not document_id.startswith("doc_"):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{document_id}' not found"
        )
    
    metadata = DocumentMetadata(
        filename="report.pdf",
        size=1024576,
        mime_type="application/pdf",
        uploaded_at=datetime.utcnow(),
        tags=["report"],
    )
    
    return DocumentResponse(
        message="Document retrieved successfully",
        document_id=document_id,
        metadata=metadata,
    )


@router.patch(
    "/{document_id}",
    response_model=DocumentResponse,
    summary="Update document metadata",
    description="Update tags and metadata for a document",
    status_code=status.HTTP_200_OK,
)
async def update_document(
    document_id: Annotated[str, Field(min_length=1, max_length=100)],
    update_data: DocumentUpdateRequest,
) -> DocumentResponse:
    """
    Update document metadata.
    
    Args:
        document_id: Document ID to update
        update_data: Updated metadata
    
    Returns:
        DocumentResponse: Updated document information
    
    Raises:
        HTTPException: If document not found
    """
    # Verify document exists
    if not document_id.startswith("doc_"):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{document_id}' not found"
        )
    
    # Update metadata (in production, update database)
    return DocumentResponse(
        message=f"Document '{document_id}' updated successfully",
        document_id=document_id,
        metadata=None,
    )


@router.delete(
    "/{document_id}",
    summary="Delete document",
    description="Permanently delete a document by ID",
    status_code=status.HTTP_200_OK,
)
async def delete_document(
    document_id: Annotated[str, Field(min_length=1, max_length=100)]
) -> dict[str, str]:
    """
    Delete a document by ID.
    
    Args:
        document_id: Document ID to delete
    
    Returns:
        Success confirmation message
    
    Raises:
        HTTPException: If document not found or deletion fails
    """
    # Verify document exists
    if not document_id.startswith("doc_"):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{document_id}' not found"
        )
    
    # Delete file (in production, delete from storage and database)
    try:
        # file_path = DocumentConfig.UPLOAD_DIR / f"{document_id}.*"
        # file_path.unlink()
        pass
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete document: {str(e)}"
        ) from e
    
    return {
        "message": f"Document '{document_id}' deleted successfully",
        "document_id": document_id,
    }


@router.post(
    "/delete/batch",
    summary="Bulk delete documents",
    description="Delete multiple documents in a single request",
    status_code=status.HTTP_200_OK,
)
async def delete_documents_batch(
    request: BulkDeleteRequest
) -> dict[str, Any]:
    """
    Delete multiple documents in batch.
    
    Args:
        request: List of document IDs to delete
    
    Returns:
        Batch deletion results
    """
    results = {
        "deleted": [],
        "failed": [],
        "total": len(request.document_ids),
    }
    
    for doc_id in request.document_ids:
        try:
            await delete_document(doc_id)
            results["deleted"].append(doc_id)
        except HTTPException:
            results["failed"].append(doc_id)
    
    return results


@router.get(
    "/{document_id}/download",
    summary="Download document",
    description="Download document file by ID",
    status_code=status.HTTP_200_OK,
)
async def download_document(
    document_id: Annotated[str, Field(min_length=1, max_length=100)]
) -> dict[str, str]:
    """
    Download document file.
    
    Args:
        document_id: Document ID to download
    
    Returns:
        Download information (in production, return FileResponse)
    
    Raises:
        HTTPException: If document not found
    """
    # In production, use FileResponse to stream the file
    # from fastapi.responses import FileResponse
    # file_path = DocumentConfig.UPLOAD_DIR / f"{document_id}.*"
    # return FileResponse(file_path, media_type="application/octet-stream")
    
    if not document_id.startswith("doc_"):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{document_id}' not found"
        )
    
    return {
        "message": "Download endpoint",
        "document_id": document_id,
        "note": "Use FileResponse in production"
    }
