"""Analytics API router for tracking application metrics and health status."""

from datetime import datetime, timedelta
from typing import Annotated, Any, Literal

from fastapi import APIRouter, HTTPException, Query, status
from pydantic import BaseModel, Field, ConfigDict


# Create router with prefix and tags
router = APIRouter(
    prefix="/analytics",
    tags=["Analytics"],
    responses={
        404: {"description": "Not found"},
        500: {"description": "Internal server error"}
    }
)


# ================= Response Models =================

class AnalyticsResponse(BaseModel):
    """Response model for analytics statistics."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "total_queries": 1250,
                "avg_response_time": 0.85,
                "popular_topics": ["AI", "FastAPI", "Python"]
            }
        }
    )
    
    total_queries: int = Field(
        ...,
        description="Total number of queries processed",
        ge=0
    )
    avg_response_time: float = Field(
        ...,
        description="Average response time in seconds",
        ge=0.0
    )
    popular_topics: list[str] = Field(
        ...,
        description="List of most popular query topics",
        min_length=0,
        max_length=100
    )


class HealthResponse(BaseModel):
    """Response model for health check endpoint."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "status": "healthy",
                "uptime": "24h 15m",
                "timestamp": "2025-12-09T16:44:00Z",
                "version": "1.0.0"
            }
        }
    )
    
    status: Literal["healthy", "degraded", "unhealthy"] = Field(
        ...,
        description="Current health status of the service"
    )
    uptime: str = Field(
        ...,
        description="Service uptime duration"
    )
    timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        description="Current server timestamp"
    )
    version: str = Field(
        default="1.0.0",
        description="API version"
    )
    checks: dict[str, bool] = Field(
        default_factory=dict,
        description="Individual health check results"
    )


class DetailedAnalyticsResponse(BaseModel):
    """Extended analytics response with additional metrics."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "total_queries": 1250,
                "avg_response_time": 0.85,
                "popular_topics": ["AI", "FastAPI", "Python"],
                "queries_by_hour": [45, 52, 38, 61],
                "error_rate": 0.02,
                "cache_hit_rate": 0.78,
                "active_users": 142
            }
        }
    )
    
    total_queries: int = Field(..., ge=0)
    avg_response_time: float = Field(..., ge=0.0)
    popular_topics: list[str] = Field(...)
    queries_by_hour: list[int] = Field(
        default_factory=list,
        description="Query count for each hour of the day"
    )
    error_rate: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Percentage of failed requests"
    )
    cache_hit_rate: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Cache hit rate percentage"
    )
    active_users: int = Field(
        default=0,
        ge=0,
        description="Number of active users"
    )


class TopicAnalyticsResponse(BaseModel):
    """Response model for topic-specific analytics."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "topic": "AI",
                "query_count": 342,
                "avg_response_time": 0.72,
                "success_rate": 0.98,
                "trending": True
            }
        }
    )
    
    topic: str = Field(..., min_length=1, max_length=100)
    query_count: int = Field(..., ge=0)
    avg_response_time: float = Field(..., ge=0.0)
    success_rate: float = Field(..., ge=0.0, le=1.0)
    trending: bool = Field(default=False)


# ================= API Endpoints =================

@router.get(
    "/stats",
    response_model=AnalyticsResponse,
    summary="Get analytics statistics",
    description="Retrieve overall analytics metrics including query counts and popular topics",
    status_code=status.HTTP_200_OK
)
async def get_analytics() -> AnalyticsResponse:
    """
    Get basic analytics statistics.
    
    Returns:
        AnalyticsResponse: Analytics data including total queries, 
                          average response time, and popular topics
    """
    # In production, this would fetch from database/cache
    return AnalyticsResponse(
        total_queries=1250,
        avg_response_time=0.85,
        popular_topics=["AI", "FastAPI", "Python"]
    )


@router.get(
    "/stats/detailed",
    response_model=DetailedAnalyticsResponse,
    summary="Get detailed analytics",
    description="Retrieve comprehensive analytics with additional metrics",
    status_code=status.HTTP_200_OK
)
async def get_detailed_analytics(
    time_range: Annotated[
        Literal["1h", "24h", "7d", "30d"],
        Query(description="Time range for analytics data")
    ] = "24h"
) -> DetailedAnalyticsResponse:
    """
    Get detailed analytics with extended metrics.
    
    Args:
        time_range: Time range for analytics (1h, 24h, 7d, 30d)
    
    Returns:
        DetailedAnalyticsResponse: Comprehensive analytics data
    """
    # Mock data - replace with actual database queries
    return DetailedAnalyticsResponse(
        total_queries=1250,
        avg_response_time=0.85,
        popular_topics=["AI", "FastAPI", "Python"],
        queries_by_hour=[45, 52, 38, 61, 55, 48, 42, 39],
        error_rate=0.02,
        cache_hit_rate=0.78,
        active_users=142
    )


@router.get(
    "/stats/topics/{topic}",
    response_model=TopicAnalyticsResponse,
    summary="Get topic-specific analytics",
    description="Retrieve analytics for a specific topic",
    status_code=status.HTTP_200_OK
)
async def get_topic_analytics(
    topic: Annotated[str, Field(min_length=1, max_length=100)]
) -> TopicAnalyticsResponse:
    """
    Get analytics for a specific topic.
    
    Args:
        topic: Topic name to get analytics for
    
    Returns:
        TopicAnalyticsResponse: Topic-specific analytics data
    
    Raises:
        HTTPException: If topic not found
    """
    # Mock data - replace with actual database query
    popular_topics = ["AI", "FastAPI", "Python", "ML", "Data Science"]
    
    if topic not in popular_topics:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Topic '{topic}' not found in analytics data"
        )
    
    return TopicAnalyticsResponse(
        topic=topic,
        query_count=342,
        avg_response_time=0.72,
        success_rate=0.98,
        trending=True
    )


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Health check endpoint",
    description="Check service health status and uptime",
    status_code=status.HTTP_200_OK
)
async def health_check() -> HealthResponse:
    """
    Perform health check on the service.
    
    Returns:
        HealthResponse: Service health status and metadata
    """
    # Mock uptime calculation - in production, track actual start time
    uptime_hours = 24
    uptime_minutes = 15
    uptime_str = f"{uptime_hours}h {uptime_minutes}m"
    
    # Perform health checks
    health_checks = {
        "database": True,      # Check DB connection
        "cache": True,         # Check cache connection
        "external_api": True,  # Check external API availability
    }
    
    # Determine overall health
    all_healthy = all(health_checks.values())
    health_status: Literal["healthy", "degraded", "unhealthy"] = (
        "healthy" if all_healthy else "degraded"
    )
    
    return HealthResponse(
        status=health_status,
        uptime=uptime_str,
        timestamp=datetime.utcnow(),
        version="1.0.0",
        checks=health_checks
    )


@router.get(
    "/health/live",
    summary="Liveness probe",
    description="Simple liveness check for container orchestration",
    status_code=status.HTTP_200_OK,
    response_model=dict[str, str]
)
async def liveness_probe() -> dict[str, str]:
    """
    Kubernetes/Docker liveness probe endpoint.
    
    Returns:
        Simple status response
    """
    return {"status": "alive"}


@router.get(
    "/health/ready",
    summary="Readiness probe",
    description="Check if service is ready to accept traffic",
    status_code=status.HTTP_200_OK,
    response_model=dict[str, bool]
)
async def readiness_probe() -> dict[str, bool]:
    """
    Kubernetes/Docker readiness probe endpoint.
    
    Returns:
        Readiness status with component checks
    """
    # Check if all critical components are ready
    checks = {
        "database": True,
        "cache": True,
        "ready": True
    }
    
    if not checks["ready"]:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Service not ready"
        )
    
    return checks


@router.post(
    "/events",
    summary="Log analytics event",
    description="Log a custom analytics event",
    status_code=status.HTTP_201_CREATED
)
async def log_event(
    event_type: Annotated[str, Field(min_length=1, max_length=50)],
    event_data: dict[str, Any]
) -> dict[str, str]:
    """
    Log a custom analytics event.
    
    Args:
        event_type: Type of event to log
        event_data: Event data payload
    
    Returns:
        Success confirmation with event ID
    """
    # In production, store event in database/analytics system
    event_id = f"evt_{datetime.utcnow().timestamp()}"
    
    return {
        "status": "success",
        "event_id": event_id,
        "message": f"Event '{event_type}' logged successfully"
    }


# ================= Utility Functions =================

def calculate_uptime(start_time: datetime) -> str:
    """
    Calculate uptime string from start time.
    
    Args:
        start_time: Service start timestamp
    
    Returns:
        Formatted uptime string
    """
    uptime = datetime.utcnow() - start_time
    hours = int(uptime.total_seconds() // 3600)
    minutes = int((uptime.total_seconds() % 3600) // 60)
    
    return f"{hours}h {minutes}m"


def get_health_status(checks: dict[str, bool]) -> Literal["healthy", "degraded", "unhealthy"]:
    """
    Determine overall health status from individual checks.
    
    Args:
        checks: Dictionary of health check results
    
    Returns:
        Overall health status
    """
    if all(checks.values()):
        return "healthy"
    elif any(checks.values()):
        return "degraded"
    else:
        return "unhealthy"
