"""LLM operations API router for AI model interactions and query processing."""

import time
from collections.abc import Callable
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Annotated, Any, Literal

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    HTTPException,
    Query,
    status,
)
from pydantic import BaseModel, ConfigDict, Field, field_validator


# Create router with configuration
router = APIRouter(
    prefix="/llm",
    tags=["LLM Operations"],
    responses={
        400: {"description": "Bad request"},
        500: {"description": "LLM processing failed"},
    },
)


# ================= Type Aliases =================

LLMHandlerType = Callable[[str, dict[str, Any]], str]
AsyncLLMHandlerType = Callable[[str, dict[str, Any]], Any]  # Returns awaitable


# ================= Configuration =================

class LLMConfig:
    """Configuration for LLM operations."""
    
    MAX_QUERY_LENGTH = 4000
    MAX_CONTEXT_LENGTH = 8000
    REQUEST_TIMEOUT = 30  # seconds
    RATE_LIMIT_PER_MINUTE = 60
    
    AVAILABLE_MODELS = {
        "gpt-4": {
            "name": "GPT-4",
            "provider": "OpenAI",
            "context_window": 8192,
            "capabilities": ["text", "code", "reasoning"],
        },
        "gpt-3.5-turbo": {
            "name": "GPT-3.5 Turbo",
            "provider": "OpenAI",
            "context_window": 4096,
            "capabilities": ["text", "code"],
        },
        "claude-3": {
            "name": "Claude 3",
            "provider": "Anthropic",
            "context_window": 100000,
            "capabilities": ["text", "code", "analysis"],
        },
        "gemini-pro": {
            "name": "Gemini Pro",
            "provider": "Google",
            "context_window": 32768,
            "capabilities": ["text", "code", "multimodal"],
        },
        "local-model": {
            "name": "Local LLM",
            "provider": "Self-hosted",
            "context_window": 2048,
            "capabilities": ["text"],
        },
    }


# ================= Handler Registry =================

class LLMHandlerRegistry:
    """Thread-safe registry for LLM handlers."""
    
    def __init__(self) -> None:
        self._handler: LLMHandlerType | None = None
        self._async_handler: AsyncLLMHandlerType | None = None
        self._metadata: dict[str, Any] = {}
    
    def set_handler(
        self,
        handler: LLMHandlerType,
        metadata: dict[str, Any] | None = None
    ) -> None:
        """Set the LLM handler function."""
        if not callable(handler):
            raise TypeError("Handler must be callable")
        
        self._handler = handler
        self._metadata = metadata or {}
    
    def set_async_handler(
        self,
        handler: AsyncLLMHandlerType,
        metadata: dict[str, Any] | None = None
    ) -> None:
        """Set the async LLM handler function."""
        if not callable(handler):
            raise TypeError("Handler must be callable")
        
        self._async_handler = handler
        self._metadata = metadata or {}
    
    def get_handler(self) -> LLMHandlerType | None:
        """Get the registered handler."""
        return self._handler
    
    def get_async_handler(self) -> AsyncLLMHandlerType | None:
        """Get the registered async handler."""
        return self._async_handler
    
    def is_configured(self) -> bool:
        """Check if handler is configured."""
        return self._handler is not None or self._async_handler is not None
    
    def get_metadata(self) -> dict[str, Any]:
        """Get handler metadata."""
        return self._metadata.copy()


# Global registry instance
_registry = LLMHandlerRegistry()


# ================= Public API for Handler Registration =================

def set_llm_handler(
    handler: LLMHandlerType,
    metadata: dict[str, Any] | None = None
) -> None:
    """
    Register a synchronous LLM handler function.
    
    Args:
        handler: Function that takes (query, metadata) and returns response
        metadata: Optional metadata about the handler
    
    Example:
        >>> def my_handler(query: str, metadata: dict) -> str:
        ...     return f"Response to: {query}"
        >>> set_llm_handler(my_handler, {"model": "gpt-4"})
    """
    _registry.set_handler(handler, metadata)


def set_async_llm_handler(
    handler: AsyncLLMHandlerType,
    metadata: dict[str, Any] | None = None
) -> None:
    """
    Register an async LLM handler function.
    
    Args:
        handler: Async function that takes (query, metadata) and returns response
        metadata: Optional metadata about the handler
    """
    _registry.set_async_handler(handler, metadata)


def get_llm_handler() -> LLMHandlerType | None:
    """Get the registered LLM handler."""
    return _registry.get_handler()


# ================= Request/Response Models =================

class QueryRequest(BaseModel):
    """Request model for LLM queries."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "query": "What is the capital of France?",
                "metadata": {
                    "user_id": "user123",
                    "session_id": "sess456",
                    "model": "gpt-4"
                },
                "context": ["Previous conversation context"],
                "temperature": 0.7,
                "max_tokens": 500
            }
        }
    )
    
    query: str = Field(
        ...,
        min_length=1,
        max_length=LLMConfig.MAX_QUERY_LENGTH,
        description="User's question or prompt"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata for the query"
    )
    context: list[str] = Field(
        default_factory=list,
        max_length=10,
        description="Previous conversation context"
    )
    temperature: float = Field(
        default=0.7,
        ge=0.0,
        le=2.0,
        description="Sampling temperature for response generation"
    )
    max_tokens: int = Field(
        default=500,
        ge=1,
        le=4096,
        description="Maximum tokens in response"
    )
    model: str | None = Field(
        None,
        description="Specific model to use (optional)"
    )
    
    @field_validator("query")
    @classmethod
    def validate_query(cls, v: str) -> str:
        """Validate query is not empty after stripping."""
        if not v.strip():
            raise ValueError("Query cannot be empty or whitespace only")
        return v.strip()


class LLMResponse(BaseModel):
    """Response model for LLM operations."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "response": "The capital of France is Paris.",
                "model": "gpt-4",
                "tokens_used": 45,
                "processing_time": 1.23,
                "timestamp": "2025-12-09T16:49:00Z",
                "metadata": {"confidence": 0.95}
            }
        }
    )
    
    response: str = Field(..., description="LLM generated response")
    model: str | None = Field(None, description="Model used for generation")
    tokens_used: int | None = Field(None, ge=0, description="Tokens consumed")
    processing_time: float | None = Field(None, ge=0.0, description="Time in seconds")
    timestamp: datetime = Field(
        default_factory=datetime.utcnow,
        description="Response timestamp"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional response metadata"
    )


class ModelInfo(BaseModel):
    """Information about an available model."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "id": "gpt-4",
                "name": "GPT-4",
                "provider": "OpenAI",
                "context_window": 8192,
                "capabilities": ["text", "code", "reasoning"],
                "available": True
            }
        }
    )
    
    id: str = Field(..., description="Model identifier")
    name: str = Field(..., description="Human-readable model name")
    provider: str = Field(..., description="Model provider")
    context_window: int = Field(..., ge=0, description="Maximum context window")
    capabilities: list[str] = Field(..., description="Model capabilities")
    available: bool = Field(default=True, description="Model availability status")


class ModelsListResponse(BaseModel):
    """Response model for listing available models."""
    
    models: list[ModelInfo] = Field(..., description="List of available models")
    total: int = Field(..., ge=0, description="Total number of models")


class StreamChunk(BaseModel):
    """Response chunk for streaming."""
    
    chunk: str = Field(..., description="Response chunk")
    is_final: bool = Field(default=False, description="Whether this is the final chunk")


# ================= Dependency Functions =================

def verify_handler_configured() -> None:
    """
    Dependency to verify LLM handler is configured.
    
    Raises:
        HTTPException: If no handler is registered
    """
    if not _registry.is_configured():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="LLM handler not configured. Please configure the handler before making requests."
        )


async def log_request(data: QueryRequest) -> None:
    """Background task to log request details."""
    # In production, log to database or monitoring system
    print(f"[{datetime.utcnow()}] LLM Query: {data.query[:50]}...")


# ================= API Endpoints =================

@router.post(
    "/ask",
    response_model=LLMResponse,
    summary="Query LLM",
    description="Send a query to the configured LLM and receive a response",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(verify_handler_configured)]
)
async def ask_llm(
    data: QueryRequest,
    background_tasks: BackgroundTasks,
) -> LLMResponse:
    """
    Query the LLM with a question or prompt.
    
    Args:
        data: Query request with question and metadata
        background_tasks: FastAPI background tasks
    
    Returns:
        LLMResponse: Generated response with metadata
    
    Raises:
        HTTPException: If query processing fails
    """
    start_time = time.perf_counter()
    
    # Log request in background
    background_tasks.add_task(log_request, data)
    
    try:
        # Check for async handler first
        async_handler = _registry.get_async_handler()
        if async_handler:
            response_text = await async_handler(data.query, data.metadata)
        else:
            # Fall back to sync handler
            handler = _registry.get_handler()
            if not handler:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="No LLM handler configured"
                )
            response_text = handler(data.query, data.metadata)
        
        processing_time = time.perf_counter() - start_time
        
        return LLMResponse(
            response=response_text,
            model=data.model or _registry.get_metadata().get("model"),
            tokens_used=None,  # Calculate if token counter available
            processing_time=processing_time,
            timestamp=datetime.utcnow(),
            metadata={"query_length": len(data.query)}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"LLM processing failed: {str(e)}"
        ) from e


@router.post(
    "/ask/batch",
    response_model=list[LLMResponse],
    summary="Batch query LLM",
    description="Process multiple queries in a batch",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(verify_handler_configured)]
)
async def ask_llm_batch(
    queries: Annotated[
        list[QueryRequest],
        Field(min_length=1, max_length=10, description="List of queries")
    ],
    background_tasks: BackgroundTasks,
) -> list[LLMResponse]:
    """
    Process multiple queries in batch.
    
    Args:
        queries: List of query requests (max 10)
        background_tasks: FastAPI background tasks
    
    Returns:
        List of LLM responses
    """
    responses: list[LLMResponse] = []
    
    for query in queries:
        try:
            response = await ask_llm(query, background_tasks)
            responses.append(response)
        except HTTPException as e:
            # Return error response for failed queries
            responses.append(
                LLMResponse(
                    response=f"Error: {e.detail}",
                    model=None,
                    tokens_used=None,
                    processing_time=None,
                    timestamp=datetime.utcnow(),
                    metadata={"error": True}
                )
            )
    
    return responses


@router.get(
    "/models",
    response_model=ModelsListResponse,
    summary="List available models",
    description="Retrieve list of all available LLM models with their capabilities",
    status_code=status.HTTP_200_OK
)
async def list_models(
    provider: Annotated[
        str | None,
        Query(description="Filter by provider")
    ] = None,
    capability: Annotated[
        str | None,
        Query(description="Filter by capability")
    ] = None,
) -> ModelsListResponse:
    """
    List available LLM models with optional filtering.
    
    Args:
        provider: Filter by provider name
        capability: Filter by capability
    
    Returns:
        ModelsListResponse: List of available models
    """
    models: list[ModelInfo] = []
    
    for model_id, info in LLMConfig.AVAILABLE_MODELS.items():
        # Apply filters
        if provider and info["provider"].lower() != provider.lower():
            continue
        
        if capability and capability.lower() not in [c.lower() for c in info["capabilities"]]:
            continue
        
        models.append(
            ModelInfo(
                id=model_id,
                name=info["name"],
                provider=info["provider"],
                context_window=info["context_window"],
                capabilities=info["capabilities"],
                available=True,
            )
        )
    
    return ModelsListResponse(
        models=models,
        total=len(models)
    )


@router.get(
    "/models/{model_id}",
    response_model=ModelInfo,
    summary="Get model details",
    description="Retrieve detailed information about a specific model",
    status_code=status.HTTP_200_OK
)
async def get_model_info(
    model_id: Annotated[str, Field(min_length=1, max_length=100)]
) -> ModelInfo:
    """
    Get detailed information about a specific model.
    
    Args:
        model_id: Model identifier
    
    Returns:
        ModelInfo: Model details
    
    Raises:
        HTTPException: If model not found
    """
    if model_id not in LLMConfig.AVAILABLE_MODELS:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Model '{model_id}' not found"
        )
    
    info = LLMConfig.AVAILABLE_MODELS[model_id]
    
    return ModelInfo(
        id=model_id,
        name=info["name"],
        provider=info["provider"],
        context_window=info["context_window"],
        capabilities=info["capabilities"],
        available=True,
    )


@router.get(
    "/status",
    summary="Get LLM service status",
    description="Check the status of the LLM service and handler configuration",
    status_code=status.HTTP_200_OK
)
async def get_status() -> dict[str, Any]:
    """
    Get LLM service status.
    
    Returns:
        Service status information
    """
    return {
        "status": "operational" if _registry.is_configured() else "not_configured",
        "handler_configured": _registry.is_configured(),
        "handler_metadata": _registry.get_metadata(),
        "available_models": len(LLMConfig.AVAILABLE_MODELS),
        "timestamp": datetime.utcnow().isoformat(),
    }


@router.post(
    "/validate",
    summary="Validate query",
    description="Validate a query without processing it",
    status_code=status.HTTP_200_OK
)
async def validate_query(
    data: QueryRequest
) -> dict[str, Any]:
    """
    Validate a query without processing.
    
    Args:
        data: Query request to validate
    
    Returns:
        Validation result
    """
    return {
        "valid": True,
        "query_length": len(data.query),
        "has_context": len(data.context) > 0,
        "metadata_keys": list(data.metadata.keys()),
        "estimated_tokens": len(data.query.split()),  # Rough estimate
    }


# ================= Example Usage =================

def example_llm_handler(query: str, metadata: dict[str, Any]) -> str:
    """
    Example LLM handler implementation.
    
    Args:
        query: User query
        metadata: Request metadata
    
    Returns:
        Generated response
    """
    # In production, this would call actual LLM API
    return f"Example response to: {query}"


# Register example handler (for testing)
if __name__ == "__main__":
    set_llm_handler(example_llm_handler, {"model": "example-model"})
