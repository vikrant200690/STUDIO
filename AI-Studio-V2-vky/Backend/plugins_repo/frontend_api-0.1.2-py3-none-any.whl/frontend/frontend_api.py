"""
FastAPI application factory with integrated routers and frontend serving.

This module provides a configurable FastAPI application with:
- Multi-router architecture (LLM, Documents, Analytics)
- CORS middleware configuration
- Static file serving
- Centralized exception handling
- Health monitoring
"""

import logging
from collections.abc import Callable
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, ValidationError

from .routers import analytics, documents, llm


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


# ================= Type Aliases =================

LLMHandlerType = Callable[[str, dict[str, Any]], str]
AsyncLLMHandlerType = Callable[[str, dict[str, Any]], Any]  # Returns awaitable


# ================= Configuration Models =================

class APIConfig(BaseModel):
    """Configuration for API application."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "title": "Multi-Endpoint API",
                "description": "FastAPI with organized endpoints",
                "version": "1.0.0",
                "allow_origins": ["*"],
                "enable_gzip": True,
                "enable_docs": True
            }
        }
    )
    
    title: str = "Multi-Endpoint API"
    description: str = "FastAPI with multiple organized endpoints"
    version: str = "1.0.0"
    allow_origins: list[str] = ["*"]
    allow_credentials: bool = True
    enable_gzip: bool = True
    enable_docs: bool = True
    trusted_hosts: list[str] | None = None
    static_dir: Path | str | None = None
    debug: bool = False


class ErrorResponse(BaseModel):
    """Standard error response model."""
    
    error: str
    details: str | dict[str, Any] | list[Any]
    timestamp: datetime
    path: str | None = None
    request_id: str | None = None


# ================= Application Factory =================

class FrontendUtilsAPI:
    """
    FastAPI application factory with integrated routers and handlers.
    
    This class creates and configures a FastAPI application with:
    - Multiple routers (LLM, Documents, Analytics)
    - CORS and security middleware
    - Static file serving
    - Exception handling
    - Health monitoring
    """
    
    def __init__(
        self,
        llm_handler: LLMHandlerType | AsyncLLMHandlerType,
        info_handler: LLMHandlerType | None = None,
        config: APIConfig | None = None,
        **kwargs: Any
    ) -> None:
        """
        Initialize the API application.
        
        Args:
            llm_handler: Handler function for LLM operations
            info_handler: Optional info handler (defaults to default_info_handler)
            config: Optional APIConfig object
            **kwargs: Additional config parameters (merged with config)
        """
        # Merge config with kwargs
        if config is None:
            config = APIConfig(**kwargs)
        else:
            # Update config with any additional kwargs
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        
        self.config = config
        self.llm_handler = llm_handler
        self.info_handler = info_handler or self.default_info_handler
        self.start_time = datetime.utcnow()
        
        # Create application
        self.app = self._create_app()
        
        logger.info(f"API initialized: {config.title} v{config.version}")

    def _create_app(self) -> FastAPI:
        """Create and configure the FastAPI application."""
        
        # Lifespan context manager for startup/shutdown
        @asynccontextmanager
        async def lifespan(app: FastAPI):
            # Startup
            logger.info("Application starting up...")
            yield
            # Shutdown
            logger.info("Application shutting down...")
        
        # Create app with lifespan
        app = FastAPI(
            title=self.config.title,
            description=self.config.description,
            version=self.config.version,
            docs_url="/docs" if self.config.enable_docs else None,
            redoc_url="/redoc" if self.config.enable_docs else None,
            lifespan=lifespan,
            debug=self.config.debug,
        )
        
        # Add middleware
        self._add_middleware(app)
        
        # Set up handlers
        self._setup_handlers()
        
        # Include routers
        self._include_routers(app)
        
        # Add exception handlers
        self._add_exception_handlers(app)
        
        # Add core endpoints
        self._add_core_endpoints(app)
        
        # Mount static files
        self._mount_static_files(app)
        
        return app

    def _add_middleware(self, app: FastAPI) -> None:
        """Add middleware to the application."""
        
        # CORS middleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self.config.allow_origins,
            allow_credentials=self.config.allow_credentials,
            allow_methods=["*"],
            allow_headers=["*"],
            expose_headers=["*"],
        )
        logger.info(f"CORS configured with origins: {self.config.allow_origins}")
        
        # GZip compression middleware
        if self.config.enable_gzip:
            app.add_middleware(GZipMiddleware, minimum_size=1000)
            logger.info("GZip compression enabled")
        
        # Trusted host middleware
        if self.config.trusted_hosts:
            app.add_middleware(
                TrustedHostMiddleware,
                allowed_hosts=self.config.trusted_hosts
            )
            logger.info(f"Trusted hosts: {self.config.trusted_hosts}")

    def _setup_handlers(self) -> None:
        """Set up handlers for routers."""
        
        # Set LLM handler
        if hasattr(llm, 'set_llm_handler'):
            llm.set_llm_handler(self.llm_handler)
            logger.info("LLM handler registered")
        
        # Set async handler if applicable
        if hasattr(llm, 'set_async_llm_handler'):
            import asyncio
            if asyncio.iscoroutinefunction(self.llm_handler):
                llm.set_async_llm_handler(self.llm_handler)
                logger.info("Async LLM handler registered")

    def _include_routers(self, app: FastAPI) -> None:
        """Include all routers in the application."""
        
        routers = [
            (llm.router, "LLM Operations"),
            (documents.router, "Document Management"),
            (analytics.router, "Analytics"),
        ]
        
        for router, name in routers:
            app.include_router(router)
            logger.info(f"Router included: {name}")

    def _add_exception_handlers(self, app: FastAPI) -> None:
        """Add custom exception handlers."""
        
        @app.exception_handler(HTTPException)
        async def http_exception_handler(
            request: Request,
            exc: HTTPException
        ) -> JSONResponse:
            """Handle HTTP exceptions."""
            logger.warning(
                f"HTTP {exc.status_code}: {exc.detail} - "
                f"Path: {request.url.path}"
            )
            
            return JSONResponse(
                status_code=exc.status_code,
                content=ErrorResponse(
                    error=f"HTTP {exc.status_code}",
                    details=exc.detail,
                    timestamp=datetime.utcnow(),
                    path=str(request.url.path),
                ).model_dump()
            )
        
        @app.exception_handler(RequestValidationError)
        async def validation_exception_handler(
            request: Request,
            exc: RequestValidationError
        ) -> JSONResponse:
            """Handle request validation errors."""
            logger.warning(
                f"Validation error on {request.url.path}: {exc.errors()}"
            )
            
            return JSONResponse(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                content=ErrorResponse(
                    error="Validation Failed",
                    details=exc.errors(),
                    timestamp=datetime.utcnow(),
                    path=str(request.url.path),
                ).model_dump()
            )
        
        @app.exception_handler(ValidationError)
        async def pydantic_validation_handler(
            request: Request,
            exc: ValidationError
        ) -> JSONResponse:
            """Handle Pydantic validation errors."""
            logger.warning(
                f"Pydantic validation error on {request.url.path}: {exc.errors()}"
            )
            
            return JSONResponse(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                content=ErrorResponse(
                    error="Validation Failed",
                    details=exc.errors(),
                    timestamp=datetime.utcnow(),
                    path=str(request.url.path),
                ).model_dump()
            )
        
        @app.exception_handler(Exception)
        async def general_exception_handler(
            request: Request,
            exc: Exception
        ) -> JSONResponse:
            """Handle all other exceptions."""
            logger.error(
                f"Unhandled exception on {request.url.path}: {str(exc)}",
                exc_info=True
            )
            
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content=ErrorResponse(
                    error="Internal Server Error",
                    details=str(exc) if self.config.debug else "An error occurred",
                    timestamp=datetime.utcnow(),
                    path=str(request.url.path),
                ).model_dump()
            )

    def _add_core_endpoints(self, app: FastAPI) -> None:
        """Add core application endpoints."""
        
        @app.get(
            "/",
            response_class=HTMLResponse,
            summary="Serve frontend",
            description="Serve the main frontend HTML page",
            tags=["Frontend"]
        )
        async def serve_frontend() -> HTMLResponse:
            """Serve the frontend HTML page."""
            try:
                # Try to load from static directory
                if self.config.static_dir:
                    static_path = Path(self.config.static_dir)
                    index_path = static_path / "index.html"
                    
                    if index_path.exists():
                        content = index_path.read_text(encoding="utf-8")
                        return HTMLResponse(content=content, status_code=200)
                
                # Try importlib.resources (package data)
                try:
                    from importlib.resources import files
                    content = (
                        files("frontend")
                        .joinpath("static/index.html")
                        .read_text(encoding="utf-8")
                    )
                    return HTMLResponse(content=content, status_code=200)
                except (ImportError, FileNotFoundError, AttributeError):
                    pass
                
                # Fallback: Return basic HTML
                return HTMLResponse(
                    content=self._get_fallback_html(),
                    status_code=200
                )
                
            except Exception as e:
                logger.error(f"Error serving frontend: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Failed to load frontend"
                )
        
        @app.get(
            "/api/info",
            summary="API information",
            description="Get API version and configuration info",
            tags=["Core"]
        )
        async def api_info() -> dict[str, Any]:
            """Get API information."""
            uptime = datetime.utcnow() - self.start_time
            
            return {
                "title": self.config.title,
                "version": self.config.version,
                "description": self.config.description,
                "uptime_seconds": uptime.total_seconds(),
                "docs_url": "/docs" if self.config.enable_docs else None,
                "endpoints": {
                    "llm": "/llm",
                    "documents": "/documents",
                    "analytics": "/analytics",
                },
            }
        
        @app.get(
            "/api/health",
            summary="Health check",
            description="Check API health status",
            tags=["Core"]
        )
        async def health_check() -> dict[str, Any]:
            """Health check endpoint."""
            return {
                "status": "healthy",
                "timestamp": datetime.utcnow().isoformat(),
                "uptime_seconds": (datetime.utcnow() - self.start_time).total_seconds(),
            }

    def _mount_static_files(self, app: FastAPI) -> None:
        """Mount static files directory."""
        
        static_dir = None
        
        # Check configured static directory
        if self.config.static_dir:
            static_dir = Path(self.config.static_dir)
        else:
            # Try to find static directory in package
            try:
                from importlib.resources import files
                static_dir = Path(str(files("frontend").joinpath("static")))
            except (ImportError, AttributeError):
                pass
        
        if static_dir and static_dir.exists() and static_dir.is_dir():
            try:
                app.mount(
                    "/static",
                    StaticFiles(directory=str(static_dir)),
                    name="static"
                )
                logger.info(f"Static files mounted from: {static_dir}")
            except Exception as e:
                logger.warning(f"Failed to mount static files: {e}")
        else:
            logger.warning("Static directory not found, static files not mounted")

    def _get_fallback_html(self) -> str:
        """Get fallback HTML when index.html is not found."""
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.config.title}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }}
        .container {{
            background: white;
            color: #333;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }}
        h1 {{ color: #667eea; }}
        a {{ color: #667eea; text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
        .endpoint {{ 
            background: #f5f5f5; 
            padding: 10px; 
            margin: 10px 0; 
            border-radius: 5px; 
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{self.config.title}</h1>
        <p>{self.config.description}</p>
        <p><strong>Version:</strong> {self.config.version}</p>
        
        <h2>Available Endpoints</h2>
        <div class="endpoint">
            <strong>📚 API Documentation:</strong> 
            <a href="/docs">/docs</a> | <a href="/redoc">/redoc</a>
        </div>
        <div class="endpoint">
            <strong>🤖 LLM Operations:</strong> <a href="/llm/models">/llm/models</a>
        </div>
        <div class="endpoint">
            <strong>📄 Document Management:</strong> <a href="/documents/list">/documents/list</a>
        </div>
        <div class="endpoint">
            <strong>📊 Analytics:</strong> <a href="/analytics/stats">/analytics/stats</a>
        </div>
        <div class="endpoint">
            <strong>🏥 Health Check:</strong> <a href="/api/health">/api/health</a>
        </div>
    </div>
</body>
</html>
"""

    def get_app(self) -> FastAPI:
        """
        Get the configured FastAPI application.
        
        Returns:
            Configured FastAPI application instance
        """
        return self.app

    @staticmethod
    def default_info_handler(context: str, metadata: dict[str, Any]) -> str:
        """
        Default info handler implementation.
        
        Args:
            context: Context string
            metadata: Additional metadata
        
        Returns:
            Formatted info response
        """
        return f"Info received: {context}"


# ================= Convenience Functions =================

def create_api(
    llm_handler: LLMHandlerType | AsyncLLMHandlerType,
    **kwargs: Any
) -> FastAPI:
    """
    Convenience function to create a FastAPI application.
    
    Args:
        llm_handler: Handler function for LLM operations
        **kwargs: Configuration parameters
    
    Returns:
        Configured FastAPI application
    
    Example:
        >>> def my_llm_handler(query: str, metadata: dict) -> str:
        ...     return f"Response to: {query}"
        >>> app = create_api(my_llm_handler, title="My API", version="2.0.0")
    """
    api = FrontendUtilsAPI(llm_handler, **kwargs)
    return api.get_app()


def create_api_with_config(
    llm_handler: LLMHandlerType | AsyncLLMHandlerType,
    config: APIConfig
) -> FastAPI:
    """
    Create API with explicit configuration object.
    
    Args:
        llm_handler: Handler function for LLM operations
        config: APIConfig object
    
    Returns:
        Configured FastAPI application
    """
    api = FrontendUtilsAPI(llm_handler, config=config)
    return api.get_app()
