import os
from pathlib import Path
from typing import Any
import yaml
from dotenv import load_dotenv


class EnvConfigLoader:
    """Loads environment variables from .env file with type safety."""
    
    def __init__(self, env_path: str | Path = ".env") -> None:
        self.env_path = Path(env_path)
        self.config: dict[str, Any] = {}
        self.load_env()

    def load_env(self) -> None:
        """Load and parse environment variables."""
        if not self.env_path.exists():
            print(f"Warning: {self.env_path} not found")
            return
            
        load_dotenv(self.env_path)
        self.config["APP_ENV"] = os.getenv("APP_ENV", "development")
        self.config["DEBUG"] = self._to_bool(os.getenv("DEBUG", "false"))
        self.config["DB_HOST"] = os.getenv("DB_HOST", "localhost")
        self.config["DB_PORT"] = int(os.getenv("DB_PORT", "5432"))
        self.config["API_KEY"] = os.getenv("API_KEY", "")

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve configuration value by key."""
        return self.config.get(key, default)

    @staticmethod
    def _to_bool(value: str | None) -> bool:
        """Convert string to boolean."""
        if value is None:
            return False
        return value.lower() in ("1", "true", "yes", "on")


class YamlConfigLoader:
    """Loads configuration from YAML file with error handling."""
    
    def __init__(self, yaml_path: str | Path = "config.yml") -> None:
        self.yaml_path = Path(yaml_path)
        self.config: dict[str, Any] = {}
        self.load_yaml()

    def load_yaml(self) -> None:
        """Load and parse YAML configuration file."""
        if not self.yaml_path.exists():
            print(f"Warning: {self.yaml_path} not found")
            return
            
        try:
            with self.yaml_path.open("r", encoding="utf-8") as file:
                yaml_data = yaml.safe_load(file)
                if yaml_data:
                    self.config.update(yaml_data)
        except yaml.YAMLError as e:
            print(f"Error parsing YAML file: {e}")
        except OSError as e:
            print(f"Error reading file: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve configuration value by key."""
        return self.config.get(key, default)


if __name__ == "__main__":
    print("---- .env config ----")
    env_loader = EnvConfigLoader(".env")
    print("APP_ENV:", env_loader.get("APP_ENV"))
    print("DB_HOST:", env_loader.get("DB_HOST"))
    print("DEBUG:", env_loader.get("DEBUG"))
    print("DB_PORT:", env_loader.get("DB_PORT"))
    print("API_KEY:", env_loader.get("API_KEY"))

    print("\n---- .yml config ----")
    yaml_loader = YamlConfigLoader("config.yml")
    print("APP_NAME:", yaml_loader.get("APP_NAME"))
    print("VERSION:", yaml_loader.get("VERSION"))
    print("ENABLE_LOGGING:", yaml_loader.get("ENABLE_LOGGING"))
